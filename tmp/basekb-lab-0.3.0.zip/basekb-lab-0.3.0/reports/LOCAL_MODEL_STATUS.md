# Local Model Status

Release verification: **not_run**. Local model endpoint was not available during release verification.

Configured model: `qwen3-coder:30b`  
Endpoint: `http://127.0.0.1:11434/v1`

No mocked or estimated generative-model score is substituted. Start the intended local model and run `npm run smoke:local` followed by `npm run eval:llm`.
