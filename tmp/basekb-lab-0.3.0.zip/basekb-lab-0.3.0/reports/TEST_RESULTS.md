# Test Results — BaseKB Lab 0.3.0

Generated: 2026-10-04T10:28:06.222Z

- deterministic tests: **166/166 passed**
- failures: **0**
- syntax check: **passed**
- deterministic identity fixture: **44/44 correct decisions**
- false auto-links on authored identity fixture: **0**
- local generative-model evaluation: **not run by release verification**

The deterministic identity fixture is an authored regression suite, not an independent benchmark. See `IDENTITY_EVAL.md` and `identity-eval.json`.
