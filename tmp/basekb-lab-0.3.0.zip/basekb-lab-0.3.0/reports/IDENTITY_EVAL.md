# Deterministic Identity Evaluation

Run: 2026-10-04T10:28:08.648Z; Node v22.16.0, linux/x64.

**Synthetic regression set authored alongside the implementation, not an independent benchmark.** No LLM calls.

| Variant | Correct | Auto-links | False auto-links | Abstentions |
|---|---:|---:|---:|---:|
| full | 44/44 | 20 | 0 | 19 |
| without_aliases | 41/44 | 18 | 0 | 19 |
| without_context | 39/44 | 17 | 0 | 18 |
| without_properties | 34/44 | 11 | 0 | 29 |
| without_fuzzy | 43/44 | 20 | 0 | 18 |

`decisionCoverage` includes both links and decisions to create a new referent. Link precision is computed only for `same` predictions. Abstentions are deliberate and are not replaced with guesses. The gold set includes cases that must remain ambiguous.

Complete results and decision reasons are in `identity-eval.json`. These results do not validate natural-language formalization, a real model inference, or safety on an unknown distribution.
