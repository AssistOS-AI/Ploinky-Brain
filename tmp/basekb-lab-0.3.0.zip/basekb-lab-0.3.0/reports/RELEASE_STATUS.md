# Release Status — BaseKB Lab 0.3.0

Generated: 2026-10-04T10:28:06.222Z

**Deterministic release gate: PASS**

The syntax check, 166 deterministic tests, and deterministic identity regression/ablation completed successfully. The release keeps model evaluation separate: `npm run verify` never fabricates or silently substitutes LLM results.

Runtime semantic versions used by this build:

```json
{
  "schemaVersion": "2",
  "internalLanguage": "en",
  "knowledgeIRVersion": "1.0",
  "programApiVersion": "1.0",
  "resolverPolicyVersion": "3.0",
  "inferenceVersion": "1.0",
  "identityProfileVersion": "1.0",
  "auditChainVersion": "1.0",
  "promptVersion": "2.1"
}
```

Local-model status: Local model endpoint was not available during release verification.
