/**
 * v1 -> v2 changes the semantic contract: canonical semantic records must be English.
 * A generic migration cannot prove that an arbitrary v1 store already satisfies that
 * contract. Therefore the caller must explicitly assert that semantic content has
 * been reviewed/normalized before this metadata migration is applied.
 */
export function migrateV1ToV2(db, versions, {assumeEnglish=false, cleanupLegacyBootstrap=false}={}) {
  const get=db.prepare('SELECT value FROM meta WHERE key=?');
  const put=db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  if(get.get('schemaVersion')?.value !== '1') return false;
  if(!assumeEnglish) {
    const e=new Error('v1 semantic language cannot be verified deterministically. Normalize/review the store first, then rerun with --assume-english.');
    e.code='MIGRATE_LANGUAGE';throw e;
  }
  // v1 did not distinguish field-level identity provenance. Preserve values but
  // explicitly downgrade them so they cannot become v2 identity anchors by accident.
  const entityRows=db.prepare("SELECT id,data FROM records WHERE kind='entity'").all();
  const updateEntity=db.prepare('UPDATE records SET data=? WHERE id=?');
  for(const row of entityRows){
    let data;try{data=JSON.parse(row.data);}catch{continue;}
    const identityEvidence={ids:{},properties:{}};
    for(const key of Object.keys(data.ids??{}))identityEvidence.ids[key]={trusted:false,reason:'legacy_v1_unprovenanced'};
    for(const key of Object.keys(data.properties??{}))identityEvidence.properties[key]={trusted:false,reason:'legacy_v1_unprovenanced'};
    data.identityEvidence=identityEvidence;data.internalLanguage='en';
    updateEntity.run(JSON.stringify(data),row.id);
  }

  if(cleanupLegacyBootstrap) {
    // These exact aliases were edge-language conveniences in BaseKB Lab 0.1 and
    // violate the v2 rule that semantic aliases in the KB are English.
    const legacy=[
      ['părinte al','sys:parentOf'],['strămoș al','sys:ancestorOf'],['lucrează la','sys:employedBy'],
      ['angajează','sys:employs'],['situat în','sys:locatedIn']
    ];
    const rows=db.prepare("SELECT id,name,data FROM records WHERE kind='alias'").all();
    const del=db.prepare('DELETE FROM records WHERE id=?');
    for(const row of rows){
      let data={};try{data=JSON.parse(row.data);}catch{}
      if(legacy.some(([name,target])=>row.name===name&&data.target===target))del.run(row.id);
    }
  }
  put.run('schemaVersion','2');
  for(const [key,value] of Object.entries(versions)) put.run(key,String(value));
  put.run('migrationLanguageAssertion','operator-reviewed-or-normalized');
  return true;
}
