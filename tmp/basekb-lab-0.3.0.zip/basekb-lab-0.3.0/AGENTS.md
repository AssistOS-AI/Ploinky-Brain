# Coding-Agent Contract

This file is normative. A coding agent may refactor implementation details but must not silently weaken these invariants.

## Non-negotiable invariants

1. **English semantic core.** Canonical semantic objects and internal answers use English. Proper names/identifiers keep canonical spelling. Raw source text may remain non-English only as evidence/provenance.
2. **Never execute model-generated JavaScript in Node/V8.** Model output must pass the custom parser, Knowledge IR validator and KB-VM whitelist.
3. **Name similarity is not identity proof.** Exact labels, fuzzy matching, punctuation/diacritic normalization, initials, nicknames and acronyms are candidate generators unless a documented policy says otherwise.
4. **Hard identity conflicts veto automatic merges.** A human selection cannot override conflicting trusted unique identifiers without correcting the underlying evidence.
5. **Field-level identity evidence matters.** Identity-sensitive values produced by the LLM must use evidence-bearing values before they can become automatic anchors.
6. **Mention is not entity.** Preserve `Mention -> ResolutionDecision -> Entity`; do not replace it with destructive entity union.
7. **BaseKB is not mutated by chat.** Session writes belong in SessionKB; durable promotion creates a new reviewed BaseKB.
8. **Clarification and failed execution are semantically atomic.** No partial entity/fact/schema writes may survive.
9. **Absence is not negation.** Explicit negative assertions are represented separately. `unknown` is not `false`.
10. **Contradictions remain representable.** Do not implement logical explosion or silently delete conflicting claims.
11. **Generated executable/schema knowledge is quarantined.** New rules, constraints, functions, hooks, aliases and semantic relation metadata require a separate operator approval step before activation.
12. **Provenance is first-class.** Model-generated factual assertions must be traceable to an exact source span or a trusted import adapter.
13. **LLM/network calls never occur inside SQLite transactions.** Plan first; execute deterministic work transactionally.
14. **All public semantic formats are versioned.** Do not silently reinterpret old DB/IR/API/policy versions; add a migration/version bump.
15. **Identity evidence is accumulated non-destructively.** Do not overwrite a canonical entity merely to add a newly observed identifier/property; derive the active `IdentityProfile` from trusted evidence and keep conflicting claims inspectable.
16. **Resolution correction is explicit replay, not silent mutation.** Supersede the old decision, retain it for audit, and rewrite only assertions with recorded identity dependencies. Legacy untracked dependencies fail closed.
17. **Creation metadata is historical.** Do not silently rewrite a store's original version metadata when a newer runtime opens it. Each execution records the actual runtime version set it used.
18. **Audit chains are integrity aids, not signatures.** Preserve hash-linked event semantics and do not describe them as protection from a fully privileged host.
19. **Do not weaken tests to make an implementation pass.** Change an expectation only when an explicit architectural decision changes, and document that decision.

## Required workflow for material changes

1. Read `docs/specs/00-review-decisions.md`, this file, and the spec relevant to the subsystem.
2. Add or update a regression test first for semantic/security changes.
3. Run `npm run check`, `npm test`, and `npm run eval`.
4. Keep model-dependent tests separate from deterministic tests.
5. Update the appropriate spec, `CHANGELOG.md`, version constants when needed, and migration files if persistence semantics changed.
6. Never claim a local-model result unless the real model endpoint was actually run.

## Definition of Done

A change is complete only when:

- deterministic tests pass;
- new behavior has a regression test;
- dry-run and rollback behavior were considered;
- provenance and identity effects were considered;
- version compatibility was considered;
- the English-core boundary is preserved;
- security capabilities did not expand accidentally;
- documentation matches implementation.

## High-value next work

Prefer improvements that strengthen correctness before breadth: `CandidateClaim` staging for long documents, richer type-specific identity policies, relation semantic comparison, independent benchmark corpora, persistent indexes/query planning, semi-naive inference, signed/reviewer-aware approval records, and systematic local-model formalization evaluation.
