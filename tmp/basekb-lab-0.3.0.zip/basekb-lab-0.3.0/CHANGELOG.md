# Changelog

## 0.3.0 — identity replay and audit hardening

- added non-destructive derived `IdentityProfile` aggregation from active trusted resolution evidence;
- superseded resolutions no longer contribute identity anchors;
- added explicit identity conflicts to automatic-merge blockers;
- assertions now record `identityDependencies` when their entity arguments came from a unique resolution in the current execution;
- added operator-only `Engine.rebindResolution(...)` with transactional dependency-directed fact rewriting, masking of replaced facts and derived-fact recomputation;
- added fail-closed `REPLAY_UNTRACKED` behavior for legacy same-source references without dependency metadata;
- added first-class committed `execution` records with runtime versions, program/IR hashes, answer hash and inference summary;
- stopped silently rewriting historical store version metadata when a newer compatible runtime opens a store;
- added hash-linked audit metadata for session events plus `Store.verifyAuditChain()` and CLI `audit`;
- added CLI `identity-profile` and `rebind-resolution` operator commands;
- expanded `/api/kb` diagnostics with executions, audit state and separate store-creation/runtime versions;
- resolver policy bumped to 3.0; prompt contract bumped to 2.1; identity-profile/audit versions added;
- trusted standard identifiers now receive namespace-specific syntax/checksum validation before becoming identity anchors;
- strict N-Triples imports attach field-level source evidence to resource IRIs, enabling safe identity reuse across separate deterministic imports;
- retrieved LLM context uses active derived identity profiles rather than stale destructive entity fields;
- `npm run verify` now regenerates release reports from the current tree and keeps real-model evaluation explicitly separate;
- deterministic suite expanded to 166 tests.

## 0.2.0 — pre-agent hardening

- established the English-only internal semantic core with multilingual normalization/presentation at the boundary;
- added versioned Knowledge IR and version metadata;
- made mentions and identity resolution decisions first-class;
- required field-level evidence for trusted identity discriminators/identifiers;
- hardened organization/person same-name handling and identity abstention;
- added migration skeleton, coding-agent contract and local-model operational docs;
- expanded deterministic tests and identity evaluation.

## 0.1.0 — initial executable knowledge prototype

- BaseKB/SessionKB overlay;
- restricted JS-like Knowledge Program parser/interpreter;
- facts, relation types, rules, constraints, functions/hooks, provenance and temporal contexts;
- conservative resolver, local LLM adapter, AutoFormaliser, CLI/web demo and deterministic tests.
