const $=id=>document.getElementById(id);
let config,sessionId,busy=false;
async function api(path,data){
  const r=await fetch(path,{method:data===undefined?'GET':'POST',headers:{'X-KB-Token':config?.token??'',...(data!==undefined?{'Content-Type':'application/json'}:{})},...(data!==undefined?{body:JSON.stringify(data)}:{})});
  const v=await r.json();if(!r.ok)throw new Error(`${v.error?.code}: ${v.error?.message}`);return v;
}
function message(text,role='assistant'){const el=document.createElement('div');el.className=`message ${role}`;el.textContent=text;$('messages').append(el);el.scrollIntoView({block:'nearest',behavior:'smooth'});return el;}
function state(flag,text=''){busy=flag;for(const id of ['send','new','fork'])$(id).disabled=flag;$('status').textContent=text;}
async function refresh(){if(!sessionId)return;$('session').textContent=`Session: ${sessionId}`;const data=await api(`/api/kb?session=${sessionId}`);$('kbdata').textContent=JSON.stringify(data,null,2);}
async function show(result){
  $('program').textContent=result.program??'—';$('resolution').textContent=JSON.stringify(result.resolutions??result.error?.details??{},null,2);
  $('evidence').textContent=JSON.stringify({inputNormalization:result.inputNormalization,canonicalIR:result.ir,irHash:result.irHash,evidence:result.answer?.evidence,inference:result.inference,computations:result.answer?.computations,attempts:result.attempts?.map(a=>({ok:a.ok,error:a.error,model:a.reply?.model,latencyMs:a.reply?.latencyMs}))},null,2);
  if(result.needsClarification){
    const el=message(`Clarification required.\n${result.displayMessage??result.error.message}`);
    if(result.hint){const note=document.createElement('small');note.textContent=`Advisory identity-LLM hint, not authoritative: ${JSON.stringify(result.hint)}`;el.append(note);}
    if(result.pendingId){
      const choices=[...(result.error.details.candidates??[]),{id:'__new__',name:'A distinct entity',description:'Create a new referent without merging identities.'}];
      for(const c of choices){const b=document.createElement('button');b.textContent=`${c.name}\n${c.description??''}`;b.disabled=!!c.blockers?.length;
        b.onclick=async()=>{if(busy)return;state(true,'Applying explicit identity selection…');try{await show(await api('/api/resolve',{pendingId:result.pendingId,candidateId:c.id}));for(const x of el.querySelectorAll('button'))x.disabled=true;}catch(e){message(e.message,'error');}finally{state(false);}};el.append(b);
        if(c.features){const d=document.createElement('details'),s=document.createElement('summary'),p=document.createElement('pre');s.textContent='Candidate signals, anchors and blockers';p.textContent=JSON.stringify({features:c.features,anchors:c.anchors,blockers:c.blockers},null,2);d.append(s,p);el.append(d);}
      }
    }
  }else{
    const text=result.answer?.displayText??result.answer?.text??'Program completed.';const el=message(`${result.dryRun?'PREVIEW — nothing persisted\n':''}${text}`);
    if(result.answer?.displayLanguage && result.answer.displayLanguage!=='en'){const s=document.createElement('small');s.textContent=`Presentation language: ${result.answer.displayLanguage}; canonical internal answer remains English.`;el.append(s);}
    for(const warning of result.answer?.warnings??[]){const s=document.createElement('small');s.textContent=warning;el.append(s);}
  }
  await refresh();
}
async function newSession(fork=false){state(true);try{const r=await api(fork?'/api/fork':'/api/sessions',fork?{sessionId}:{});sessionId=r.sessionId;localStorage.setItem('basekbSession',sessionId);$('messages').replaceChildren();await refresh();if(fork)message('Forked session created; BaseKB remains unchanged.');}catch(e){message(e.message,'error');}finally{state(false);}}
$('form').onsubmit=async e=>{e.preventDefault();if(busy)return;const text=$('input').value.trim();if(!text)return;message(text,'user');$('input').value='';state(true,'Language normalization → formalization → validation → reasoning…');try{await show(await api('/api/chat',{sessionId,text,dryRun:$('dry').checked,requestId:crypto.randomUUID()}));}catch(e){message(e.message,'error');}finally{state(false);}};
$('input').onkeydown=e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey))$('form').requestSubmit();};
$('new').onclick=()=>newSession();$('fork').onclick=()=>newSession(true);
for(const b of document.querySelectorAll('[data-tab]'))b.onclick=()=>{for(const id of ['trace','kb'])$(id).hidden=id!==b.dataset.tab;};
try{
  config=await api('/api/config');const health=await api('/api/health');$('mode').textContent=config.demo?'CONTROLLED DEMO · no LLM':`${config.model} · ${health.ok?'model server available':'model server unavailable; start scripts/start-model.mjs'} · internal=${config.internalLanguage}`;
  const examples=config.demo?['Ion is parent of Maria. Maria is parent of Ana. Who is grandparent of Ana?','Ion este părinte pentru Maria. Cine este părinte pentru Maria?','Sum 2, 3, 4']:[
    'Ion este tatăl Mariei. Maria este părintele Anei. Cine este bunicul Anei?',
    'Alex lucrează la Nova Labs. Cine este angajatorul lui Alex?',
    'Calculate the sum of 17, 23 and 42 using the available functions.'
  ];
  for(const text of examples){const b=document.createElement('button');b.textContent=text;b.onclick=()=>{$('input').value=text;$('input').focus();};$('examples').append(b);}
  sessionId=localStorage.getItem('basekbSession');if(sessionId){try{await refresh();const history=await api(`/api/history?session=${sessionId}`);for(const h of history){message(h.text,'user');message(h.answer.displayText??h.answer.text);}}catch{sessionId=null;}}
  if(!sessionId)await newSession();
}catch(e){message(e.message,'error');}
