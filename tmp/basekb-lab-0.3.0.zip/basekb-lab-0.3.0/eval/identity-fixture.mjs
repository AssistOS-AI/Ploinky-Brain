/** Synthetic identity-resolution challenge cases; NOT an independent real-world benchmark. */
export function identityFixture() {
  const entities=[
    {id:'e:stefan',kind:'entity',name:'Ștefan Müller',description:'A fictional researcher at the North laboratory.',type:'sys:Person',layer:'base',ids:{orcid:'0000-0001-2345-6789'},properties:{birthDate:'1980-01-02',affiliation:'North Lab'}},
    {id:'e:alex1',kind:'entity',name:'Alex Stone',description:'A fictional person born in 1970, working at North Lab.',type:'sys:Person',layer:'base',ids:{registry:'P-101'},properties:{birthDate:'1970-01-01',affiliation:'North Lab'}},
    {id:'e:alex2',kind:'entity',name:'Alex Stone',description:'A different fictional person born in 1990, working at South Lab.',type:'sys:Person',layer:'base',ids:{registry:'P-102'},properties:{birthDate:'1990-01-01',affiliation:'South Lab'}},
    {id:'e:robert',kind:'entity',name:'Robert Vale',description:'A fictional person also nicknamed Bob.',type:'sys:Person',layer:'base',ids:{registry:'P-103'},properties:{birthDate:'1985-06-02'}},
    {id:'e:acme',kind:'entity',name:'Acme Research',description:'A fictional research organization in Switzerland.',type:'sys:Organization',layer:'base',ids:{registry:'CH-101'},properties:{registryCountry:'CH'}},
    {id:'e:acme-us',kind:'entity',name:'Acme Research',description:'A separate fictional organization in the United States.',type:'sys:Organization',layer:'base',ids:{registry:'US-101'},properties:{registryCountry:'US'}},
    {id:'e:ikl',kind:'entity',name:'International Knowledge Laboratory',description:'A fictional research laboratory.',type:'sys:Organization',layer:'base',ids:{registry:'LAB-101'},properties:{registryCountry:'CH'}},
    {id:'e:appleorg',kind:'entity',name:'Apple',description:'A fictional organization called Apple in this benchmark.',type:'sys:Organization',layer:'base',ids:{registry:'O-APPLE'}},
    {id:'e:appleconcept',kind:'entity',name:'Apple',description:'The apple concept in this synthetic benchmark.',type:'sys:Concept',layer:'base',ids:{}},
    {id:'e:ana',kind:'entity',name:'Ana',description:'The person introduced in this session.',type:'sys:Person',layer:'session',ids:{},properties:{}},
    {id:'e:ioana',kind:'entity',name:'Ioana',description:'Another person introduced in this session.',type:'sys:Person',layer:'session',ids:{},properties:{}},
    {id:'e:sessionorg',kind:'entity',name:'Local Lab',description:'The organization introduced in this conversation.',type:'sys:Organization',layer:'session',ids:{}},
    {id:'e:cpp',kind:'entity',name:'C++',description:'The programming language.',type:'sys:Artifact',layer:'base',ids:{},properties:{caseSensitive:true}},
    {id:'e:csharp',kind:'entity',name:'C#',description:'A different programming language.',type:'sys:Artifact',layer:'base',ids:{},properties:{caseSensitive:true}},
    {id:'e:gene',kind:'entity',name:'AbC',description:'A case-sensitive synthetic identifier.',type:'sys:Concept',layer:'base',ids:{},properties:{caseSensitive:true}}
  ];
  const aliases=[
    {id:'a:stefan',kind:'alias',name:'Stefan Mueller',target:'e:stefan',targetKind:'entity',aliasKind:'spelling',status:'active'},
    {id:'a:bob',kind:'alias',name:'Bob',target:'e:robert',targetKind:'entity',aliasKind:'nickname',status:'active'},
    {id:'a:ikl',kind:'alias',name:'IKL',target:'e:ikl',targetKind:'entity',aliasKind:'acronym',status:'active'},
    {id:'a:unreviewed',kind:'alias',name:'UnknownAlias',target:'e:alex1',targetKind:'entity',aliasKind:'synonym',status:'candidate'}
  ];
  const mentions=[{id:'m:ana',kind:'mention',target:'e:ana',turn:10},{id:'m:org',kind:'mention',target:'e:sessionorg',turn:10}];
  const records=[...entities,...aliases,...mentions];
  const store={list:kind=>records.filter(r=>r.kind===kind),get:id=>records.find(r=>r.id===id)};
  return {store,records};
}
const person=(name,extra={})=>({name,description:'A person mentioned by the user.',type:'sys:Person',...extra});
const org=(name,extra={})=>({name,description:'An organization mentioned by the user.',type:'sys:Organization',...extra});
export const IDENTITY_CASES=[
  {id:'id-orcid',mention:person('S. Muller',{ids:{orcid:'0000-0001-2345-6789'}}),expect:'same',target:'e:stefan'},
  {id:'id-orcid-url',mention:person('Someone',{ids:{orcid:'https://orcid.org/0000-0001-2345-6789'}}),expect:'same',target:'e:stefan'},
  {id:'id-conflict-over-name',mention:person('Alex Stone',{ids:{registry:'P-999'}}),expect:'new'},
  {id:'id-versus-disjoint-type',mention:org('Totally New Label',{ids:{registry:'P-101'}}),expect:'uncertain'},
  {id:'person-homonym',mention:person('Alex Stone'),expect:'uncertain'},
  {id:'person-discriminator-1970',mention:person('Alex Stone',{properties:{birthDate:'1970-01-01'}}),expect:'same',target:'e:alex1'},
  {id:'person-discriminator-1990',mention:person('Alex Stone',{properties:{birthDate:'1990-01-01'}}),expect:'same',target:'e:alex2'},
  {id:'person-discriminator-affiliation',mention:person('Alex Stone',{properties:{affiliation:'North Lab'}}),expect:'uncertain'},
  {id:'person-description-only-not-enough',mention:person('Alex Stone',{description:'The person born in 1970 who works at North Lab.'}),expect:'uncertain'},
  {id:'surname-only',mention:person('Stone'),expect:'uncertain'},
  {id:'initials-only',mention:person('A. Stone'),expect:'uncertain'},
  {id:'initials-plus-birthdate',mention:person('A. Stone',{properties:{birthDate:'1970-01-01'}}),expect:'same',target:'e:alex1'},
  {id:'reordered-name-alone',mention:person('Stone, Alex'),expect:'uncertain'},
  {id:'reordered-plus-birthdate',mention:person('Stone, Alex',{properties:{birthDate:'1990-01-01'}}),expect:'same',target:'e:alex2'},
  {id:'honorific-plus-birthdate',mention:person('Dr. Alex Stone',{properties:{birthDate:'1970-01-01'}}),expect:'same',target:'e:alex1'},
  {id:'nickname-alone',mention:person('Bob'),expect:'uncertain'},
  {id:'nickname-plus-birthdate',mention:person('Bob',{properties:{birthDate:'1985-06-02'}}),expect:'same',target:'e:robert'},
  {id:'nickname-with-wrong-birthdate',mention:person('Bob',{properties:{birthDate:'2001-01-01'}}),expect:'new'},
  {id:'approved-transliteration',mention:person('Stefan Mueller'),expect:'same',target:'e:stefan'},
  {id:'diacritics-alone',mention:person('Stefan Muller'),expect:'uncertain'},
  {id:'diacritics-plus-birthdate',mention:person('Stefan Muller',{properties:{birthDate:'1980-01-02'}}),expect:'same',target:'e:stefan'},
  {id:'legacy-cedilla-alone',mention:person('Ştefan Müller'),expect:'uncertain'},
  {id:'typo-alone',mention:person('Robert Vle'),expect:'uncertain'},
  {id:'organization-homonym',mention:org('Acme Research'),expect:'uncertain'},
  {id:'organization-country-ch',mention:org('Acme Research',{properties:{registryCountry:'CH'}}),expect:'same',target:'e:acme'},
  {id:'organization-country-us',mention:org('Acme Research',{properties:{registryCountry:'US'}}),expect:'same',target:'e:acme-us'},
  {id:'organization-registry',mention:org('ACME',{ids:{registry:'CH-101'}}),expect:'same',target:'e:acme'},
  {id:'acronym-alone',mention:org('IKL'),expect:'uncertain'},
  {id:'acronym-plus-identifier',mention:org('IKL',{ids:{registry:'LAB-101'}}),expect:'same',target:'e:ikl'},
  {id:'polysemy-org',mention:org('Apple'),expect:'uncertain'},
  {id:'polysemy-concept',mention:{name:'Apple',description:'A concept',type:'sys:Concept'},expect:'same',target:'e:appleconcept'},
  {id:'polysemy-without-type',mention:{name:'Apple',description:'An unspecified referent'},expect:'uncertain'},
  {id:'scoped-person-name',mention:person('Ana'),expect:'same',target:'e:ana'},
  {id:'recent-typed-pronoun',mention:person('she'),turn:10,expect:'same',target:'e:ana'},
  {id:'recent-typed-organization',mention:org('this company'),turn:10,expect:'same',target:'e:sessionorg'},
  {id:'recent-untyped-pronoun',mention:{name:'it',description:'An unspecified recent referent'},turn:10,expect:'uncertain'},
  {id:'expired-pronoun',mention:person('she'),turn:20,expect:'uncertain'},
  {id:'role-title',mention:person('CEO'),expect:'uncertain'},
  {id:'unreviewed-alias',mention:person('UnknownAlias'),expect:'new'},
  {id:'mixed-script',mention:org('Aсme Research'),expect:'uncertain'},
  {id:'new-entity',mention:person('Zed Quill'),expect:'new'},
  {id:'punctuation-cpp',mention:{name:'C++',description:'Programming language',type:'sys:Artifact'},expect:'same',target:'e:cpp'},
  {id:'punctuation-csharp',mention:{name:'C#',description:'Programming language',type:'sys:Artifact'},expect:'same',target:'e:csharp'},
  {id:'case-sensitive-symbol',mention:{name:'abc',description:'Synthetic identifier',type:'sys:Concept'},expect:'new'}
];
