import test from 'node:test';import assert from 'node:assert/strict';
import {parseProgram,validateProgram,evaluateProgram} from '../src/language.mjs';
const run=code=>{const api={sum:a=>a.reduce((x,y)=>x+y,0),identity:x=>x};return evaluateProgram(validateProgram(parseProgram(code),Object.keys(api)),api);};
test('literal objects, single quotes, comments, arrays, nested calls',()=>assert.deepEqual(JSON.parse(JSON.stringify(run(`// test\nconst a = sum([2, 3]); return identity({answer:a, text:'ș\\u021bi', nested:[null,true,-2.5]});`))),{answer:5,text:'șți',nested:[null,true,-2.5]}));
test('trailing commas accepted',()=>assert.equal(run('return sum([1,2,]);'),3));
test('all code is parsed before execution',()=>{let effects=0;assert.throws(()=>{const ast=parseProgram('sum([1]); while(true) {}');evaluateProgram(ast,{sum:()=>effects++});});assert.equal(effects,0);});
const forbidden=[
 'return process.env;', 'return globalThis;', 'import fs from "node:fs";', 'return eval("1");',
 'return Function("return process")();', 'while(true) {}', 'for(;;) {}', 'const x = () => 1;',
 'return ({})["constructor"];', 'return `hello`;', 'return new Date();', 'let a=1;',
 'return {__proto__: {polluted:true}};', 'return {"\\u005f_proto__":1};', 'return {x:1,x:2};',
 'const a=1; const a=2; return a;', 'const sum=1; return sum;', 'return unknown;',
 'return sum(...[1,2]);', 'return sum([Infinity]);', 'return 1; sum([2]);', 'return 1e999;'
];
for(const code of forbidden)test(`reject: ${code}`,()=>assert.throws(()=>run(code)));
test('nesting budget',()=>assert.throws(()=>parseProgram(`return ${'['.repeat(40)}1${']'.repeat(40)};`),e=>e.code==='LIMIT'));
test('byte budget',()=>assert.throws(()=>parseProgram('return "'+'a'.repeat(66000)+'";'),e=>e.code==='LIMIT'));
test('execution budget',()=>assert.throws(()=>evaluateProgram(parseProgram('return sum([1,2,3]);'),{sum:()=>0},{budget:{remaining:1}}),e=>e.code==='LIMIT'));
test('reject async host operation',()=>assert.throws(()=>evaluateProgram(parseProgram('return tool();'),{tool:()=>Promise.resolve(1)}),e=>e.code==='ASYNC'));
