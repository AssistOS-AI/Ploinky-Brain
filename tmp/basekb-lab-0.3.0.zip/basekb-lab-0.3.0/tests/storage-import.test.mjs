import test from 'node:test';import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,writeFileSync} from 'node:fs';import {join} from 'node:path';
import {fixture,FAMILY_CODE,FAMILY_SOURCE} from './helpers.mjs';
import {Store,promote} from '../src/storage.mjs';import {Engine} from '../src/engine.mjs';
import {AutoFormaliser,parseNTriples,chunkText} from '../src/formaliser.mjs';
import {migrateV1ToV2} from '../migrations/001-v1-to-v2.mjs';
import {VERSION_SET} from '../src/versions.mjs';
const withKB=(name,fn)=>test(name,async()=>{const f=fixture();try{await fn(f);}finally{f.close();}});
withKB('BaseKB file remains byte-for-byte unchanged',({engine,base})=>{const bytes=readFileSync(base);engine.execute(FAMILY_CODE,{text:FAMILY_SOURCE});assert.deepEqual(readFileSync(base),bytes);});
withKB('fork isolates writes while retaining the base digest',({engine,store,dir})=>{engine.execute(FAMILY_CODE,{text:FAMILY_SOURCE});const before=store.snapshot(),child=store.fork(join(dir,'fork.sqlite'));try{new Engine(child).execute('return createEntity("Zed","A new person",{type:"Person"});');assert.equal(store.snapshot(),before);assert.equal(child.getMeta('baseDigest'),store.getMeta('baseDigest'));assert.notEqual(child.id,store.id);}finally{child.close();}});
withKB('session rejects a changed BaseKB digest',({base,dir})=>{const modified=join(dir,'other.sqlite');writeFileSync(modified,readFileSync(base));const first=new Store({basePath:modified,sessionPath:join(dir,'pin.sqlite')});first.close();const writable=new Store({sessionPath:modified,writableBase:true});writable.setMeta('modified','yes');writable.close();assert.throws(()=>new Store({basePath:modified,sessionPath:join(dir,'pin.sqlite')}),e=>e.code==='BASE_CHANGED');});
withKB('private promotion requires explicit consent',({engine,store,dir})=>{engine.execute(FAMILY_CODE,{text:FAMILY_SOURCE});const id=store.list('assertion').find(f=>f.relation==='sys:parentOf').id;assert.throws(()=>promote(store,join(dir,'newbase.sqlite'),[id],{reason:'Reviewed'}),e=>e.code==='PRIVACY');});
withKB('selected promotion carries dependencies into a new base',({engine,store,dir,base})=>{engine.execute(FAMILY_CODE,{text:FAMILY_SOURCE});const id=store.list('assertion').find(f=>f.relation==='sys:parentOf').id,bytes=readFileSync(base),output=join(dir,'newbase.sqlite');promote(store,output,[id],{reason:'Synthetic demonstration approved',includePrivate:true});assert.deepEqual(readFileSync(base),bytes);const view=new Store({basePath:output});try{assert(view.get(id));for(const a of view.get(id).args)assert(view.get(a));}finally{view.close();}});
withKB('JSON exchange ingest is atomic and preserves declared relation direction',({engine,store})=>{const data=JSON.parse(readFileSync(new URL('../examples/import.json',import.meta.url),'utf8'));new AutoFormaliser(engine).ingestExchange(data);assert.equal(store.list('entity').length,2);const r=engine.execute('return query({relation:"parentOf",args:["?p","?c"]});');assert.match(r.answer.text,/Ada/);assert.match(r.answer.text,/Eli/);});
withKB('bad exchange reference leaves no partial writes',({engine,store})=>{const data={format:'basekb-exchange-v1',entities:[{id:'a',name:'A',type:'Person'}],facts:[{relation:'parentOf',args:[{entity:'a'},{entity:'missing'}]}]};const before=store.snapshot();assert.throws(()=>new AutoFormaliser(engine).ingestExchange(data),e=>e.code==='IMPORT');assert.equal(store.snapshot(),before);});
withKB('N-Triples imports literals, language qualifiers and scoped blank nodes',({engine,store})=>{const text=readFileSync(new URL('../examples/import.nt',import.meta.url),'utf8');const r=new AutoFormaliser(engine).ingestNTriples(text,{batchSize:1});assert.equal(r.triples,4);assert.equal(store.list('entity').length,3);const facts=store.list('assertion').filter(f=>f.relation!=='sys:instanceOf');assert.equal(facts.length,4);assert(facts.some(f=>f.qualifiers.language==='en'));});

withKB('N-Triples IRI identity is evidence-bearing and reusable across separate imports',({engine,store})=>{
  const af=new AutoFormaliser(engine);
  af.ingestNTriples('<urn:person:alice> <urn:p:name> "Alice" .',{name:'rdf-a.nt'});
  af.ingestNTriples('<urn:person:alice> <urn:p:role> "Researcher" .',{name:'rdf-b.nt'});
  const matches=store.list('entity').filter(e=>e.ids?.iri==='urn:person:alice');
  assert.equal(matches.length,1);
  assert.equal(matches[0].identityEvidence?.ids?.iri?.trusted,true);
  assert.match(matches[0].identityEvidence.ids.iri.evidence.quote,/urn:person:alice/);
});
test('N-Triples rejects malformed input rather than skipping it',()=>assert.throws(()=>parseNTriples('<x> <p> "unterminated .'),e=>e.code==='NTRIPLES'));
test('N-Triples preserves literal escapes',()=>assert.equal(parseNTriples('<x> <p> "line\\nnext" .')[0].object.literal,'line\nnext'));
test('chunk offsets reconstruct exact Unicode source text',()=>{const text=('ș🙂 paragraph. '.repeat(100));const chunks=chunkText(text,{maxChars:101});assert.equal(chunks.map(c=>c.text).join(''),text);for(const c of chunks)assert.equal(c.text,text.slice(c.start,c.end));});
withKB('imported executable content stays inactive',({engine,dir,store})=>{const otherPath=join(dir,'foreign.sqlite'),other=new Store({sessionPath:otherPath,writableBase:true});other.put({id:'foreign:fn',kind:'function',name:'foreignFunction',description:'Unreviewed foreign code',code:'return 42;',codeHash:'untrusted',status:'active',inputSchema:{},outputSchema:{}});other.close();new AutoFormaliser(engine).importBase(otherPath);const f=store.list('function').find(r=>r.name==='foreignFunction');assert.equal(f.status,'candidate');assert.throws(()=>engine.execute('return call("foreignFunction",null);'),e=>e.code==='FUNCTION');});
withKB('conflicting imported ID is namespaced, never mapped onto local identity',({engine,dir,store})=>{store.put({id:'collision',kind:'entity',name:'Original',type:'sys:Person',description:'Original referent',ids:{}});const otherPath=join(dir,'foreign.sqlite'),other=new Store({sessionPath:otherPath,writableBase:true});other.put({id:'collision',kind:'entity',name:'Different',type:'sys:Person',description:'Different referent',ids:{}});other.close();new AutoFormaliser(engine).importBase(otherPath);assert.equal(store.get('collision').name,'Original');assert(store.list('entity').some(r=>r.name==='Different' && r.id!=='collision'));});
withKB('unreviewed relation metadata cannot be promoted as reviewed knowledge',({engine,store,dir})=>{const r=engine.execute('return createRelationType("candidateRelation","A relation awaiting review",{domains:["Person","Person"],transitive:true});');assert.throws(()=>promote(store,join(dir,'candidate-base.sqlite'),[r.answer.value],{reason:'Must be rejected',includePrivate:true}),e=>e.code==='POLICY');});
withKB('exchange imports must explicitly declare English internal semantics',({engine,store})=>{
  const before=store.snapshot();
  assert.throws(()=>new AutoFormaliser(engine).ingestExchange({format:'basekb-exchange-v2',entities:[],facts:[]}),e=>e.code==='IMPORT');
  assert.equal(store.snapshot(),before);
});
withKB('v1 migration cannot silently certify non-English semantics',({dir})=>{
  const path=join(dir,'legacy-v1.sqlite'),db=new DatabaseSync(path);
  try{
    db.exec('CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL); CREATE TABLE records(id TEXT PRIMARY KEY,kind TEXT NOT NULL,name TEXT NOT NULL,data TEXT NOT NULL,created_at TEXT NOT NULL);');
    db.prepare('INSERT INTO meta VALUES(?,?)').run('schemaVersion','1');
    db.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run('legacy:alias','alias','părinte al',JSON.stringify({target:'sys:parentOf',targetKind:'relation',status:'active'}),new Date(0).toISOString());
    db.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run('legacy:entity','entity','Alex Stone',JSON.stringify({description:'A reviewed English description.',type:'sys:Person',ids:{orcid:'0000-0001-2345-6789'},properties:{birthDate:'1970-01-01'}}),new Date(0).toISOString());
    assert.throws(()=>migrateV1ToV2(db,VERSION_SET),e=>e.code==='MIGRATE_LANGUAGE');
    assert.equal(db.prepare("SELECT value FROM meta WHERE key='schemaVersion'").get().value,'1');
    migrateV1ToV2(db,VERSION_SET,{assumeEnglish:true,cleanupLegacyBootstrap:true});
    assert.equal(db.prepare("SELECT value FROM meta WHERE key='schemaVersion'").get().value,'2');
    assert.equal(db.prepare("SELECT value FROM meta WHERE key='internalLanguage'").get().value,'en');
    assert.equal(db.prepare("SELECT count(*) n FROM records WHERE id='legacy:alias'").get().n,0);
    const migrated=JSON.parse(db.prepare("SELECT data FROM records WHERE id='legacy:entity'").get().data);
    assert.equal(migrated.identityEvidence.ids.orcid.trusted,false);assert.equal(migrated.identityEvidence.properties.birthDate.trusted,false);
  } finally {db.close();}
});
test('N-Triples rejects explicitly non-English semantic literals in the English-core store',()=>{
  const f=fixture();try{
    assert.throws(()=>new AutoFormaliser(f.engine).ingestNTriples('<urn:a> <urn:label> "salut"@ro .'),e=>e.code==='IMPORT_LANGUAGE');
  } finally {f.close();}
});
