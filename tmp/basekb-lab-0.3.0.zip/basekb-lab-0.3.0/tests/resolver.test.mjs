import test from 'node:test';import assert from 'node:assert/strict';
import {Resolver,normalise,relationKey,isTheSame,mentionKey} from '../src/resolver.mjs';
import {identityFixture,IDENTITY_CASES} from '../eval/identity-fixture.mjs';
for(const c of IDENTITY_CASES)test(`identity: ${c.id}`,()=>{
  const {store}=identityFixture();const r=new Resolver(store);
  let outcome;try{outcome=r.resolveEntity(c.mention,{turn:c.turn ?? 10});}catch(e){assert.equal(e.code,'AMBIGUOUS');outcome={decision:'uncertain'};}
  assert.equal(outcome.decision,c.expect);if(c.target)assert.equal(outcome.target,c.target);
});
test('normalization preserves C++, C# and meaningful punctuation',()=>{assert.notEqual(normalise('C++'),normalise('C#'));assert.equal(relationKey('worksAt'),relationKey('works_at'));});
test('human confirmation cannot override a hard ID conflict',()=>{const {store}=identityFixture();const mention={name:'Alex Stone',description:'A person',type:'sys:Person',ids:{registry:'P-102'}};
assert.throws(()=>new Resolver(store).resolveEntity(mention,{bindings:{[mentionKey(mention)]:'e:alex1'}}),e=>e.code==='AMBIGUOUS');});
test('human selection supports an explicit distinct referent',()=>{const {store}=identityFixture(),m={name:'Alex Stone',description:'Another Alex',type:'sys:Person'};assert.equal(new Resolver(store).resolveEntity(m,{bindings:{[mentionKey(m)]:'__new__'}}).decision,'new');});
test('several recent compatible referents require clarification',()=>{const {store,records}=identityFixture();records.push({id:'m:other',kind:'mention',target:'e:ioana',turn:10});assert.throws(()=>new Resolver(store).resolveEntity({name:'she',description:'The recently mentioned person',type:'sys:Person'},{turn:10}),e=>e.code==='AMBIGUOUS');});
test('hard blockers dominate multiple positive features',()=>{const {store}=identityFixture();const r=isTheSame({name:'Alex Stone',description:'Same description',type:'sys:Person',ids:{registry:'P-999'},properties:{birthDate:'1970-01-01'}},store.get('e:alex1'));assert.equal(r.decision,'different');assert(!r.strong);});
test('same organization label is not identity proof and trusted jurisdiction can block a false merge',()=>{
  const store={list(kind){if(kind==='entity')return [{id:'org:ch',kind:'entity',name:'Acme',description:'Acme organization in Switzerland.',type:'sys:Organization',ids:{},properties:{registryCountry:'CH'},layer:'base'}];return [];}};
  const resolver=new Resolver(store);
  assert.throws(()=>resolver.resolveEntity({name:'Acme',description:'An organization mentioned in the source.',type:'sys:Organization',ids:{},properties:{},identityEvidence:{ids:{},properties:{}}}),e=>e.code==='AMBIGUOUS');
  const mismatch=resolver.resolveEntity({name:'Acme',description:'Acme organization registered in the United States.',type:'sys:Organization',ids:{},properties:{registryCountry:'US'},identityEvidence:{ids:{},properties:{registryCountry:{trusted:true}}}});
  assert.equal(mismatch.decision,'new');
});
test('identity anchors require trusted evidence on both the new mention and stored entity',()=>{
  const trusted={name:'Alex Stone',description:'A researcher.',type:'sys:Person',ids:{orcid:'0000-0001-2345-6789'},properties:{birthDate:'1970-01-01'},identityEvidence:{ids:{orcid:{trusted:true}},properties:{birthDate:{trusted:true}}}};
  const untrustedStored={id:'e:raw',kind:'entity',name:'Alex Stone',description:'A researcher.',type:'sys:Person',ids:{orcid:'0000-0001-2345-6789'},properties:{birthDate:'1970-01-01'},identityEvidence:{ids:{orcid:{trusted:false}},properties:{birthDate:{trusted:false}}}};
  const r=isTheSame(trusted,untrustedStored);assert.equal(r.decision,'uncertain');assert.equal(r.anchors.length,0);assert(r.features.some(f=>f.name.startsWith('untrusted_identifier_match:')));
  const conflicting={...untrustedStored,ids:{orcid:'9999-9999-9999-9999'}};const c=isTheSame(trusted,conflicting);assert.equal(c.decision,'uncertain');assert(!c.blockers.some(b=>b.startsWith('identifier_conflict')));
});
