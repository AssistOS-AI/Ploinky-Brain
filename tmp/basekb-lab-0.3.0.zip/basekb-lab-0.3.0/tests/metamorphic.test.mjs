import test from 'node:test';import assert from 'node:assert/strict';
import {closure,unify} from '../src/rules.mjs';
function rng(seed){return()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};}
for(let seed=0;seed<8;seed++)test(`independent reachability oracle, seed ${seed}`,()=>{
 const r=rng(seed),n=10,edges=[];for(let a=0;a<n;a++)for(let b=0;b<n;b++)if(r()<.11)edges.push([String(a),String(b)]);
 const facts=edges.map((args,i)=>({id:`f${i}`,relation:'edge',args,polarity:1,context:'actual',validFrom:null,validTo:null,status:'accepted',qualifiers:{}}));
 const rules=[{id:'r1',name:'base',status:'active',body:[{relation:'edge',args:['?x','?y']}],head:{relation:'path',args:['?x','?y']}},{id:'r2',name:'step',status:'active',body:[{relation:'path',args:['?x','?y']},{relation:'edge',args:['?y','?z']}],head:{relation:'path',args:['?x','?z']}}];
 const inferred=new Set(closure(facts,rules,{comparisons:1_000_000}).facts.filter(f=>f.relation==='path').map(f=>f.args.join(',')));
 const expected=new Set();for(let a=0;a<n;a++){const seen=new Set(),queue=edges.filter(e=>e[0]===String(a)).map(e=>e[1]);while(queue.length){const b=queue.shift();if(seen.has(b))continue;seen.add(b);expected.add(`${a},${b}`);for(const e of edges)if(e[0]===b)queue.push(e[1]);}}
 assert.deepEqual(inferred,expected);
 const reversed=closure([...facts].reverse(),[...rules].reverse(),{comparisons:1_000_000});assert.deepEqual(new Set(reversed.facts.filter(f=>f.relation==='path').map(f=>f.args.join(','))),expected);
});
test('repeated variables enforce equality within an atom',()=>{assert.equal(unify({relation:'r',args:['?x','?x']},{relation:'r',args:['a','b'],polarity:1}),null);assert.deepEqual(unify({relation:'r',args:['?x','?x']},{relation:'r',args:['a','a'],polarity:1}),{'?x':'a'});});
