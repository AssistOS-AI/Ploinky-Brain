import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers.mjs';
import { Engine } from '../src/engine.mjs';
import { mentionKey } from '../src/resolver.mjs';
import { buildIdentityProfile } from '../src/identity-profile.mjs';
import { VERSION_SET } from '../src/versions.mjs';

const withKB=(name,fn)=>test(name,async()=>{const f=fixture();try{await fn(f);}finally{f.close();}});

withKB('trusted identity evidence accumulates non-destructively across active resolutions',({engine,store})=>{
  const first=engine.execute('return createEntity("Alex Stone","Alex Stone, a person introduced in the source.",{type:"Person",evidence:sourceSpan("Alex Stone is a person.")});',{text:'Alex Stone is a person.'});
  const id=first.answer.value;
  const second=engine.execute('return createEntity("Alex Stone","Alex Stone, the same recently discussed person, with an explicit date of birth.",{type:"Person",properties:{birthDate:claim("1970-01-01",sourceSpan("born on 1970-01-01"))},evidence:sourceSpan("Alex Stone was born on 1970-01-01.")});',{text:'Alex Stone was born on 1970-01-01.'});
  assert.equal(second.answer.value,id);
  const stored=store.get(id);assert.equal(stored.properties.birthDate,undefined,'canonical entity row is not destructively enriched');
  const profile=buildIdentityProfile(store,id);assert.equal(profile.resolved.properties.birthDate,'1970-01-01');assert(profile.evidence.properties.birthDate.trusted);assert(profile.evidence.properties.birthDate.claimCount>=1);
  const later={name:'A. Stone',description:'A person mentioned much later.',type:'sys:Person',ids:{},properties:{birthDate:'1970-01-01'},identityEvidence:{ids:{},properties:{birthDate:{trusted:true}}}};
  const resolved=engine.resolver.resolveEntity(later,{turn:100});assert.equal(resolved.decision,'same');assert.equal(resolved.target,id);
});

withKB('resolution rebinding rewrites only dependency-tracked assertions and moves identity evidence',({engine,store})=>{
  store.put({id:'person:a',kind:'entity',name:'Alex Stone',description:'First candidate person.',type:'sys:Person',ids:{},properties:{},identityEvidence:{ids:{},properties:{}},status:'session'});
  store.put({id:'person:b',kind:'entity',name:'Alex Stone',description:'Second candidate person.',type:'sys:Person',ids:{},properties:{},identityEvidence:{ids:{},properties:{}},status:'session'});
  const source='Alex Stone, born on 1970-01-01, is parent of Bea.';
  const description='Alex Stone, the person in the statement.';
  const key=mentionKey({name:'Alex Stone',description,type:'sys:Person'});
  const code=`const alex=createEntity("Alex Stone",${JSON.stringify(description)},{type:"Person",properties:{birthDate:claim("1970-01-01",sourceSpan("born on 1970-01-01"))},evidence:sourceSpan(${JSON.stringify(source)})});\nconst bea=createEntity("Bea","Bea, the child mentioned in the statement.",{type:"Person",evidence:sourceSpan(${JSON.stringify(source)})});\ncreateFact("parentOf",[alex,bea],{evidence:sourceSpan(${JSON.stringify(source)})});\nreturn alex;`;
  const run=engine.execute(code,{text:source,bindings:{[key]:'person:a'}});assert.equal(run.answer.value,'person:a');
  const oldResolution=run.resolutions.find(r=>r.target==='person:a');assert(oldResolution);
  const oldFact=store.list('assertion').find(f=>f.relation==='sys:parentOf'&&f.args[0]==='person:a');assert(oldFact?.identityDependencies?.some(d=>d.resolutionId===oldResolution.id));
  assert.equal(buildIdentityProfile(store,'person:a').resolved.properties.birthDate,'1970-01-01');
  const correction=engine.rebindResolution(oldResolution.id,'person:b','The operator confirmed that this mention referred to the second Alex Stone.');
  assert.equal(correction.oldTarget,'person:a');assert.equal(correction.newTarget,'person:b');assert.equal(correction.rewritten.length,1);
  assert.equal(store.get(oldFact.id),null);assert(store.get(oldFact.id,{includeMasked:true}));
  const newFact=store.list('assertion').find(f=>f.reboundFrom===oldFact.id);assert(newFact);assert.equal(newFact.args[0],'person:b');assert(newFact.identityDependencies.some(d=>d.resolutionId===correction.to));
  assert.equal(buildIdentityProfile(store,'person:a').resolved.properties.birthDate,undefined);
  assert.equal(buildIdentityProfile(store,'person:b').resolved.properties.birthDate,'1970-01-01');
  const oldTruth=engine.execute('return query({relation:"parentOf",args:[ref("person:a"),"?child"]});').answer.value.total;
  const newTruth=engine.execute('return query({relation:"parentOf",args:[ref("person:b"),"?child"]});').answer.value.total;
  assert.equal(oldTruth,0);assert.equal(newTruth,1);
});

withKB('rebinding fails closed when legacy same-source assertions lack identity dependency metadata',({engine,store})=>{
  store.put({id:'person:a',kind:'entity',name:'Alex Stone',description:'First candidate.',type:'sys:Person',ids:{},properties:{},status:'session'});
  store.put({id:'person:b',kind:'entity',name:'Alex Stone',description:'Second candidate.',type:'sys:Person',ids:{},properties:{},status:'session'});
  const source='Alex Stone is parent of Bea.',description='Alex Stone, the person in the statement.';
  const key=mentionKey({name:'Alex Stone',description,type:'sys:Person'});
  const run=engine.execute(`const a=createEntity("Alex Stone",${JSON.stringify(description)},{type:"Person",evidence:sourceSpan(${JSON.stringify(source)})});const b=createEntity("Bea","Bea, a person.",{type:"Person",evidence:sourceSpan(${JSON.stringify(source)})});createFact("parentOf",[a,b],{evidence:sourceSpan(${JSON.stringify(source)})});return a;`,{text:source,bindings:{[key]:'person:a'}});
  const resolution=run.resolutions.find(r=>r.target==='person:a'),fact=store.list('assertion').find(f=>f.relation==='sys:parentOf'&&f.args[0]==='person:a');
  const {identityDependencies,...legacy}=fact;store.put(legacy,{replace:true});
  assert.throws(()=>engine.rebindResolution(resolution.id,'person:b','Legacy correction'),e=>e.code==='REPLAY_UNTRACKED');
  assert.equal(store.get(fact.id).args[0],'person:a');
});

withKB('execution records preserve runtime versions while store creation metadata is not silently rewritten',({store})=>{
  store.setMeta('resolverPolicyVersion','legacy-policy-marker');
  const engine=new Engine(store);assert.equal(store.getMeta('resolverPolicyVersion'),'legacy-policy-marker');
  const r=engine.execute('return call("sum",[1,2]);');assert.equal(r.versions.resolverPolicyVersion,VERSION_SET.resolverPolicyVersion);
  const record=store.get(r.executionId);assert.equal(record.kind,'execution');assert.equal(record.irHash,r.irHash);assert.equal(record.versions.resolverPolicyVersion,VERSION_SET.resolverPolicyVersion);assert.equal(store.getMeta('resolverPolicyVersion'),'legacy-policy-marker');
});

withKB('event audit chain verifies clean history and detects tampering',({engine,store})=>{
  engine.execute('return call("sum",[2,3]);');engine.execute('return call("multiply",[2,4]);');
  const clean=store.verifyAuditChain();assert(clean.ok);assert(clean.audited>=2);assert.match(clean.headHash,/^[a-f0-9]{64}$/);
  const row=store.db.prepare('SELECT seq,data FROM events ORDER BY seq LIMIT 1').get(),data=JSON.parse(row.data);data.tampered=true;
  store.db.prepare('UPDATE events SET data=? WHERE seq=?').run(JSON.stringify(data),row.seq);
  const broken=store.verifyAuditChain();assert.equal(broken.ok,false);assert(broken.errors.some(e=>e.kind==='event_hash_mismatch'||e.kind==='previous_hash_mismatch'));
});

withKB('trusted standard identifiers are format validated before they can become identity anchors',({engine})=>{
  const source='Alex Stone has ORCID 0000-0001-2345-6780.';
  assert.throws(()=>engine.execute('return createEntity("Alex Stone","Alex Stone, a researcher in the source.",{type:"Person",ids:{orcid:claim("0000-0001-2345-6780",sourceSpan("ORCID 0000-0001-2345-6780"))},evidence:sourceSpan("Alex Stone has ORCID 0000-0001-2345-6780.")});',{text:source}),e=>e.code==='IDENTIFIER_FORMAT');
});

withKB('retrieved LLM context sees active derived identity properties but not orphaned entities',async({engine,store})=>{
  const {retrievedContext}=await import('../src/llm.mjs');
  const first=engine.execute('return createEntity("Alex Stone","Alex Stone, a person introduced in the source.",{type:"Person",evidence:sourceSpan("Alex Stone is a person.")});',{text:'Alex Stone is a person.'}),id=first.answer.value;
  engine.execute('return createEntity("Alex Stone","Alex Stone, the same recently discussed person.",{type:"Person",properties:{birthDate:claim("1970-01-01",sourceSpan("born on 1970-01-01"))},evidence:sourceSpan("Alex Stone was born on 1970-01-01.")});',{text:'Alex Stone was born on 1970-01-01.'});
  const ctx=retrievedContext(store,'Alex Stone birth date');const entry=ctx.entities.find(e=>e.id===id);assert(entry);assert.equal(entry.properties.birthDate,'1970-01-01');
});
