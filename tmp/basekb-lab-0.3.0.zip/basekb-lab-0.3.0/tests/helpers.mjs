import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Store } from '../src/storage.mjs';
import { Engine } from '../src/engine.mjs';
import { createBase } from '../src/seed.mjs';
export function fixture(options={}) {
  const dir=mkdtempSync(join(tmpdir(),'basekb-')); const base=join(dir,'base.sqlite');createBase(base);
  const store=new Store({basePath:base,sessionPath:join(dir,'session.sqlite')});const engine=new Engine(store,options);
  return {dir,base,store,engine,close(){store.close();rmSync(dir,{recursive:true,force:true});}};
}
export const FAMILY_SOURCE='Ion este părintele Mariei. Maria este părintele Anei.';
export const FAMILY_CODE=`const ion = createEntity("Ion", "Ion, the parent of Maria mentioned in the source.", {type:"Person"});
const maria = createEntity("Maria", "Maria, the parent of Ana mentioned in the source.", {type:"Person"});
const ana = createEntity("Ana", "Ana, the child of Maria mentioned in the source.", {type:"Person"});
createFact("parentOf", [ion, maria], {evidence:sourceSpan("Ion este părintele Mariei.")});
createFact("parentOf", [maria, ana], {evidence:sourceSpan("Maria este părintele Anei.")});
return respond(query({relation:"grandparentOf",args:["?grandparent",ana]}));`;
