# BaseKB Lab 0.3.0

BaseKB Lab is a local-first prototype for an **executable symbolic knowledge environment**. A local LLM is used primarily as a semantic compiler/planner: it converts user language into a restricted Knowledge Program. The deterministic KB runtime resolves identity, executes approved capabilities, applies rules and constraints, records provenance, and renders a structured answer.

The design is intentionally not a RAG wrapper and not an arbitrary JavaScript agent. Model-generated text is parsed into a small JS-like DSL, converted to a versioned Knowledge IR, validated, dry-run, and only then executed transactionally.

## Architectural rule: English inside, multilingual at the boundary

All canonical semantic representation is English:

- contextual entity descriptions;
- entity/type/relation names when they are semantic labels rather than proper names;
- relation roles;
- rules, constraints and function descriptions;
- Knowledge Programs and canonical Knowledge IR;
- clarification messages and internal answers.

Proper names and identifiers keep their canonical spelling. Raw source text is also retained exactly in its original language **only for provenance and exact quotations**. For a Romanian input, for example:

```text
Romanian source
   -> local LLM semantic normalization to English
   -> English Knowledge Program / IR
   -> KB-VM, inference, constraints, provenance
   -> English canonical AnswerObject
   -> optional local LLM presentation translation back to Romanian
```

This separation lets the symbolic kernel operate in one semantic language while preserving auditable evidence from the source.

## Quick start: deterministic demo, no model

Requirements: Node.js >= 22.16.0. There are no npm dependencies.

```bash
unzip basekb-lab-0.3.0.zip
cd basekb-lab-0.3.0
npm run verify
npm run demo
```

Open `http://127.0.0.1:3000` and try the controlled-language examples shown in the UI. The demo is intentionally limited and does **not** pretend to be a multilingual formalizer.

## Local LLM

The default adapter uses an OpenAI-compatible local endpoint and defaults to:

```text
LLM_BASE_URL=http://127.0.0.1:11434/v1
LLM_MODEL=qwen3-coder:30b
```

A convenient Ollama launcher is included:

```bash
node scripts/start-model.mjs --provider ollama --model qwen3-coder:30b --pull
```

Then, in another terminal:

```bash
npm start
```

The model weights are deliberately **not** bundled in the archive. Downloading weights is an explicit operator action. A `llama.cpp` server is also supported; any local OpenAI-compatible endpoint can be configured through environment variables.

After starting the model:

```bash
npm run doctor
npm run smoke:local
npm run eval:llm
```

See `docs/guides/DGX_SPARK.md` and `docs/specs/12-local-model-runtime.md`.

## Main concepts

- **BaseKB**: immutable-ish durable SQLite knowledge substrate opened read-only during sessions.
- **SessionKB**: a copy-on-write SQLite overlay containing conversational/candidate knowledge.
- **AutoFormaliser**: adapters for existing BaseKBs, BaseKB exchange JSON, strict N-Triples, and text via a local model.
- **BaseLLM**: semantic normalizer, Knowledge Program compiler/planner, optional identity adviser, and presentation translator.
- **Knowledge Program**: restricted JS-like surface language.
- **Knowledge IR**: versioned canonical form of a parsed program.
- **KB-VM / Engine**: trusted executor with transactions, budgets, provenance, rules, constraints and approved functions.
- **Resolver**: conservative entity and relation identity resolution.
- **ResolutionDecision**: first-class, supersedable record connecting a mention to an entity and explaining why.
- **IdentityProfile**: non-destructive derived view of active trusted identity evidence accumulated across resolutions.
- **ExecutionRecord**: first-class replay/audit metadata for every committed Knowledge Program.

## Identity policy

Name similarity is retrieval evidence, **not identity proof**. Exact spelling, diacritic variants, initials, acronyms, fuzzy matches and nicknames are primarily candidate generators. Auto-linking requires an independent anchor such as a trusted identifier, an evidence-bearing hard discriminator, an approved strong alias, or tightly scoped recent context. Hard conflicts veto a merge.

Identity-sensitive properties can carry field-level evidence:

```javascript
const alex = createEntity(
  "Alex Stone",
  "Alex Stone, the person described in the source.",
  {
    type: "Person",
    properties: {
      birthDate: claim("1970-01-01", sourceSpan("Alex Stone was born on 1970-01-01."))
    },
    evidence: sourceSpan("Alex Stone was born on 1970-01-01.")
  }
);
```

A raw `birthDate:"1970-01-01"` may be stored but is not trusted as an automatic identity anchor.


## Identity correction and audit

Release 0.3 adds a reversible correction path without destructive entity union. New assertions record which `ResolutionDecision` supplied each entity argument. An operator can inspect accumulated identity evidence and supersede a wrong resolution:

```bash
node src/cli.mjs identity-profile entity:...
node src/cli.mjs rebind-resolution resolution:... entity:... --reason "Reviewed correction"
node src/cli.mjs audit
```

Rebinding rewrites only local directly asserted facts whose identity dependency is explicit; derived facts are recomputed. If an older/legacy fact references the old target but lacks dependency metadata, the operation fails closed with `REPLAY_UNTRACKED` instead of silently producing a partial correction. Superseded resolutions remain available for audit and no longer contribute trusted evidence to the active identity profile.

Session events are hash-linked. `audit` detects subsequent modifications to audited event rows, but it is not a digital signature or an external timestamp: a privileged process that can rewrite the entire SQLite file and recompute the chain remains in the trusted computing base.

## Repository layout

```text
src/                runtime, storage, resolver, parser, rules, LLM boundary
migrations/         explicit schema migrations
scripts/            init, checks, evals, local-model launch and smoke tests
tests/              deterministic regression suite
eval/               identity and local-model diagnostics
docs/specs/         normative architecture/specification documents
docs/guides/         operational guides
examples/            minimal programs/import formats
public/              local chat UI
data/base.sqlite     seeded BaseKB generated for this release
AGENTS.md            non-negotiable contract for coding agents
```

## Verification

```bash
npm run check       # syntax checks
npm test            # deterministic tests; no network/model required
npm run eval        # identity-policy evaluation and ablations
npm run verify      # regenerate release reports: syntax + tests + deterministic eval + environment
```

The release archive contains generated test/evaluation reports. Release 0.3.0 has 166 deterministic regression tests at build time, including identity-profile/rebinding and audit-chain cases. Local-model evaluation is intentionally reported as `not_run` unless a local endpoint was actually available.

## Security stance

The raw user source, imported documents and model output are untrusted. The model never receives shell/filesystem/network capabilities through the Knowledge Program language. Candidate rules/functions/constraints do not activate themselves. BaseKB is not mutated by ordinary chat. Clarification and failed executions roll back semantic writes. See `docs/specs/07-security.md` and `docs/specs/13-risks.md`.

## Important limitation

A syntactically valid, source-grounded Knowledge Program is **not proof that natural-language meaning was formalized correctly**. Translation/formalization fidelity remains the central research problem and must be evaluated independently of the deterministic kernel.
