const subtotal = call("sum", [17, 23, 42]);
const doubled = call("double", subtotal);
return respond(doubled);
