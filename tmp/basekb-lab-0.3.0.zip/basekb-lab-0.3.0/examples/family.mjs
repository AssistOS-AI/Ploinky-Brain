const ion = createEntity("Ion", "Ion, the parent of Maria mentioned in the source.", {type:"Person"});
const maria = createEntity("Maria", "Maria, the parent of Ana mentioned in the source.", {type:"Person"});
const ana = createEntity("Ana", "Ana, the child of Maria mentioned in the source.", {type:"Person"});
createFact("parentOf", [ion, maria], {evidence:sourceSpan("Ion este părintele Mariei.")});
createFact("parentOf", [maria, ana], {evidence:sourceSpan("Maria este părintele Anei.")});
return respond(query({relation:"grandparentOf",args:["?grandparent",ana]}));
