import { hash, canonical, KBError } from './util.mjs';
import { RESOLVER_POLICY_VERSION } from './versions.mjs';
import { buildIdentityProfiles, applyIdentityProfile, effectiveMentionTarget } from './identity-profile.mjs';

/** Safe key for retrieval; NEVER proof of identity. Preserve C++, C#, units and case-sensitive identifiers. */
export function normalise(text) {
  return String(text).normalize('NFKC').replace(/[şŞţŢ]/g, c => ({ ş:'ș', Ş:'Ș', ţ:'ț', Ţ:'Ț' })[c])
    .replace(/[’‘]/g, "'").replace(/[‐‑–—]/g, '-').replace(/\s+/gu, ' ').trim().toLocaleLowerCase('und');
}
export const folded = text => normalise(text).normalize('NFD').replace(/\p{M}/gu, '');
export const relationKey = text => normalise(String(text).replace(/([a-z])([A-Z])/g, '$1 $2')).replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
export const words = text => new Set(folded(text).match(/[\p{L}\p{N}]+/gu) ?? []);
export function mixedScript(text) { return /\p{Script=Latin}/u.test(text) && /[\p{Script=Cyrillic}\p{Script=Greek}]/u.test(text); }
function jaccard(a,b){const x=words(a),y=words(b),u=new Set([...x,...y]);return u.size?[...x].filter(t=>y.has(t)).length/u.size:0;}
function personNameKey(s){s=folded(s).replace(/^(?:dr|prof|mr|mrs|ms)\.?\s+/,'');if(s.includes(',')){const [last,first]=s.split(',').map(x=>x.trim());if(first)s=`${first} ${last}`;}return s.replace(/[.]/g,'').replace(/\s+/g,' ').trim();}
function initialsCompatible(a,b){const x=personNameKey(a).split(' '),y=personNameKey(b).split(' ');return x.length>=2&&x.length===y.length&&x.at(-1)===y.at(-1)&&x.every((v,i)=>v===y[i]||(v.length===1&&y[i].startsWith(v))||(y[i].length===1&&v.startsWith(y[i])));}
function acronym(s){return [...words(s)].filter(w=>!['of','the','and'].includes(w)).map(w=>w[0]).join('');}
function bigrams(s){s=folded(s);return new Set(Array.from({length:Math.max(0,s.length-1)},(_,i)=>s.slice(i,i+2)));}
function dice(a,b){const x=bigrams(a),y=bigrams(b);return x.size+y.size?2*[...x].filter(v=>y.has(v)).length/(x.size+y.size):0;}

const SHORT_ROLES=new Set(['ceo','cto','director','manager','doctor','professor']);
// Input normalization should translate pronouns to English before semantic resolution.
const ANAPHORS=new Set(['he','she','it','they','this company','that company','this person','that person','the former','the latter']);
const ID_NAMESPACES=new Set(['orcid','doi','wikidata','isbn','registry','external','iri']);
const HARD_DISCRIMINATORS=new Set(['birthDate','registryCountry','parentOrganization','version']);
const SOFT_DISCRIMINATORS=new Set(['affiliation','country','city']);

export function normaliseID(ns,value){const raw=String(value).trim();if(ns==='doi')return raw.replace(/^https?:\/\/(?:dx\.)?doi\.org\//i,'').toLowerCase();if(ns==='orcid')return raw.replace(/^https?:\/\/orcid\.org\//i,'').toUpperCase();if(ns==='isbn')return raw.replace(/[\s-]/g,'');if(ns==='wikidata')return raw.replace(/^https?:\/\/www\.wikidata\.org\/entity\//i,'').toUpperCase();return raw;}
export function identifierWellFormed(ns,value){
  const v=normaliseID(ns,value);if(typeof value!=='string'||!v||v.length>500)return false;
  if(ns==='orcid'){const d=v.replace(/-/g,'');if(!/^\d{15}[\dX]$/.test(d))return false;let total=0;for(const c of d.slice(0,15))total=(total+Number(c))*2;const check=(12-(total%11))%11;return (check===10?'X':String(check))===d.at(-1);}
  if(ns==='doi')return /^10\.\d{4,9}\/\S+$/i.test(v);
  if(ns==='wikidata')return /^Q[1-9]\d*$/.test(v);
  if(ns==='isbn'){if(/^\d{13}$/.test(v)){const sum=[...v.slice(0,12)].reduce((a,c,i)=>a+Number(c)*(i%2?3:1),0);return (10-sum%10)%10===Number(v[12]);}if(/^\d{9}[\dX]$/.test(v)){const sum=[...v].reduce((a,c,i)=>a+(c==='X'?10:Number(c))*(10-i),0);return sum%11===0;}return false;}
  if(ns==='iri')return /^[A-Za-z][A-Za-z0-9+.-]*:[^\s]+$/.test(v);
  return true; // registry/external namespaces are authority-specific and validated by provenance/review.
}
export const mentionKey=mention=>hash({name:normalise(mention.name),description:mention.description,type:mention.type??null}).slice(0,24);
export class AmbiguityError extends KBError{constructor(mention,candidates,reason,extra={}){super('AMBIGUOUS',reason,{mention,mentionKey:mentionKey(mention),candidates,policyVersion:RESOLVER_POLICY_VERSION,...extra});}}
function bareType(type){return String(type??'').replace(/^sys:/,'');}
export function incompatibleTypes(a,b){a=bareType(a);b=bareType(b);const disjoint=['Person','Organization','Place','Concept','Artifact'];return a!==b&&disjoint.includes(a)&&disjoint.includes(b);}
function sameType(a,b){return a&&b&&a===b;}
function evidenceTrusted(mention,group,key){
  const map=mention.identityEvidence?.[group];
  // Direct Resolver callers are trusted test/operator inputs. Engine-created mentions always carry the map.
  if(!map)return true;
  return map[key]?.trusted===true;
}

export class Resolver{
  constructor(store,{recentWindow=2,minMargin=15,heuristics={}}={}){this.store=store;this.recentWindow=recentWindow;this.minMargin=minMargin;this.heuristics={aliases:true,folding:true,context:true,properties:true,fuzzy:true,...heuristics};this.policyVersion=RESOLVER_POLICY_VERSION;}
  compare(mention,entity,{recent=[],aliasesByTarget=null}={}){
    const features=[],blockers=[],anchors=[];let score=0,idMatch=false;
    const add=(name,weight,kind='support')=>{features.push({name,weight,kind});score+=weight;if(kind==='anchor')anchors.push(name);};
    if(incompatibleTypes(mention.type,entity.type))blockers.push('disjoint_types');
    for (const conflict of entity.identityProfile?.conflicts ?? []) if (conflict.hard) blockers.push(`stored_identity_conflict:${conflict.group}:${conflict.key}`);

    for(const [ns,value] of Object.entries(mention.ids??{})){
      if(entity.ids?.[ns]!=null){
        const leftTrusted=evidenceTrusted(mention,'ids',ns),rightTrusted=evidenceTrusted(entity,'ids',ns);
        if(leftTrusted&&ID_NAMESPACES.has(ns)&&!identifierWellFormed(ns,value))blockers.push(`invalid_identifier:${ns}:mention`);
        if(rightTrusted&&ID_NAMESPACES.has(ns)&&!identifierWellFormed(ns,entity.ids[ns]))blockers.push(`invalid_identifier:${ns}:stored`);
        if(normaliseID(ns,value)!==normaliseID(ns,entity.ids[ns])){
          if(leftTrusted&&rightTrusted)blockers.push(`identifier_conflict:${ns}`);
          else add(`untrusted_identifier_difference:${ns}`,-5,'candidate');
        } else if(ID_NAMESPACES.has(ns)){
          idMatch=true;
          if(leftTrusted&&rightTrusted)add(`identifier:${ns}`,120,'anchor');
          else add(`untrusted_identifier_match:${ns}`,20,'candidate');
        }
      }
    }

    const exact=normalise(mention.name)===normalise(entity.name),type=bareType(entity.type);
    const suspicious=mixedScript(mention.name)||/[\u200B-\u200F\u202A-\u202E\u2066-\u2069]/u.test(mention.name);
    if(suspicious)blockers.push('confusable_or_control_characters');
    if((entity.properties?.caseSensitive||mention.properties?.caseSensitive)&&mention.name!==entity.name)blockers.push('case_sensitive_label');
    if(exact)add('exact_label',45,'candidate');
    else if(this.heuristics.folding&&folded(mention.name)===folded(entity.name))add('diacritic_variant',25,'candidate');
    else if(this.heuristics.fuzzy&&dice(mention.name,entity.name)>=0.72)add('fuzzy_label',15,'candidate');

    if(!exact&&type==='Person'){
      if(personNameKey(mention.name)===personNameKey(entity.name))add('name_order_or_title_variant',25,'candidate');
      else if(initialsCompatible(mention.name,entity.name))add('initials_variant',20,'candidate');
      else if(personNameKey(entity.name).split(' ').at(-1)===personNameKey(mention.name))add('surname_only',15,'candidate');
    }
    if(!exact&&type==='Organization'&&folded(mention.name)===acronym(entity.name)&&mention.name.length>=2)add('generated_acronym',20,'candidate');

    const candidateAliases=this.heuristics.aliases?(aliasesByTarget?(aliasesByTarget.get(entity.id)??[]):this.store.list('alias').filter(a=>a.target===entity.id&&a.status==='active')):[];
    const aliases=candidateAliases.filter(a=>normalise(a.name)===normalise(mention.name));
    for(const alias of aliases){
      if(alias.aliasKind==='nickname'||alias.aliasKind==='acronym')add(`weak_alias:${alias.aliasKind}`,25,'candidate');
      else add(`approved_alias:${alias.aliasKind??'equivalent'}`,60,'anchor');
    }

    const descriptionSimilarity=jaccard(mention.description??'',entity.description??'');
    if(descriptionSimilarity>0.05)add('description_overlap',Math.round(descriptionSimilarity*20),'support');
    if(sameType(mention.type,entity.type))add('compatible_declared_type',10,'support');

    let trustedDiscriminators=0;
    if(this.heuristics.properties){
      for(const key of [...HARD_DISCRIMINATORS,...SOFT_DISCRIMINATORS]){
        if(mention.properties?.[key]!=null&&entity.properties?.[key]!=null){
          const leftTrusted=evidenceTrusted(mention,'properties',key),rightTrusted=evidenceTrusted(entity,'properties',key),trusted=leftTrusted&&rightTrusted;
          if(canonical(mention.properties[key])===canonical(entity.properties[key])){
            if(trusted){add(`property:${key}`,HARD_DISCRIMINATORS.has(key)?40:30,HARD_DISCRIMINATORS.has(key)?'anchor':'support');trustedDiscriminators++;}
            else add(`untrusted_property:${key}`,5,'candidate');
          } else if(HARD_DISCRIMINATORS.has(key)&&trusted) blockers.push(`property_conflict:${key}`);
          else if(trusted) add(`property_difference:${key}`,-20,'support');
          else add(`untrusted_property_difference:${key}`,-2,'candidate');
        }
      }
    }

    const recentMatch=this.heuristics.context&&recent.some(r=>r.target===entity.id);
    if(recentMatch)add('recent_mention',12,'context');
    // Session continuity is a scoped identity anchor, not a global statement about a person with that name.
    if(exact&&entity.layer==='session'&&recentMatch&&sameType(mention.type,entity.type))add('scoped_recent_exact',30,'anchor');
    // Canonical symbolic artifacts can safely use exact case-sensitive labels.
    if(exact&&type==='Artifact'&&sameType(mention.type,entity.type)&&entity.properties?.caseSensitive)add('case_sensitive_artifact_label',30,'anchor');
    // Concepts may auto-resolve only when their English semantic descriptions materially overlap.
    if(exact&&type==='Concept'&&sameType(mention.type,entity.type)&&descriptionSimilarity>=0.12)add('concept_definition_overlap',25,'anchor');
    if(entity.kind==='type'&&exact)add('declared_type_identity',80,'anchor');

    const strong=anchors.length>0&&!blockers.length;
    return {id:entity.id,name:entity.name,description:entity.description,type:entity.type,score,features,blockers,anchors,strong,decision:blockers.length?'different':strong?'same':'uncertain',idMatch,trustedDiscriminators,policyVersion:this.policyVersion};
  }

  resolveEntity(mention,{turn=0,bindings={}}={}){
    const profiles=buildIdentityProfiles(this.store);
    const entities=[...this.store.list('entity').filter(e=>e.status!=='orphaned').map(e=>applyIdentityProfile(e,profiles.get(e.id))),...this.store.list('type')];
    const recent=this.store.list('mention').filter(r=>turn-r.turn<=this.recentWindow&&turn-r.turn>=0).map(r=>({...r,target:effectiveMentionTarget(this.store,r)}));
    const aliasesByTarget=new Map();for(const a of this.store.list('alias').filter(a=>a.status==='active')){if(!aliasesByTarget.has(a.target))aliasesByTarget.set(a.target,[]);aliasesByTarget.get(a.target).push(a);}
    const scored=entities.map(e=>this.compare(mention,e,{recent,aliasesByTarget}));
    const key=mentionKey(mention);

    if(Object.hasOwn(bindings,key)){
      const target=bindings[key];
      if(target==='__new__'){
        const collisions=scored.filter(c=>c.idMatch&&c.anchors.some(a=>a.startsWith('identifier:')));
        if(collisions.length)throw new AmbiguityError(mention,collisions.slice(0,8),'A trusted unique identifier already exists. Correct the identifier or type instead of creating a duplicate.');
        return {decision:'new',reason:'human_new_referent',candidates:[],policyVersion:this.policyVersion};
      }
      const c=scored.find(x=>x.id===target);
      if(!c||c.blockers.length)throw new AmbiguityError(mention,c?[c]:[],'Human selection conflicts with an explicit identity blocker.');
      return {decision:'same',target,reason:'human_confirmation',candidates:[c],policyVersion:this.policyVersion};
    }

    const incompatibleIdentifier=scored.filter(c=>c.idMatch&&c.blockers.length&&c.anchors.some(a=>a.startsWith('identifier:')));
    if(incompatibleIdentifier.length)throw new AmbiguityError(mention,incompatibleIdentifier.slice(0,8),'The same trusted unique identifier has incompatible identity evidence. Correct the source interpretation; do not silently duplicate it.');

    const anaphor=ANAPHORS.has(normalise(mention.name));
    if(anaphor&&this.heuristics.context){
      const ids=new Set(recent.map(r=>r.target));
      const candidates=scored.filter(c=>ids.has(c.id)&&!c.blockers.length&&(!mention.type||sameType(c.type,mention.type)));
      if(candidates.length===1&&mention.type)return {decision:'same',target:candidates[0].id,reason:'unique_typed_recent_referent',candidates,policyVersion:this.policyVersion};
      throw new AmbiguityError(mention,candidates.slice(0,8),'The recent conversation does not identify a unique compatible referent.');
    }
    if(SHORT_ROLES.has(normalise(mention.name)))throw new AmbiguityError(mention,[],'A role title is not a stable entity identity. Query the role in organization and time context.');

    const identityFeature=/^(identifier:|untrusted_identifier_match:|exact_label|diacritic_variant|fuzzy_label|name_order_or_title_variant|initials_variant|surname_only|generated_acronym|approved_alias:|weak_alias:)/;
    const relevant=scored.filter(c=>c.score>=15&&c.features.some(f=>identityFeature.test(f.name))).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
    const admissible=relevant.filter(c=>!c.blockers.length),best=admissible[0],next=admissible[1];
    if(best?.strong&&(!next||best.score-next.score>=this.minMargin))return {decision:'same',target:best.id,reason:best.anchors.join('+'),candidates:relevant.slice(0,8),policyVersion:this.policyVersion};
    if(best)throw new AmbiguityError(mention,relevant.slice(0,8),'Possible identity match, but candidate-generating signals are not identity proof. Add an independent discriminator, use recent scoped context, or confirm explicitly.');
    if(mixedScript(mention.name))throw new AmbiguityError(mention,relevant.slice(0,8),'Mixed-script label requires explicit review.');
    return {decision:'new',reason:relevant.length?'all_candidates_explicitly_incompatible':'no_candidate',candidates:relevant.slice(0,8),policyVersion:this.policyVersion};
  }

  resolveRelation(name,description,signature={}){
    const key=relationKey(name),relations=this.store.list('relation');
    const aliases=this.store.list('alias').filter(a=>a.status==='active'&&a.targetKind==='relation'&&relationKey(a.name)===key);
    const hits=relations.filter(r=>relationKey(r.name)===key||aliases.some(a=>a.target===r.id));
    if(hits.length===1){const r=hits[0];const conflicts=['roles','domains','arity','symmetric','transitive','irreflexive','inverse','semanticsKey'].filter(k=>signature[k]!==undefined&&canonical(signature[k])!==canonical(r[k]));if(conflicts.length)throw new KBError('RELATION_CONFLICT','Matching label has a different ordered relation signature. Do not conflate inverse, broader or narrower relations.',{name,target:r.id,conflicts});return {decision:'same',target:r.id,semanticRelation:'same',reason:'approved_relation_label_and_compatible_signature',policyVersion:this.policyVersion};}
    if(hits.length>1)throw new KBError('RELATION_AMBIGUOUS','Relation alias has multiple meanings.',{name,candidates:hits.map(r=>r.id)});
    const suggestions=relations.map(r=>{
      let semanticRelation='uncertain';
      if(signature.inverse&&signature.inverse===r.id)semanticRelation='inverse';
      else if(signature.semanticsKey&&r.semanticsKey===signature.semanticsKey)semanticRelation='related';
      return {id:r.id,name:r.name,score:jaccard(description,r.description),semanticRelation};
    }).filter(r=>r.score>0.35||r.semanticRelation!=='uncertain');
    return {decision:'new',semanticRelation:'different_or_unresolved',reason:'no_approved_relation_equivalence',suggestions,policyVersion:this.policyVersion};
  }
}

/** Public pairwise helper. Scores are heuristic ranking signals, NEVER probabilities. */
export function isTheSame(left,right,context={}){const store=context.store??{list:()=>[]};return new Resolver(store).compare(left,right,context);}
