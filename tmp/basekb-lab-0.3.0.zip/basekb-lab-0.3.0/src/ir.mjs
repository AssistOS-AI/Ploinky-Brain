import { assert, hash, safeData } from './util.mjs';
import { KNOWLEDGE_IR_VERSION, PROGRAM_API_VERSION } from './versions.mjs';

/**
 * Canonical Knowledge Program IR.
 * The JS-looking source is only a surface syntax. This object is the versioned
 * representation executed by KB-VM and suitable for replay, hashing and future compilers.
 */
export function toKnowledgeIR(ast) {
  assert(ast && Array.isArray(ast.statements), 'IR', 'Invalid parsed Knowledge Program.');
  return safeData({
    kind: 'KnowledgeProgramIR',
    irVersion: KNOWLEDGE_IR_VERSION,
    programApiVersion: PROGRAM_API_VERSION,
    statements: ast.statements
  });
}

export function validateKnowledgeIR(ir) {
  assert(ir?.kind === 'KnowledgeProgramIR', 'IR', 'Expected KnowledgeProgramIR.');
  assert(ir.irVersion === KNOWLEDGE_IR_VERSION, 'IR_VERSION', `Unsupported Knowledge IR ${ir.irVersion}.`);
  assert(ir.programApiVersion === PROGRAM_API_VERSION, 'API_VERSION', `Unsupported Program API ${ir.programApiVersion}.`);
  assert(Array.isArray(ir.statements), 'IR', 'Knowledge IR requires statements.');
  return ir;
}

export const irHash = ir => hash(validateKnowledgeIR(ir));
