import { canonical, safeData } from './util.mjs';

export const IDENTITY_PROFILE_VERSION = '1.0';

const HARD_PROPERTY_KEYS = new Set(['birthDate','registryCountry','parentOrganization','version']);

function fieldTrusted(record, group, key) {
  const map = record.identityEvidence?.[group];
  // Raw records inserted by a trusted operator/test fixture predate field-level evidence.
  // Engine-created records always carry identityEvidence, so absence there is meaningful.
  if (!map) return true;
  return map[key]?.trusted === true;
}

function auditValue(profile, group, key, value, evidence, origin) {
  if (!profile.claims[group][key]) profile.claims[group][key] = [];
  const list = profile.claims[group][key];
  const fingerprint = canonical(value);
  if (!list.some(x => x.fingerprint === fingerprint && x.origin?.recordId === origin.recordId)) {
    list.push({ value:safeData(value), evidence:evidence ? safeData(evidence) : null, fingerprint, origin:safeData(origin) });
  }
}

export function resolutionState(store) {
  const resolutions = store.list('resolution');
  const byId = new Map(resolutions.map(r => [r.id,r]));
  const supersededBy = new Map();
  for (const r of resolutions) if (r.supersedes) supersededBy.set(r.supersedes, r.id);
  const superseded = new Set(supersededBy.keys());
  const active = resolutions.filter(r => !superseded.has(r.id));
  return { resolutions, byId, supersededBy, superseded, active };
}

export function effectiveResolution(store, resolutionId) {
  const state = resolutionState(store); let id = resolutionId, guard = 0;
  while (state.supersededBy.has(id)) {
    id = state.supersededBy.get(id);
    if (++guard > 64) throw new Error('Resolution supersession chain exceeds 64 steps.');
  }
  return state.byId.get(id) ?? null;
}

export function effectiveMentionTarget(store, mention) {
  const effective = mention?.resolutionId ? effectiveResolution(store, mention.resolutionId) : null;
  return effective?.target ?? mention?.target ?? null;
}

export function buildIdentityProfiles(store) {
  const entities = store.list('entity');
  const state = resolutionState(store);
  const profiles = new Map();
  for (const entity of entities) profiles.set(entity.id, {
    profileVersion:IDENTITY_PROFILE_VERSION,
    entityId:entity.id,
    claims:{ ids:Object.create(null), properties:Object.create(null) },
    resolved:{ ids:Object.create(null), properties:Object.create(null) },
    evidence:{ ids:Object.create(null), properties:Object.create(null) },
    conflicts:[],
    activeResolutionIds:[],
    ignoredSupersededResolutionIds:[],
    directRecordTrusted:!(entity.createdByResolution && state.superseded.has(entity.createdByResolution))
  });

  const addRecord = (entityId, record, origin) => {
    const profile = profiles.get(entityId); if (!profile) return;
    for (const group of ['ids','properties']) for (const [key,value] of Object.entries(record[group] ?? {})) {
      if (fieldTrusted(record,group,key)) auditValue(profile,group,key,value,record.identityEvidence?.[group]?.[key]?.evidence ?? record.evidence ?? null,origin);
    }
  };

  for (const entity of entities) {
    const profile = profiles.get(entity.id);
    if (profile.directRecordTrusted) addRecord(entity.id, entity, {kind:'entity',recordId:entity.id});
  }

  for (const resolution of state.resolutions) {
    const profile = profiles.get(resolution.target); if (!profile) continue;
    if (state.superseded.has(resolution.id)) { profile.ignoredSupersededResolutionIds.push(resolution.id); continue; }
    if (!['same','new'].includes(resolution.decision)) continue;
    profile.activeResolutionIds.push(resolution.id);
    addRecord(resolution.target, resolution.mention ?? {}, {kind:'resolution',recordId:resolution.id,decision:resolution.decision,turn:resolution.turn ?? null});
  }

  for (const profile of profiles.values()) for (const group of ['ids','properties']) for (const [key,claims] of Object.entries(profile.claims[group])) {
    const unique = new Map();
    for (const claim of claims) if (!unique.has(claim.fingerprint)) unique.set(claim.fingerprint, claim);
    if (unique.size === 1) {
      const claim = [...unique.values()][0]; profile.resolved[group][key] = claim.value;
      profile.evidence[group][key] = {trusted:true,evidence:claim.evidence,claimCount:claims.length,origins:claims.map(c=>c.origin)};
    } else if (unique.size > 1) {
      profile.conflicts.push({group,key,hard:group==='ids'||HARD_PROPERTY_KEYS.has(key),values:[...unique.values()].map(c=>c.value),claimCount:claims.length});
    }
  }
  return profiles;
}

export function buildIdentityProfile(store, entityId) {
  return buildIdentityProfiles(store).get(entityId) ?? null;
}

/** Return a non-persistent entity view enriched by active trusted identity claims. */
export function applyIdentityProfile(entity, profile) {
  if (!profile) return entity;
  const directTrusted = profile.directRecordTrusted;
  const ids = { ...(entity.ids ?? {}) }, properties = { ...(entity.properties ?? {}) };
  const identityEvidence = {
    ids:{ ...(entity.identityEvidence?.ids ?? {}) },
    properties:{ ...(entity.identityEvidence?.properties ?? {}) }
  };
  if (!directTrusted) {
    for (const key of Object.keys(ids)) identityEvidence.ids[key] = {trusted:false,reason:'originating resolution was superseded'};
    for (const key of Object.keys(properties)) identityEvidence.properties[key] = {trusted:false,reason:'originating resolution was superseded'};
  }
  for (const group of ['ids','properties']) {
    const values = group === 'ids' ? ids : properties;
    for (const [key,value] of Object.entries(profile.resolved[group])) {
      values[key] = safeData(value); identityEvidence[group][key] = safeData(profile.evidence[group][key]);
    }
    for (const conflict of profile.conflicts.filter(c=>c.group===group)) {
      delete values[conflict.key]; identityEvidence[group][conflict.key] = {trusted:false,reason:'conflicting trusted identity claims'};
    }
  }
  return {...entity,ids,properties,identityEvidence,identityProfile:safeData({profileVersion:profile.profileVersion,conflicts:profile.conflicts,activeResolutionIds:profile.activeResolutionIds})};
}
