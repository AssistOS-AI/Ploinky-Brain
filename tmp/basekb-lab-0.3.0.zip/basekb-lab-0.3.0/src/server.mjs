import http from 'node:http';
import { readFileSync, existsSync, mkdirSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { Store } from './storage.mjs';
import { Engine } from './engine.mjs';
import { ChatAgent, LocalLLM } from './llm.mjs';
import { createBase } from './seed.mjs';
import { assert, errorJSON, parseArgs, safeData, hash, KBError } from './util.mjs';
import { VERSION_SET, INTERNAL_LANGUAGE } from './versions.mjs';

const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
async function bodyJSON(req) {
  assert((req.headers['content-type'] ?? '').split(';')[0]==='application/json','HTTP_TYPE','Expected application/json.');
  let total=0;const chunks=[];
  for await(const c of req){total+=c.length;assert(total<=180000,'LIMIT','HTTP body exceeds 180 kB.');chunks.push(c);}
  try{return safeData(JSON.parse(Buffer.concat(chunks).toString('utf8')));}catch(e){if(e instanceof KBError)throw e;throw new KBError('JSON','Invalid JSON body.');}
}
export function createApp({basePath=join(ROOT,'data/base.sqlite'),dataDir=join(ROOT,'data/sessions'),demo=false,llm=new LocalLLM(),port=3000,host='127.0.0.1'}={}) {
  assert(['127.0.0.1','::1'].includes(host),'LOCAL_ONLY','The demo web application binds to loopback only. Use an SSH tunnel.');
  if(!existsSync(basePath))createBase(basePath);mkdirSync(dataDir,{recursive:true,mode:0o700});
  const token=randomBytes(32).toString('hex'),sessions=new Map(),pending=new Map(),queues=new Map(),requests=new Map();
  function openSession(id,create=false){
    assert(typeof id==='string' && /^[a-f0-9-]{36}$/.test(id),'SESSION','Invalid session ID.');
    if(!sessions.has(id)){
      const path=join(dataDir,`${id}.sqlite`);assert(create || existsSync(path),'SESSION','Session not found.');
      assert(sessions.size<100,'LIMIT','Open-session limit reached. Restart the app to release handles.');
      const store=new Store({basePath,sessionPath:path}),engine=new Engine(store);
      sessions.set(id,{store,engine,agent:new ChatAgent(engine,{llm,demo,identityLLM:process.env.IDENTITY_LLM==='1'})});
    }
    return sessions.get(id);
  }
  function enqueue(id,fn){
    const previous=queues.get(id) ?? Promise.resolve();const task=previous.catch(()=>{}).then(fn);
    queues.set(id,task);task.finally(()=>{if(queues.get(id)===task)queues.delete(id);}).catch(()=>{});return task;
  }
  function reply(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(value));}
  function addClarification(result,id,text,dryRun=false){
    if(result.needsClarification && result.error.code==='AMBIGUOUS'){
      const pendingId=randomUUID();pending.set(pendingId,{id,text,dryRun,program:result.program,bindings:result.bindings,normalization:result.inputNormalization,details:result.error.details,snapshot:openSession(id).store.snapshot()});
      result.pendingId=pendingId;
      if(pending.size>100)pending.delete(pending.keys().next().value);
    }
    return result;
  }
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Cache-Control','no-store');
    res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Cross-Origin-Resource-Policy','same-origin');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
    try{
      const actualPort=server.address()?.port ?? port;
      const validHosts=[`127.0.0.1:${actualPort}`,`localhost:${actualPort}`,`[::1]:${actualPort}`];
      assert(validHosts.includes(req.headers.host),'HOST','Unexpected Host header.');
      if(req.headers.origin)assert(validHosts.some(h=>req.headers.origin===`http://${h}`),'ORIGIN','Cross-origin requests are not allowed.');
      const url=new URL(req.url,`http://${req.headers.host}`);
      const staticFiles={'/':['index.html','text/html'],'/app.mjs':['app.mjs','text/javascript'],'/style.css':['style.css','text/css']};
      if(req.method==='GET' && staticFiles[url.pathname]){
        const [name,mime]=staticFiles[url.pathname];res.setHeader('Content-Type',`${mime}; charset=utf-8`);res.end(readFileSync(join(ROOT,'public',name)));return;
      }
      if(req.method==='GET' && url.pathname==='/api/config'){reply(res,200,{token,demo,model:llm.model,endpoint:llm.baseURL,internalLanguage:INTERNAL_LANGUAGE,versions:VERSION_SET});return;}
      const supplied=String(req.headers['x-kb-token'] ?? '');
      assert(supplied.length===token.length && timingSafeEqual(Buffer.from(supplied),Buffer.from(token)),'AUTH','Missing application token.');
      if(req.method==='GET' && url.pathname==='/api/health'){reply(res,200,demo ? {ok:true,mode:'controlled-demo'} : await llm.health());return;}
      if(req.method==='POST' && url.pathname==='/api/sessions'){
        await bodyJSON(req);const id=randomUUID();openSession(id,true);reply(res,201,{sessionId:id});return;
      }
      if(req.method==='GET' && url.pathname==='/api/kb'){
        const {store}=openSession(url.searchParams.get('session'));
        reply(res,200,{entities:store.list('entity').slice(0,200),types:store.list('type'),relations:store.list('relation'),
          assertions:store.list('assertion').slice(0,500),definitions:[...store.list('rule'),...store.list('constraint'),...store.list('function'),...store.list('alias').filter(a=>a.layer==='session')],
          mentions:store.list('mention').slice(-100),resolutions:store.list('resolution').slice(-100),executions:store.list('execution').slice(-50),events:store.events(20),audit:store.verifyAuditChain(),limits:{entities:200,assertions:500},snapshot:store.snapshot(),internalLanguage:store.getMeta('internalLanguage'),storeCreationVersions:Object.fromEntries(Object.keys(VERSION_SET).map(k=>[k,store.getMeta(k)])),runtimeVersions:VERSION_SET});return;
      }
      if(req.method==='GET' && url.pathname==='/api/history'){
        const {store}=openSession(url.searchParams.get('session'));reply(res,200,store.events(300).filter(e=>e.kind==='execution').reverse().map(e=>({text:store.get(e.data.sourceId)?.text,answer:e.data.answer,program:e.data.code})));return;
      }
      if(req.method==='POST' && url.pathname==='/api/chat'){
        const body=await bodyJSON(req),session=openSession(body.sessionId);
        assert(typeof body.text==='string' && body.text.trim() && body.text.length<=16000,'INPUT','Message must contain 1..16000 characters.');
        const requestId=body.requestId ?? randomUUID();assert(typeof requestId==='string' && requestId.length<=100,'INPUT','Invalid request ID.');
        const requestKey=`${body.sessionId}:${requestId}`,bodyHash=hash({text:body.text,dryRun:!!body.dryRun});
        const result=await enqueue(body.sessionId,async()=>{
          if(requests.has(requestKey)){const saved=requests.get(requestKey);assert(saved.hash===bodyHash,'REPLAY','Request ID reused with another body.');return saved.result;}
          const output=addClarification(await session.agent.run(body.text,{dryRun:body.dryRun===true}),body.sessionId,body.text,body.dryRun===true);
          requests.set(requestKey,{hash:bodyHash,result:output});if(requests.size>200)requests.delete(requests.keys().next().value);return output;
        });reply(res,200,result);return;
      }
      if(req.method==='POST' && url.pathname==='/api/resolve'){
        const body=await bodyJSON(req),p=pending.get(body.pendingId);assert(p,'PENDING','Clarification expired; submit the message again.');
        assert(body.candidateId==='__new__' || p.details.candidates.some(c=>c.id===body.candidateId),'IDENTITY','Candidate was not offered for this ambiguity.');
        const result=await enqueue(p.id,async()=>{
          const {store,agent}=openSession(p.id);assert(store.snapshot()===p.snapshot,'STALE_SESSION','Session changed since clarification. Submit again.');
          const bindings={...p.bindings,[p.details.mentionKey]:body.candidateId};
          const output=await agent.run(p.text,{code:p.program,bindings,dryRun:p.dryRun,normalization:p.normalization});pending.delete(body.pendingId);
          if(!p.dryRun)store.event('human_identity_selection',{mentionKey:p.details.mentionKey,target:body.candidateId});
          return addClarification(output,p.id,p.text,p.dryRun);
        });reply(res,200,result);return;
      }
      if(req.method==='POST' && url.pathname==='/api/fork'){
        const body=await bodyJSON(req);const parent=openSession(body.sessionId);const id=randomUUID();
        await enqueue(body.sessionId,()=>{const child=parent.store.fork(join(dataDir,`${id}.sqlite`));child.close();openSession(id);});reply(res,201,{sessionId:id});return;
      }
      throw new KBError('NOT_FOUND','Unknown endpoint.');
    }catch(e){reply(res,e.code==='AUTH'?401:e.code==='NOT_FOUND'?404:['HOST','ORIGIN'].includes(e.code)?403:400,{error:errorJSON(e)});}
  });
  server.requestTimeout=200000;server.headersTimeout=10000;
  return {server,token,sessions,async listen(){await new Promise((yes,no)=>{server.once('error',no);server.listen(port,host,yes);});return server.address();},
    async close(){server.closeIdleConnections();await new Promise(resolve=>server.close(resolve));for(const {store}of sessions.values())store.close();}};
}
if(process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const args=parseArgs(process.argv.slice(2));
  const app=createApp({demo:!!args.demo,port:Number(args.port ?? process.env.PORT ?? 3000),basePath:resolve(args.base ?? join(ROOT,'data/base.sqlite')),dataDir:resolve(args.data ?? join(ROOT,'data/sessions'))});
  const address=await app.listen();
  console.log(`BaseKB Lab: http://127.0.0.1:${address.port}\nMode: ${args.demo ? 'CONTROLLED DEMO (no LLM)' : 'local LLM'}\nToken for CLI HTTP requests: ${app.token}\nCtrl-C stops the application.`);
  const shutdown=async()=>{await app.close();process.exit(0);};process.once('SIGINT',shutdown);process.once('SIGTERM',shutdown);
}
