import { Resolver, normalise, normaliseID, identifierWellFormed, mentionKey, AmbiguityError } from './resolver.mjs';
import { parseProgram, validateProgram, evaluateProgram } from './language.mjs';
import { toKnowledgeIR, validateKnowledgeIR, irHash } from './ir.mjs';
import { INTERNAL_LANGUAGE, VERSION_SET } from './versions.mjs';
import { buildIdentityProfile, applyIdentityProfile } from './identity-profile.mjs';
import { closure, join, variable, validateRule, checkConstraints } from './rules.mjs';
import { renderAnswer, explainFact } from './answer.mjs';
import { assert, KBError, hash, canonical, safeData, requireString, interval, iso, conforms, validateSchema, bannedKeys, own } from './util.mjs';

const literalValue = v => v && typeof v === 'object' && v.kind === 'literal';
const READ_API = ['ref','literal','query','truth','explain','call','get','respond','clarify'];
export const PROGRAM_API = [...READ_API,'sourceSpan','claim','createEntity','createEntityType','createRelationType','createFact','createConstraint','createRule','createFunction','createAlias','retractFact'];
export class Engine {
  constructor(store, options = {}) {
    this.store = store; this.options = { maxFacts:10000, maxRounds:32, comparisons:200000, maxWrites:500, language:INTERNAL_LANGUAGE, ...options };
    assert(this.options.language === INTERNAL_LANGUAGE, 'INTERNAL_LANGUAGE', 'KB-VM answers and semantic objects are always English. Localization belongs at the UI/LLM boundary.');
    this.resolver = new Resolver(store, options.resolver); this.current = null; this.cache = null;
  }
  lookupRelation(id) {
    const direct = this.store.get(id);
    if (direct?.kind === 'relation') return direct;
    const result = this.resolver.resolveRelation(String(id), '', {});
    assert(result.decision === 'same', 'RELATION', `Unknown relation ${id}; declare it or use a known relation.`);
    return this.store.get(result.target);
  }
  lookupType(type) {
    if (!type) return 'sys:Entity';
    if (this.store.get(type)?.kind === 'type') return type;
    const hits = this.store.list('type').filter(t => normalise(t.name) === normalise(type));
    assert(hits.length === 1, 'TYPE', `Unknown or ambiguous type ${type}.`); return hits[0].id;
  }
  isA(entity, expected) {
    if (!expected || expected === 'sys:Entity') return !!entity;
    const e = typeof entity === 'string' ? this.store.get(entity) : entity;
    if (!e) return false;
    if (expected === 'sys:Type') return e.kind === 'type';
    let type = e.type, seen = new Set();
    while (type && !seen.has(type)) { if (type === expected) return true; seen.add(type); type = this.store.get(type)?.parent; }
    return false;
  }
  writable() {
    assert(this.current && !this.current.readOnly, 'CAPABILITY', 'This execution has no write capability.');
    assert(++this.current.writes <= this.options.maxWrites, 'LIMIT', 'Write budget exceeded.');
    this.cache = null;
  }
  sourceSpan(quote, occurrence = 0) {
    assert(this.current, 'CONTEXT', 'Missing execution context.');
    requireString(quote, 'Source quotation', 200000);
    assert(Number.isSafeInteger(occurrence) && occurrence >= 0 && occurrence <= 1000, 'EVIDENCE', 'Invalid occurrence index.');
    const text = this.current.source.text; let start = -1, cursor = 0;
    for (let i=0; i<=occurrence; i++) { start = text.indexOf(quote, cursor); if (start < 0) break; cursor = start + quote.length; }
    assert(start >= 0, 'EVIDENCE', 'Quoted evidence does not occur in the source.');
    return { sourceId:this.current.source.id, start, end:start + quote.length, quote, granularity:'span' };
  }
  evidence(provided) {
    const e = provided ?? { sourceId:this.current.source.id, start:0, end:this.current.source.text.length, quote:this.current.source.text, granularity:'whole_source' };
    const source = this.store.get(e.sourceId);
    assert(source?.kind === 'source' && source.text && Number.isSafeInteger(e.start) && Number.isSafeInteger(e.end) && e.start >= 0 && e.end > e.start && e.end <= source.text.length && source.text.slice(e.start,e.end) === e.quote,
      'EVIDENCE', 'Invalid source span.');
    // Programs may only assert evidence from this source, never fabricate a citation to another source.
    assert(e.sourceId === this.current.source.id, 'EVIDENCE', 'Cross-source citations must be imported by a trusted adapter.');
    return safeData(e);
  }
  claim(value, evidence) {
    assert(['string','number','boolean'].includes(typeof value) || value === null, 'CLAIM', 'Evidence-bearing identity values must be scalar.');
    return safeData({ kind:'evidencedValue', value, evidence:this.evidence(evidence), trusted:true });
  }
  identityFields(raw, group, fallbackEvidence) {
    const values=Object.create(null), identityEvidence=Object.create(null);
    for(const [key,entry] of Object.entries(safeData(raw ?? {}))) {
      if(entry && typeof entry === 'object' && entry.kind === 'evidencedValue') {
        const evidence=this.evidence(entry.evidence); values[key]=safeData(entry.value);
        identityEvidence[key]={trusted:entry.trusted===true,evidence};
      } else {
        values[key]=safeData(entry); identityEvidence[key]={trusted:false,evidence:fallbackEvidence,reason:'entity-level evidence only'};
      }
      if(group==='ids' && identityEvidence[key].trusted) {
        const evidence=identityEvidence[key].evidence;
        assert(typeof values[key]==='string' && values[key].trim(), 'IDENTIFIER_FORMAT', `Identifier ${key} must be a nonempty string.`);
        assert(identifierWellFormed(key,values[key]), 'IDENTIFIER_FORMAT', `Identifier ${key} has an invalid canonical format/checksum.`);
        assert(normaliseID(key,evidence.quote).includes(normaliseID(key,values[key])), 'EVIDENCE', `Identifier ${key} must occur in its field-level evidence span.`);
      }
    }
    return {values:safeData(values),identityEvidence:safeData(identityEvidence)};
  }
  createEntity(name, description, options = {}) {
    this.writable(); requireString(name, 'Entity name', 200); requireString(description, 'Contextual description in English', 2000);
    const evidence = this.evidence(options.evidence), type = this.lookupType(options.type);
    const idsPack=this.identityFields(options.ids,'ids',evidence), propsPack=this.identityFields(options.properties,'properties',evidence);
    const ids=idsPack.values, properties=propsPack.values;
    const identityEvidence={ids:idsPack.identityEvidence,properties:propsPack.identityEvidence};
    const mention = {name, description, type, ids, properties, identityEvidence};
    const key = mentionKey(mention);
    let resolution;
    if (options.new === true) {
      assert(this.current.allowExplicitNew, 'POLICY', 'Only a trusted import or human confirmation can force a new entity.');
      resolution = { decision:'new', reason:'trusted_explicit_new', candidates:[], policyVersion:this.resolver.policyVersion };
    } else resolution = this.resolver.resolveEntity(mention, { turn:this.current.turn, bindings:this.current.bindings });
    let id = resolution.target;
    if (!id) id = `entity:${hash([this.store.id, key, this.current.source.id]).slice(0,32)}`;
    const resolutionId=`resolution:${hash([this.current.source.id,key,id,resolution.policyVersion,resolution.reason]).slice(0,32)}`;
    if (!resolution.target) {
      this.store.put({ id, kind:'entity', name, description, type, ids, properties, identityEvidence, status:'session', evidence,
        createdByResolution:resolutionId, createdByExecution:this.current.executionId });
    }
    const decision={id:resolutionId,kind:'resolution',name:`resolve:${name}`,mentionKey:key,mention:safeData(mention),target:id,decision:resolution.decision,reason:resolution.reason,
      candidates:safeData(resolution.candidates ?? []),policyVersion:resolution.policyVersion ?? this.resolver.policyVersion,turn:this.current.turn,evidence,status:'recorded',createdByExecution:this.current.executionId};
    this.store.put(decision);
    const record = { id:`mention:${hash([this.current.source.id,key,id]).slice(0,32)}`, kind:'mention', name, description, target:id, type, turn:this.current.turn, evidence,
      resolutionId, resolution:{decision:decision.decision,reason:decision.reason,policyVersion:decision.policyVersion}, mentionKey:key,createdByExecution:this.current.executionId };
    this.store.put(record); this.current.resolutions.push(decision);
    const previous=this.current.resolutionByTarget.get(id);
    if(previous===undefined)this.current.resolutionByTarget.set(id,resolutionId);
    else if(previous!==resolutionId)this.current.resolutionByTarget.set(id,null); // ambiguous mention provenance for this target in one program
    if (!resolution.target && type !== 'sys:Entity' && this.store.get('sys:instanceOf')) this.createFact('sys:instanceOf', [id,type], {evidence});
    return id;
  }
  createEntityType(name, description, options = {}) {
    this.writable(); requireString(name,'Type name',100); requireString(description,'Type description');
    const old = this.store.list('type').filter(t => normalise(t.name) === normalise(name));
    if (old.length) {
      assert(old.length===1,'TYPE_CONFLICT','Type name is ambiguous.');
      if(options.parent !== undefined) assert(old[0].parent===this.lookupType(options.parent),'TYPE_CONFLICT','Existing type has another declared parent.');
      return old[0].id;
    }
    const parent = this.lookupType(options.parent), evidence = this.evidence(options.evidence);
    const id = `type:${hash([this.store.id,name,description]).slice(0,32)}`;
    this.store.put({id, kind:'type', name, description, parent, status:'session', evidence,createdByExecution:this.current.executionId}); return id;
  }
  createRelationType(name, description, options = {}) {
    this.writable(); requireString(name,'Relation name',100); requireString(description,'Relation description');
    for(const key of ['symmetric','transitive','irreflexive']) if(options[key] !== undefined) assert(typeof options[key]==='boolean','RELATION',`${key} must be boolean.`);
    const signature = { ...options }; delete signature.evidence;
    if (signature.domains) signature.domains = signature.domains.map(t => this.lookupType(t));
    const result = this.resolver.resolveRelation(name, description, signature);
    this.current.resolutions.push({kind:'relationResolution', name, ...result});
    if (result.decision === 'same') return result.target;
    const arity = options.arity ?? options.roles?.length ?? 2;
    assert(Number.isSafeInteger(arity) && arity >= 1 && arity <= 8, 'RELATION', 'Arity must be between 1 and 8.');
    const roles = options.roles ?? (arity === 2 ? ['subject','object'] : Array.from({length:arity},(_,i)=>`arg${i}`));
    const domains = signature.domains ?? Array(arity).fill('sys:Entity');
    assert(roles.every(role=>typeof role==='string' && role.trim() && role.length<=100) && roles.length === arity && new Set(roles).size === arity && domains.length === arity, 'RELATION','Ordered roles/domains must match arity.');
    const id = `relation:${hash([this.store.id,name,description,roles,domains]).slice(0,32)}`;
    this.current.resolutions.at(-1).target=id;
    this.store.put({id, kind:'relation', name, description, arity, roles, domains, symmetric:options.symmetric ?? false,
      transitive:options.transitive ?? false, irreflexive:options.irreflexive ?? false, inverse:options.inverse ?? null,
      semanticsKey:options.semanticsKey ?? id, status:'session', metadataStatus:'candidate', evidence:this.evidence(options.evidence),createdByExecution:this.current.executionId});
    return id;
  }
  normaliseAtom(atom) {
    const r = this.lookupRelation(atom.relation);
    assert(Array.isArray(atom.args) && atom.args.length === r.arity, 'QUERY', `Expected ${r.arity} arguments for ${r.name}.`);
    return {relation:r.id,args:atom.args,polarity:atom.polarity ?? 1};
  }
  validateFactArgs(r,args) {
    assert(args.length === r.arity, 'ARITY', `${r.name} requires ${r.arity} arguments.`);
    for (let i=0;i<args.length;i++) {
      const term = args[i], expected = r.domains[i];
      if (expected === 'sys:Term') assert(literalValue(term) || (typeof term === 'string' && ['entity','type'].includes(this.store.get(term)?.kind)), 'TYPE', 'Term must be an entity reference or literal.');
      else if (expected === 'sys:Literal') assert(literalValue(term), 'TYPE', `Argument ${i} requires literal(value).`);
      else assert(typeof term === 'string' && ['entity','type'].includes(this.store.get(term)?.kind) && this.isA(term,expected), 'TYPE', `Argument ${i} is not a known ${expected}.`);
    }
  }
  identityDependencies(args) {
    if(!this.current?.resolutionByTarget)return [];
    const grouped=new Map();
    args.forEach((term,position)=>{if(typeof term!=='string')return;const resolutionId=this.current.resolutionByTarget.get(term);if(!resolutionId)return;if(!grouped.has(resolutionId))grouped.set(resolutionId,[]);grouped.get(resolutionId).push(position);});
    return [...grouped].map(([resolutionId,positions])=>({resolutionId,positions}));
  }
  createFact(relation, ...params) {
    this.writable(); const r = this.lookupRelation(relation);
    const [args, options] = Array.isArray(params[0]) ? [params[0],params[1] ?? {}] : [params.slice(0,r.arity),params[r.arity] ?? {}];
    this.validateFactArgs(r,args);
    const polarity = options.polarity ?? 1; assert([1,-1].includes(polarity),'TYPE','Polarity must be 1 or -1.');
    const status = options.status ?? 'accepted'; assert(['accepted','proposed'].includes(status),'POLICY','Facts can be accepted assertions or proposals, never automatically verified.');
    const evidence = this.evidence(options.evidence), times = interval(options.validFrom,options.validTo);
    const context = options.context ?? 'actual'; requireString(context,'Context',100);
    const data = {relation:r.id,args:safeData(args),polarity,context,...times,qualifiers:safeData(options.qualifiers ?? {}),status,evidence};
    const id = `fact:${hash(data).slice(0,32)}`,identityDependencies=this.identityDependencies(args);
    const fact = this.store.put({id,kind:'assertion',name:r.name,...data,...(identityDependencies.length?{identityDependencies}:{}),createdByExecution:this.current.executionId});
    this.runHooks('afterCreateFact', {subject:args[0], object:args[1] ?? null, args, relation:r.id, factId:id});
    return fact.id;
  }
  createAlias(name, target, options = {}) {
    this.writable(); requireString(name,'Alias',200);
    const entity = this.store.get(target); assert(entity && ['entity','relation','type'].includes(entity.kind),'ALIAS','Unknown alias target.');
    const aliasKind = options.kind ?? 'synonym'; assert(['synonym','nickname','acronym','spelling'].includes(aliasKind),'ALIAS','Unknown alias category.');
    const id = `alias:${hash([this.store.id,name,target]).slice(0,32)}`;
    this.store.put({id,kind:'alias',name,target,targetKind:entity.kind,aliasKind,status:'candidate',evidence:this.evidence(options.evidence),createdByExecution:this.current.executionId});
    return id;
  }
  createRule(name, description, spec) {
    this.writable(); requireString(name,'Rule name'); requireString(description,'Rule description');
    const rule = {body:spec.body?.map(a => this.normaliseAtom(a)),head:this.normaliseAtom(spec.head ?? {})};
    validateRule(rule, id=>this.store.get(id));
    const id = `rule:${hash([this.store.id,name,rule]).slice(0,32)}`;
    this.store.put({id,kind:'rule',name,description,...rule,status:'candidate',version:1,evidence:this.evidence(spec.evidence),createdByExecution:this.current.executionId}); return id;
  }
  createConstraint(name, description, spec) {
    this.writable(); requireString(name,'Constraint name'); requireString(description,'Constraint description');
    assert(['irreflexive','functional'].includes(spec.kind),'CONSTRAINT','Supported constraints: irreflexive, functional.');
    const relation = this.lookupRelation(spec.relation);
    const keyPositions = spec.keyPositions ?? [0], valuePosition = spec.valuePosition ?? 1;
    assert(keyPositions.every(i=>Number.isSafeInteger(i) && i>=0 && i<relation.arity) && Number.isSafeInteger(valuePosition) && valuePosition>=0 && valuePosition<relation.arity,'CONSTRAINT','Invalid argument positions.');
    const id = `constraint:${hash([this.store.id,name,spec]).slice(0,32)}`;
    this.store.put({id,kind:'constraint',name,description,constraintKind:spec.kind,relation:relation.id,keyPositions,valuePosition,status:'candidate',evidence:this.evidence(spec.evidence),createdByExecution:this.current.executionId}); return id;
  }
  createFunction(name, description, spec) {
    this.writable(); requireString(name,'Function name',100); requireString(description,'Function description');
    requireString(spec.code,'Function body',20000);
    validateSchema(spec.inputSchema ?? {}); validateSchema(spec.outputSchema ?? {});
    validateProgram(parseProgram(spec.code),READ_API,['input']);
    const id = `function:${hash([this.store.id,name,spec.code]).slice(0,32)}`;
    this.store.put({id,kind:'function',name,description,code:spec.code,inputSchema:safeData(spec.inputSchema ?? {}),outputSchema:safeData(spec.outputSchema ?? {}),
      status:'candidate',capabilities:['read'],version:1,codeHash:hash(spec.code),evidence:this.evidence(spec.evidence),createdByExecution:this.current.executionId}); return id;
  }
  getClosure() {
    if (!this.cache) {
      const metadataRules = [];
      for (const r of this.store.list('relation')) {
        const a = (relation,args) => ({relation,args,polarity:1});
        const rule = (suffix,body,head) => metadataRules.push({id:`meta:${r.id}:${suffix}`,name:`${r.name}:${suffix}`,body,head,status:'active',version:1});
        if(r.arity === 2 && (r.status === 'active' || r.metadataStatus === 'active')) {
          if(r.symmetric) rule('symmetric',[a(r.id,['?x','?y'])],a(r.id,['?y','?x']));
          if(r.transitive) rule('transitive',[a(r.id,['?x','?y']),a(r.id,['?y','?z'])],a(r.id,['?x','?z']));
          if(r.inverse) {
            const inv = this.lookupRelation(r.inverse);
            assert(inv.arity===2 && canonical(inv.domains)===canonical([...r.domains].reverse()),'RELATION','Inverse relation must have reversed ordered domains.');
            rule('inverse',[a(r.id,['?x','?y'])],a(inv.id,['?y','?x']));
          }
        }
      }
      this.cache = closure(this.store.list('assertion'),[...this.store.list('rule'),...metadataRules],this.options);
      for(const f of this.cache.facts) {
        const relation=this.store.get(f.relation);
        assert(relation?.kind==='relation' && f.args?.length===relation.arity,'TYPE','Invalid imported or derived relation arity.');
        for(let i=0;i<f.args.length;i++) {
          const domain=relation.domains[i],term=f.args[i];
          assert(domain==='sys:Term' ? (literalValue(term) || ['entity','type'].includes(this.store.get(term)?.kind)) : domain==='sys:Literal' ? literalValue(term) : this.isA(term,domain), 'TYPE', 'An imported or inferred argument violates the declared relation domain.');
        }
      }
      const violations = checkConstraints(this.cache.facts,this.store.list('relation'),this.store.list('constraint'));
      assert(!violations.length,'CONSTRAINT_VIOLATION','The proposed knowledge violates active invariants.',{violations});
    }
    return this.cache;
  }
  query(pattern) {
    assert(pattern && typeof pattern === 'object','QUERY','Query pattern required.');
    const atoms = (pattern.where ?? [pattern]).map(a=>this.normaliseAtom(a));
    assert(atoms.length>=1 && atoms.length<=6,'QUERY','Queries allow 1..6 atoms.');
    const c = this.getClosure();
    const rows = join(atoms,c.facts,{budget:{remaining:this.options.comparisons},maxRows:this.options.maxFacts,context:pattern.context ?? 'actual',at:pattern.at ?? null});
    const select = pattern.select ?? [...new Set(atoms.flatMap(a=>a.args.filter(variable)))];
    assert(Array.isArray(select) && select.every(v=>atoms.some(a=>a.args.includes(v))),'QUERY','Selected variables must occur in query atoms.');
    const unique = new Map();
    for (const row of rows) {
      const bindings = Object.fromEntries(select.map(k=>[k,row.bindings[k]]));
      const k = canonical([bindings,row.validFrom,row.validTo,row.context]);
      if (!unique.has(k)) unique.set(k,{...row,bindings});
      else { const existing = unique.get(k); existing.factIds = [...new Set([...existing.factIds,...row.factIds])]; existing.tainted ||= row.tainted; }
    }
    const all = [...unique.values()], limit = pattern.limit ?? 50;
    assert(Number.isSafeInteger(limit) && limit>=1 && limit<=500,'LIMIT','Query limit must be 1..500.');
    const warnings = all.some(r=>r.tainted) ? ['The conclusion depends on assertions with contradictory support.'] : [];
    return {kind:'queryResult',rows:all.slice(0,limit),total:all.length,truncated:all.length>limit,complete:c.complete,warnings};
  }
  truth(pattern) {
    assert(!pattern.args?.some(variable) && pattern.args?.every(a=>a!==null),'QUERY','truth requires fully grounded arguments.');
    const atom=this.normaliseAtom(pattern);
    if(!pattern.at) assert(!this.getClosure().facts.some(f=>f.relation===atom.relation && canonical(f.args)===canonical(atom.args) && f.context===(pattern.context ?? 'actual') && (f.validFrom || f.validTo)), 'TIME_QUERY', 'A temporal truth assessment requires an explicit at date. A historical query can instead list validity intervals.');
    const positive = this.query({...pattern,polarity:1}), negative = this.query({...pattern,polarity:-1});
    return {kind:'truthResult',state:positive.total ? (negative.total ? 'both':'supported') : (negative.total ? 'refuted':'unknown'),factIds:[...new Set([...positive.rows,...negative.rows].flatMap(r=>r.factIds))]};
  }
  call(name, input) {
    requireString(name,'Function name',100);
    const pure = {
      sum: values => { assert(Array.isArray(values) && values.every(v=>typeof v==='number' && Number.isFinite(v)),'TYPE','sum requires finite numbers.'); const n=values.reduce((a,b)=>a+b,0); assert(Number.isFinite(n),'TYPE','Numeric overflow.'); return n; },
      multiply: values => { assert(Array.isArray(values) && values.every(v=>typeof v==='number' && Number.isFinite(v)),'TYPE','multiply requires finite numbers.'); const n=values.reduce((a,b)=>a*b,1); assert(Number.isFinite(n),'TYPE','Numeric overflow.'); return n; },
      count: value => { assert(Array.isArray(value) || value?.kind==='queryResult','TYPE','count requires an array or query result.'); return Array.isArray(value) ? value.length : value.total; },
      notEqual: value => { assert(Array.isArray(value) && value.length===2,'TYPE','notEqual expects two values.'); return canonical(value[0])!==canonical(value[1]); },
      equals: value => { assert(Array.isArray(value) && value.length===2,'TYPE','equals expects two values.'); return canonical(value[0])===canonical(value[1]); }
    };
    let value;
    if (own(pure,name)) value = pure[name](input);
    else {
      const matches = this.store.list('function').filter(f=>f.name===name || f.id===name);
      assert(matches.length===1 && matches[0].status==='active','FUNCTION','Function must be unique and explicitly approved before execution.');
      const f = matches[0];
      assert(!this.current.stack.includes(f.id) && this.current.stack.length<8,'FUNCTION_CYCLE','Recursive function calls are not allowed.');
      assert(hash(f.code)===f.codeHash,'FUNCTION_INTEGRITY','Stored code hash does not match.');
      conforms(input,f.inputSchema); this.current.stack.push(f.id);
      const old = this.current.readOnly; this.current.readOnly = true;
      try { const api = this.api(); const ast = validateProgram(parseProgram(f.code),READ_API,['input']); value=evaluateProgram(ast,api,{inputs:{input},budget:this.current.budget,trace:this.current.trace}); }
      finally { this.current.readOnly=old; this.current.stack.pop(); }
      conforms(value,f.outputSchema);
    }
    this.current.tools.push({function:name,input,result:value}); return value;
  }
  runHooks(event, input) {
    if (!this.current || this.current.inHook) return;
    const hooks = this.store.list('hook').filter(h=>h.status==='active' && h.event===event && (!h.relation || h.relation===input?.relation));
    assert(hooks.length<=10,'LIMIT','Hook limit exceeded.');
    this.current.inHook=true;
    try { for (const h of hooks) assert(this.call(h.function,input)!==false,'HOOK_VIOLATION',`Hook ${h.name} rejected the proposed operation.`); }
    finally { this.current.inHook=false; }
  }
  api() {
    return {
      ref:id=>{assert(typeof id==='string' && this.store.get(id),'REFERENCE',`Unknown reference ${id}.`);return id;},
      literal:(value,options={})=>{assert(['string','number','boolean'].includes(typeof value),'TYPE','Scalar literal required.');return safeData({kind:'literal',value,datatype:options.datatype ?? typeof value,...(options.unit ? {unit:options.unit}:{})});},
      sourceSpan:(...a)=>this.sourceSpan(...a), claim:(...a)=>this.claim(...a), createEntity:(...a)=>this.createEntity(...a), createEntityType:(...a)=>this.createEntityType(...a),
      createRelationType:(...a)=>this.createRelationType(...a), createFact:(...a)=>this.createFact(...a), createAlias:(...a)=>this.createAlias(...a),
      createRule:(...a)=>this.createRule(...a), createConstraint:(...a)=>this.createConstraint(...a), createFunction:(...a)=>this.createFunction(...a),
      retractFact:(id,reason)=>{this.writable();requireString(reason,'Retraction reason');this.store.mask(id,reason);return id;},
      query:pattern=>this.query(pattern), truth:pattern=>this.truth(pattern),
      explain:id=>explainFact(id,this.getClosure().facts,this.store), call:(...a)=>this.call(...a),
      get:(object,key)=>{assert(object!==null && typeof object==='object' && !bannedKeys.has(String(key)) && own(object,key),'ACCESS','Missing or forbidden data property.');return object[key];},
      clarify:message=>{requireString(message,'Clarification');throw new KBError('NEEDS_INFORMATION',message);},
      respond:value=>renderAnswer(value,this.store,{language:this.options.language,facts:this.getClosure().facts})
    };
  }
  execute(code, {text='Operator-supplied knowledge program.',normalizedText=null,sourceLanguage='en',normalizationMeta=null,sourceName='conversation',sourceKey=null,privateSource=true,dryRun=false,bindings={},allowExplicitNew=false} = {}) {
    requireString(text,'Source text',200000);
    const ast = validateProgram(parseProgram(code),PROGRAM_API);
    const ir = validateKnowledgeIR(toKnowledgeIR(ast)),canonicalIrHash=irHash(ir);
    const before = this.store.snapshot();
    const previous = this.current;
    assert(!previous,'EXECUTION','Nested top-level execution is forbidden.');
    let result;
    try {
      result=this.store.transaction(()=>{
        const turn=Number(this.store.getMeta('turn'))+1;
        const source={id:`source:${hash([this.store.id,sourceKey ?? turn,text]).slice(0,32)}`,kind:'source',name:sourceName,text,normalizedText:normalizedText ?? (sourceLanguage==='en'?text:null),sourceLanguage,normalizationMeta:normalizationMeta?safeData(normalizationMeta):null,internalLanguage:INTERNAL_LANGUAGE,private:privateSource,turn,textHash:hash(text),sourceKey:sourceKey ?? turn};
        const executionId=`execution:${hash([this.store.id,source.id,canonicalIrHash,turn,VERSION_SET]).slice(0,32)}`;
        this.store.put(source);
        this.current={source,turn,executionId,bindings,allowExplicitNew,readOnly:false,writes:0,resolutions:[],resolutionByTarget:new Map(),trace:[],tools:[],stack:[],budget:{remaining:5000}};this.cache=null;
        let value=evaluateProgram(ir,this.api(),{budget:this.current.budget,trace:this.current.trace});
        this.runHooks('beforeCommit',{turn});
        const c=this.getClosure();
        if (value?.kind!=='answer') value=renderAnswer(value,this.store,{language:this.options.language,facts:c.facts});
        value.computations=this.current.tools;
        const inference={complete:c.complete,facts:c.facts.length,rounds:c.rounds,comparisonsUsed:c.comparisonsUsed,conflicts:c.conflicts};
        const resolutionIds=this.current.resolutions.map(r=>r.id ?? r.target).filter(Boolean);
        const executionRecord={id:executionId,kind:'execution',name:`execution:${turn}`,sourceId:source.id,turn,programHash:hash(code),irHash:canonicalIrHash,versions:safeData(VERSION_SET),resolutionIds,
          writes:this.current.writes,answerHash:hash(value),inference:safeData(inference),dryRun:false,status:'committed'};
        this.store.put(executionRecord);
        const output={executionId,answer:value,program:code,ir,irHash:canonicalIrHash,versions:VERSION_SET,resolutions:this.current.resolutions,trace:this.current.trace,
          inference,sourceId:source.id,turn,dryRun};
        this.store.setMeta('turn',turn);
        this.store.event('execution',{executionId,sourceId:source.id,programHash:hash(code),irHash:canonicalIrHash,versions:VERSION_SET,code,answer:value,resolutions:resolutionIds,writes:this.current.writes});
        return output;
      },{dryRun});
    } finally {this.current=null;this.cache=null;}
    return {...result,before,after:this.store.snapshot()};
  }
  /** Read-only operator inspection of accumulated trusted identity evidence. */
  identityProfile(entityId) {
    const entity=this.store.get(entityId);assert(entity?.kind==='entity','IDENTITY','Identity profiles apply to entities.');
    return buildIdentityProfile(this.store,entityId);
  }
  /**
   * Operator-only reversible identity correction. It supersedes one ResolutionDecision,
   * rewrites only directly asserted local facts that recorded that decision as an identity
   * dependency, and lets derived facts be recomputed from the corrected assertion set.
   */
  rebindResolution(resolutionId,newTarget,reason) {
    requireString(reason,'Rebind reason',2000);
    assert(!this.current,'EXECUTION','Identity rebinding cannot run inside a generated program.');
    try{return this.store.transaction(()=>{
      const old=this.store.get(resolutionId);assert(old?.kind==='resolution' && old.layer==='session','IDENTITY','Only a session ResolutionDecision can be rebound.');
      assert(!this.store.list('resolution').some(r=>r.supersedes===old.id),'IDENTITY','This resolution has already been superseded; rebind the current effective decision instead.');
      const target=this.store.get(newTarget);assert(target?.kind==='entity' && target.status!=='orphaned','IDENTITY','New target must be an active entity.');
      assert(old.target!==newTarget,'IDENTITY','New target must differ from the current target.');
      const comparison=this.resolver.compare(old.mention,applyIdentityProfile(target,buildIdentityProfile(this.store,newTarget)));
      assert(!comparison.blockers.length,'IDENTITY_BLOCKER','The proposed rebind conflicts with explicit identity evidence. Correct the formalization/evidence first.',{blockers:comparison.blockers});
      const mention=this.store.list('mention').find(m=>m.resolutionId===old.id || (m.resolutionHistory??[]).includes(old.id));
      assert(mention && mention.layer==='session','IDENTITY','The source mention for this resolution is not locally mutable.');
      const sourceId=old.evidence?.sourceId ?? mention.evidence?.sourceId ?? null;
      const dependent=this.store.local('assertion').filter(f=>(f.identityDependencies??[]).some(d=>d.resolutionId===old.id));
      const untracked=this.store.local('assertion').filter(f=>f.evidence?.sourceId===sourceId && f.args?.includes(old.target) && !(f.identityDependencies??[]).some(d=>d.resolutionId===old.id));
      assert(!untracked.length,'REPLAY_UNTRACKED','Some same-source assertions reference the old target without identity-dependency metadata. Refuse partial replay; re-ingest that legacy source under the current runtime.',{factIds:untracked.map(f=>f.id)});
      const newResolutionId=`resolution:${hash([old.id,newTarget,reason,this.resolver.policyVersion]).slice(0,32)}`;
      const decision={...old,id:newResolutionId,name:`rebind:${old.name}`,target:newTarget,decision:'same',reason:'operator_rebind',operatorReason:reason,policyVersion:this.resolver.policyVersion,
        supersedes:old.id,candidates:[comparison],status:'recorded',createdByExecution:null};
      delete decision.layer;delete decision.createdAt;this.store.put(decision);
      const history=[...(mention.resolutionHistory??[]),old.id];
      this.store.put({...mention,target:newTarget,resolutionId:newResolutionId,resolution:{decision:'same',reason:'operator_rebind',policyVersion:this.resolver.policyVersion},resolutionHistory:history},{replace:true});
      const rewritten=[];
      for(const fact of dependent){
        const relation=this.store.get(fact.relation);assert(relation?.kind==='relation','RELATION','Dependent fact has no relation definition.');
        const args=[...fact.args],dependencies=(fact.identityDependencies??[]).map(d=>({resolutionId:d.resolutionId,positions:[...d.positions]}));
        for(const dep of dependencies)if(dep.resolutionId===old.id){for(const pos of dep.positions){assert(args[pos]===old.target,'REPLAY','Identity dependency does not match the stored argument.');args[pos]=newTarget;}dep.resolutionId=newResolutionId;}
        this.validateFactArgs(relation,args);
        const semantic={relation:fact.relation,args:safeData(args),polarity:fact.polarity,context:fact.context,validFrom:fact.validFrom??null,validTo:fact.validTo??null,qualifiers:safeData(fact.qualifiers??{}),status:fact.status,evidence:safeData(fact.evidence)};
        const newFactId=`fact:${hash(semantic).slice(0,32)}`;
        this.store.put({id:newFactId,kind:'assertion',name:fact.name,...semantic,identityDependencies:safeData(dependencies),reboundFrom:fact.id,reboundByResolution:newResolutionId});
        this.store.mask(fact.id,`Identity resolution ${old.id} superseded by ${newResolutionId}: ${reason}`);rewritten.push({from:fact.id,to:newFactId});
      }
      const oldEntity=this.store.get(old.target);
      if(oldEntity?.kind==='entity' && oldEntity.layer==='session' && oldEntity.createdByResolution===old.id){
        const stillResolved=this.store.list('resolution').some(r=>r.id!==old.id && r.target===old.target && !this.store.list('resolution').some(n=>n.supersedes===r.id));
        const stillReferenced=this.store.local('assertion').some(f=>f.args?.includes(old.target));
        if(!stillResolved&&!stillReferenced)this.store.put({...oldEntity,status:'orphaned',orphanedByResolution:newResolutionId,orphanReason:reason},{replace:true});
      }
      this.cache=null;const closureResult=this.getClosure();this.cache=null;
      this.store.event('resolution_rebind',{from:old.id,to:newResolutionId,oldTarget:old.target,newTarget,reason,rewritten});
      return {from:old.id,to:newResolutionId,oldTarget:old.target,newTarget,rewritten,inference:{facts:closureResult.facts.length,conflicts:closureResult.conflicts}};
    });}finally{this.cache=null;}
  }
  /** Operator API. Deliberately absent from the generated-program API. */
  approve(id, reason) {
    requireString(reason,'Approval reason');
    try { return this.store.transaction(()=>{
      const r=this.store.get(id);assert(r && r.layer!=='base' && ['rule','constraint','function','alias','hook','relation'].includes(r.kind),'POLICY','Only local candidate definitions may be reviewed.');
      if(r.kind==='rule') validateRule(r,id=>this.store.get(id));
      if(r.kind==='function') { validateProgram(parseProgram(r.code),READ_API,['input']); validateSchema(r.inputSchema ?? {}); validateSchema(r.outputSchema ?? {}); }
      this.store.put({...r,status:'active',approvalReason:reason},{replace:true});this.cache=null;
      this.getClosure();this.cache=null;this.store.event('approval',{id,reason});return id;
    }); } finally { this.cache=null; }
  }
}
