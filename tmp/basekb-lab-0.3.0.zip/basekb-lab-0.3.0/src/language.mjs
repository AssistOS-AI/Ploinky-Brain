import { assert, KBError, bannedKeys, own } from './util.mjs';

/** Small JS-looking grammar. No eval, Function, vm, imports, arbitrary member access or host objects. */
export function parseProgram(source, { maxBytes = 65536, maxTokens = 12000, maxDepth = 32, maxStatements = 300 } = {}) {
  assert(typeof source === 'string' && Buffer.byteLength(source) <= maxBytes, 'LIMIT', 'Program exceeds byte limit.');
  const tokens = []; let i = 0;
  const error = message => { throw new KBError('PARSE', `${message} at offset ${i}.`); };
  const add = (type, value, at) => { tokens.push({type, value, at}); assert(tokens.length <= maxTokens, 'LIMIT', 'Token budget exceeded.'); };
  while (i < source.length) {
    if (/\s/u.test(source[i])) { i++; continue; }
    if (source.startsWith('//', i)) { const end = source.indexOf('\n', i + 2); i = end < 0 ? source.length : end + 1; continue; }
    if (source.startsWith('/*', i)) { const end = source.indexOf('*/', i + 2); if (end < 0) error('Unterminated comment'); i = end + 2; continue; }
    const at = i, c = source[i];
    if ('(){}[],:;='.includes(c)) { add(c, c, i++); continue; }
    if (c === '"' || c === "'") {
      const quote = c; let value = ''; i++;
      while (i < source.length && source[i] !== quote) {
        let ch = source[i++];
        if (ch === '\n' || ch === '\r') error('Newline in string');
        if (ch === '\\') {
          const esc = source[i++];
          const escapes = { n:'\n', r:'\r', t:'\t', b:'\b', f:'\f', '\\':'\\', '"':'"', "'":"'", '/':'/' };
          if (esc === 'u') {
            const hex = source.slice(i, i + 4); if (!/^[0-9a-fA-F]{4}$/.test(hex)) error('Bad Unicode escape');
            ch = String.fromCharCode(parseInt(hex, 16)); i += 4;
          } else if (own(escapes, esc)) ch = escapes[esc]; else error('Unsupported escape');
        }
        value += ch;
      }
      if (source[i] !== quote) error('Unterminated string'); i++; add('literal', value, at); continue;
    }
    const num = source.slice(i).match(/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/);
    if (num) { const value = Number(num[0]); if (!Number.isFinite(value)) error('Non-finite number'); i += num[0].length; add('literal', value, at); continue; }
    const id = source.slice(i).match(/^[A-Za-z_$][A-Za-z0-9_$]*/);
    if (id) { i += id[0].length; add('id', id[0], at); continue; }
    error(`Forbidden or unsupported character ${JSON.stringify(c)}`);
  }
  add('eof', '', i); let p = 0;
  const peek = () => tokens[p];
  const pop = type => { const t = tokens[p++]; if (type && t.type !== type) throw new KBError('PARSE', `Expected ${type}, received ${t.type} at ${t.at}.`); return t; };
  const consume = type => peek().type === type ? pop(type) : null;
  function expr(depth = 0) {
    assert(depth <= maxDepth, 'LIMIT', 'Expression nesting limit exceeded.');
    const t = pop();
    if (t.type === 'literal') return { kind:'literal', value:t.value };
    if (t.type === 'id') {
      if (['true','false','null'].includes(t.value)) return { kind:'literal', value: { true:true, false:false, null:null }[t.value] };
      assert(!bannedKeys.has(t.value), 'SECURITY', 'Forbidden identifier.');
      if (consume('(')) {
        const args = [];
        if (peek().type !== ')') { do { args.push(expr(depth + 1)); } while (consume(',') && peek().type !== ')'); }
        pop(')'); return { kind:'call', name:t.value, args };
      }
      return { kind:'variable', name:t.value };
    }
    if (t.type === '[') {
      const items = [];
      if (peek().type !== ']') { do { items.push(expr(depth + 1)); } while (consume(',') && peek().type !== ']'); }
      pop(']'); return { kind:'array', items };
    }
    if (t.type === '{') {
      const entries = [], seen = new Set();
      if (peek().type !== '}') do {
        const key = pop();
        assert((key.type === 'id' || key.type === 'literal') && typeof key.value === 'string', 'PARSE', 'Object keys must be literal strings.');
        assert(!bannedKeys.has(key.value) && !seen.has(key.value), 'SECURITY', 'Forbidden or duplicate object key.');
        seen.add(key.value); pop(':'); entries.push([key.value, expr(depth + 1)]);
      } while (consume(',') && peek().type !== '}');
      pop('}'); return { kind:'object', entries };
    }
    throw new KBError('PARSE', `Unexpected ${t.type} at ${t.at}.`);
  }
  const statements = [];
  while (peek().type !== 'eof') {
    assert(statements.length < maxStatements, 'LIMIT', 'Statement budget exceeded.');
    if (peek().type === 'id' && peek().value === 'const') {
      pop(); const name = pop('id').value;
      assert(!bannedKeys.has(name), 'SECURITY', 'Forbidden variable.'); pop('=');
      statements.push({ kind:'declare', name, value:expr() }); pop(';');
    } else if (peek().type === 'id' && peek().value === 'return') {
      pop(); statements.push({ kind:'return', value:expr() }); consume(';');
      assert(peek().type === 'eof', 'PARSE', 'Return must be the final statement.');
    } else { statements.push({ kind:'expression', value:expr() }); pop(';'); }
  }
  assert(statements.length > 0, 'PARSE', 'Empty program.'); return { version:1, statements };
}
export function validateProgram(ast, allowedNames, inputs = []) {
  const vars = new Set(inputs), allowed = new Set(allowedNames);
  function check(e) {
    if (e.kind === 'variable') assert(vars.has(e.name), 'UNBOUND', `Unbound variable ${e.name}.`);
    else if (e.kind === 'call') { assert(allowed.has(e.name), 'CAPABILITY', `Unavailable operation ${e.name}.`); e.args.forEach(check); }
    else if (e.kind === 'array') e.items.forEach(check);
    else if (e.kind === 'object') e.entries.forEach(([,v]) => check(v));
  }
  for (const s of ast.statements) {
    check(s.value);
    if (s.kind === 'declare') { assert(!vars.has(s.name) && !allowed.has(s.name), 'SHADOW', `Duplicate or reserved variable ${s.name}.`); vars.add(s.name); }
  }
  return ast;
}
export function evaluateProgram(ast, api, { inputs = {}, budget = { remaining:5000 }, trace = [] } = {}) {
  const env = new Map(Object.entries(inputs));
  function step(e) {
    assert(--budget.remaining >= 0, 'LIMIT', 'Execution operation budget exceeded.');
    if (e.kind === 'literal') return e.value;
    if (e.kind === 'variable') { assert(env.has(e.name), 'UNBOUND', e.name); return env.get(e.name); }
    if (e.kind === 'array') return e.items.map(step);
    if (e.kind === 'object') { const out = Object.create(null); for (const [k,v] of e.entries) out[k] = step(v); return out; }
    if (e.kind === 'call') {
      assert(own(api, e.name) && typeof api[e.name] === 'function', 'CAPABILITY', e.name);
      const args = e.args.map(step), result = api[e.name](...args);
      assert(!result?.then, 'ASYNC', 'Probabilistic/network services cannot run inside the deterministic interpreter.');
      trace.push({ operation:e.name, args, result }); return result;
    }
    throw new KBError('AST', 'Unknown expression.');
  }
  let value = null;
  for (const s of ast.statements) {
    value = step(s.value);
    if (s.kind === 'declare') env.set(s.name, value);
    if (s.kind === 'return') return value;
  }
  return value;
}
