import { Store } from './storage.mjs';
import { hash } from './util.mjs';

/** Deliberately small, synthetic bootstrap: ontology + procedures, not encyclopedic coverage. */
export function seed(store) {
  const source = {id:'sys:bootstrapSource',kind:'source',name:'BaseKB Lab bootstrap specification',text:'Synthetic bootstrap ontology and reviewed demonstration rules. Not an external factual knowledge corpus.',private:false};
  const evidence = {sourceId:source.id,start:0,end:source.text.length,quote:source.text,granularity:'whole_source'};
  const types = [
    ['Entity',null,'An identified referent, not necessarily a person or physical object.'],
    ['Type','Entity','A declared entity classification.'],['Person','Entity','A human person.'],
    ['Organization','Entity','An organization, distinct from its products or founders.'],
    ['Place','Entity','A geographic or conceptual location.'],['Concept','Entity','An abstract concept.'],
    ['Artifact','Entity','An artifact, product, document or software system.'],['Literal','Entity','A typed scalar value.'],['Term','Entity','An entity reference or a typed scalar; for uninterpreted RDF import.']
  ];
  for(const [name,parent,description] of types) store.put({id:`sys:${name}`,kind:'type',name,description,parent:parent ? `sys:${parent}` : null,status:'active',evidence});
  store.put(source);
  const defs = [
    ['instanceOf',['entity','type'],['Entity','Type'],'The subject is explicitly declared as an instance of the type.'],
    ['subtypeOf',['subtype','supertype'],['Type','Type'],'Every instance of the subtype is an instance of the supertype.'],
    ['parentOf',['parent','child'],['Person','Person'],'A parent-child relation asserted in this context, without inferring gender or a biological/legal subtype.'],
    ['childOf',['child','parent'],['Person','Person'],'Inverse of parentOf; no gender implied.'],
    ['grandparentOf',['grandparent','grandchild'],['Person','Person'],'Composition of two parentOf relations; no grandfather/grandmother gender inference.'],
    ['ancestorOf',['ancestor','descendant'],['Person','Person'],'Positive transitive ancestor relation in the supplied family model.'],
    ['employedBy',['employee','employer'],['Person','Organization'],'A person has an employment relationship with the organization during the validity interval.'],
    ['employs',['employer','employee'],['Organization','Person'],'Inverse of employedBy, with employer first.'],
    ['locatedIn',['entity','place'],['Entity','Place'],'A contextual location claim; location hierarchy is not automatically transitive.'],
    ['knows',['person','other'],['Person','Person'],'The subject knows the object; neither symmetry nor transitivity is assumed.'],
    ['valueOf',['entity','value'],['Entity','Literal'],'A context-qualified scalar value; not globally functional.'],
    ['bornOn',['person','date'],['Person','Literal'],'An explicitly stated date of birth; conflicting values are not automatically reconciled.']
  ];
  for(const [name,roles,domains,description] of defs) store.put({id:`sys:${name}`,kind:'relation',name,description,arity:roles.length,roles,domains:domains.map(x=>`sys:${x}`),
    symmetric:false,transitive:name==='ancestorOf',irreflexive:['parentOf','childOf','grandparentOf','ancestorOf'].includes(name),
    inverse:({parentOf:'sys:childOf',childOf:'sys:parentOf',employedBy:'sys:employs',employs:'sys:employedBy'})[name] ?? null,
    semanticsKey:`bootstrap:${name}:v1`,status:'active',evidence});
  const atom = (relation,args)=>({relation:`sys:${relation}`,args,polarity:1});
  const rules = [
    ['grandparent','Two parent edges compose into a grandparent edge.',[atom('parentOf',['?x','?y']),atom('parentOf',['?y','?z'])],atom('grandparentOf',['?x','?z'])],
    ['parent-ancestor','Each parent is an ancestor in this demonstration ontology.',[atom('parentOf',['?x','?y'])],atom('ancestorOf',['?x','?y'])]
  ];
  for(const [name,description,body,head] of rules) store.put({id:`sys:rule:${name}`,kind:'rule',name,description,body,head,status:'active',version:1,evidence});
  const aliases = {
    parentOf:['parent of','is parent of'],childOf:['child of'],grandparentOf:['grandparent of'],ancestorOf:['ancestor of'],
    employedBy:['worksAt','employeeOf','works for','worksFor'],employs:['employs people'],locatedIn:['located in','is located in']
  };
  for(const [target,names] of Object.entries(aliases)) for(const name of names) store.put({id:`sys:alias:${hash([name,target]).slice(0,16)}`,kind:'alias',name,target:`sys:${target}`,targetKind:'relation',aliasKind:'synonym',status:'active',evidence});
  const functions = [
    ['countMatches','Count all matches of a bounded, complete query, not just the displayed rows.',
      'const rows = query(input); return call("count", rows);',{type:'object'},{type:'integer'}],
    ['double','Double a supplied finite numeric input.', 'return call("multiply", [input, 2]);',{type:'number'},{type:'number'}],
    ['noSelfParent','A read-only validation hook rejecting a self-parent assertion.',
      'return call("notEqual", [get(input, "subject"), get(input, "object")]);',{type:'object',required:['subject','object']},{type:'boolean'}]
  ];
  for(const [name,description,code,inputSchema,outputSchema] of functions) store.put({id:`sys:function:${name}`,kind:'function',name,description,code,inputSchema,outputSchema,capabilities:['read'],status:'active',version:1,codeHash:hash(code),evidence});
  store.put({id:'sys:hook:noSelfParent',kind:'hook',name:'no-self-parent',event:'afterCreateFact',relation:'sys:parentOf',function:'sys:function:noSelfParent',status:'active',evidence});
  store.setMeta('release','basekb-lab-0.3.0');
  return store;
}
export function createBase(path) {
  const store = new Store({sessionPath:path,writableBase:true});
  try {store.transaction(()=>seed(store));} finally {store.close();}
}
