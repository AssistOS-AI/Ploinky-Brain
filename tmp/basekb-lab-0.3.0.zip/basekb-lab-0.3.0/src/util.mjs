import { createHash, randomUUID } from 'node:crypto';

export class KBError extends Error {
  constructor(code, message, details = {}) { super(message); this.name = 'KBError'; this.code = code; this.details = details; }
  toJSON() { return { code: this.code, message: this.message, details: this.details }; }
}
export function assert(ok, code, message, details) { if (!ok) throw new KBError(code, message, details); }
export const uuid = prefix => `${prefix}:${randomUUID()}`;
export const now = () => new Date().toISOString();
export const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
export const bannedKeys = new Set(['__proto__', 'prototype', 'constructor']);
export function canonical(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
}
export const hash = value => createHash('sha256').update(typeof value === 'string' || Buffer.isBuffer(value) ? value : canonical(value)).digest('hex');
export function safeData(value, depth = 0) {
  assert(depth <= 40, 'LIMIT', 'Data nesting exceeds 40.');
  if (value === null || ['string', 'boolean'].includes(typeof value)) return value;
  if (typeof value === 'number') { assert(Number.isFinite(value), 'TYPE', 'Non-finite number.'); return value; }
  assert(value && typeof value === 'object', 'TYPE', 'Only JSON data is accepted.');
  if (Array.isArray(value)) { assert(value.length <= 20000, 'LIMIT', 'Array too large.'); return value.map(v => safeData(v, depth + 1)); }
  const out = Object.create(null);
  for (const [k, v] of Object.entries(value)) {
    assert(!bannedKeys.has(k), 'SECURITY', `Forbidden data key: ${k}`);
    out[k] = safeData(v, depth + 1);
  }
  return out;
}
export function requireString(s, label, max = 4000) {
  assert(typeof s === 'string' && s.trim().length > 0 && s.length <= max, 'TYPE', `${label} must be a nonempty string (max ${max}).`);
  return s;
}
export function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith('--')) { args._.push(a); continue; }
    const [key, inline] = a.slice(2).split(/=(.*)/s);
    args[key] = inline ?? (argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : true);
  }
  return args;
}
export function iso(value) {
  if (value == null) return null;
  assert(typeof value === 'string' && /^\d{4}-\d\d-\d\d(?:T\d\d:\d\d:\d\d(?:\.\d{1,3})?Z)?$/.test(value), 'TIME', 'Use YYYY-MM-DD or a UTC ISO timestamp.');
  const date = new Date(value);
  assert(Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value.slice(0, 10), 'TIME', `Invalid date: ${value}`);
  return date.toISOString();
}
export function interval(from, to) {
  const validFrom = iso(from), validTo = iso(to);
  assert(!validFrom || !validTo || validFrom < validTo, 'TIME', 'Time intervals are half-open and must have positive length.');
  return { validFrom, validTo };
}
export function intersect(a, b) {
  const validFrom = !a.validFrom ? b.validFrom : !b.validFrom ? a.validFrom : (a.validFrom > b.validFrom ? a.validFrom : b.validFrom);
  const validTo = !a.validTo ? b.validTo : !b.validTo ? a.validTo : (a.validTo < b.validTo ? a.validTo : b.validTo);
  return validFrom && validTo && validFrom >= validTo ? null : { validFrom: validFrom ?? null, validTo: validTo ?? null };
}
/** Deliberately small, validated schema dialect; unsupported keywords fail closed. */
export function validateSchema(schema = {}, depth = 0) {
  assert(schema && typeof schema === 'object' && !Array.isArray(schema) && depth <= 20, 'SCHEMA', 'Schema must be an object; nesting <=20.');
  const allowed = new Set(['type','enum','required','properties','additionalProperties','items','minimum','maximum','description']);
  for (const key of Object.keys(schema)) assert(allowed.has(key), 'SCHEMA', `Unsupported schema keyword: ${key}`);
  if (schema.type !== undefined) assert(['null','boolean','string','number','integer','array','object'].includes(schema.type), 'SCHEMA', 'Unsupported schema type.');
  if (schema.enum !== undefined) assert(Array.isArray(schema.enum) && schema.enum.length > 0, 'SCHEMA', 'enum must be a nonempty array.');
  if (schema.required !== undefined) assert(Array.isArray(schema.required) && schema.required.every(k => typeof k === 'string' && !bannedKeys.has(k)), 'SCHEMA', 'Invalid required properties.');
  if (schema.additionalProperties !== undefined) assert(typeof schema.additionalProperties === 'boolean', 'SCHEMA', 'additionalProperties must be boolean.');
  if (schema.properties !== undefined) {
    assert(schema.properties && typeof schema.properties === 'object' && !Array.isArray(schema.properties), 'SCHEMA', 'properties must be an object.');
    for (const [k,v] of Object.entries(schema.properties)) { assert(!bannedKeys.has(k), 'SCHEMA', 'Forbidden schema property.'); validateSchema(v, depth+1); }
  }
  if (schema.items !== undefined) validateSchema(schema.items, depth+1);
  for (const k of ['minimum','maximum']) if (schema[k] !== undefined) assert(typeof schema[k] === 'number' && Number.isFinite(schema[k]), 'SCHEMA', `${k} must be finite.`);
  assert(schema.minimum === undefined || schema.maximum === undefined || schema.minimum <= schema.maximum, 'SCHEMA', 'Inverted numeric bounds.');
  return schema;
}
export function conforms(value, schema = {}, path = 'input') {
  validateSchema(schema);
  const fail = message => assert(false, 'SCHEMA', `${path}: ${message}`);
  if (schema.enum && !schema.enum.some(x => canonical(x) === canonical(value))) fail('not in enum');
  if (schema.type) {
    const ok = schema.type === 'array' ? Array.isArray(value) : schema.type === 'object' ? value !== null && typeof value === 'object' && !Array.isArray(value) :
      schema.type === 'integer' ? Number.isSafeInteger(value) : schema.type === 'null' ? value === null : typeof value === schema.type;
    if (!ok) fail(`expected ${schema.type}`);
  }
  if (typeof value === 'number') {
    if (schema.minimum != null && value < schema.minimum) fail('below minimum');
    if (schema.maximum != null && value > schema.maximum) fail('above maximum');
  }
  if (Array.isArray(value) && schema.items) value.forEach((v, i) => conforms(v, schema.items, `${path}[${i}]`));
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    for (const k of schema.required ?? []) if (!own(value, k)) fail(`missing ${k}`);
    for (const [k, v] of Object.entries(value)) {
      if (schema.properties?.[k]) conforms(v, schema.properties[k], `${path}.${k}`);
      else if (schema.additionalProperties === false) fail(`unknown property ${k}`);
    }
  }
  return value;
}
export function errorJSON(e) { return e instanceof KBError ? e.toJSON() : { code: 'INTERNAL', message: e.message }; }
