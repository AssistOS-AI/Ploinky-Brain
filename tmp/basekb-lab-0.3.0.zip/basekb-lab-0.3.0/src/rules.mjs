import { assert, hash, canonical, intersect, iso } from './util.mjs';

export const variable = x => typeof x === 'string' && /^\?[A-Za-z][A-Za-z0-9_]*$/.test(x);
const eq = (a, b) => canonical(a) === canonical(b);
export function validateRule(rule, relationLookup) {
  assert(Array.isArray(rule.body) && rule.body.length >= 1 && rule.body.length <= 6 && rule.head, 'RULE', 'Rule requires 1..6 body atoms and one head.');
  const bound = new Set();
  for (const atom of [...rule.body, rule.head]) {
    const rel = relationLookup(atom.relation);
    assert(rel && Array.isArray(atom.args) && atom.args.length === rel.arity, 'RULE', 'Unknown relation or wrong rule arity.');
    assert(atom.polarity == null || [1,-1].includes(atom.polarity), 'RULE', 'Only explicit positive/negative support is supported; no negation-as-failure.');
  }
  for (const atom of rule.body) for (const a of atom.args) if (variable(a)) bound.add(a);
  for (const a of rule.head.args) if (variable(a)) assert(bound.has(a), 'RULE', `Unsafe head variable ${a}.`);
}
export function unify(atom, fact, bindings = {}) {
  if (atom.relation !== fact.relation || (atom.polarity ?? 1) !== fact.polarity || atom.args.length !== fact.args.length) return null;
  const out = { ...bindings };
  for (let i = 0; i < atom.args.length; i++) {
    const p = atom.args[i], v = fact.args[i];
    if (variable(p)) {
      if (Object.hasOwn(out, p) && !eq(out[p], v)) return null;
      out[p] = v;
    } else if (p !== null && !eq(p, v)) return null;
  }
  return out;
}
/** Indexed nested-loop join; budgets count comparisons, not only emitted rows. */
export function join(atoms, facts, { budget = { remaining:200000 }, maxRows = 10000, context = null, at = null } = {}) {
  const idx = new Map();
  const point = iso(at);
  for (const fact of facts) {
    if (context != null && fact.context !== context) continue;
    if (point && ((fact.validFrom && point < fact.validFrom) || (fact.validTo && point >= fact.validTo))) continue;
    const key = `${fact.relation}/${fact.polarity}`;
    if (!idx.has(key)) idx.set(key, []); idx.get(key).push(fact);
  }
  let states = [{ bindings:{}, factIds:[], validFrom:null, validTo:null, context:null, tainted:false }];
  for (const atom of atoms) {
    const next = [];
    for (const state of states) for (const fact of idx.get(`${atom.relation}/${atom.polarity ?? 1}`) ?? []) {
      assert(--budget.remaining >= 0, 'INFERENCE_BUDGET', 'Join comparison budget exhausted; no complete answer can be claimed.');
      if (state.context != null && state.context !== fact.context) continue;
      const span = intersect(state, fact); if (!span) continue;
      const bindings = unify(atom, fact, state.bindings); if (!bindings) continue;
      next.push({ bindings, factIds:[...state.factIds, fact.id], ...span, context:fact.context, tainted:state.tainted || !!fact.tainted });
      assert(next.length <= maxRows, 'INFERENCE_BUDGET', 'Intermediate join row limit exceeded.');
    }
    states = next;
    if (!states.length) break;
  }
  return states;
}
export const factKey = f => canonical({ relation:f.relation, args:f.args, polarity:f.polarity, context:f.context, validFrom:f.validFrom, validTo:f.validTo, qualifiers:f.qualifiers ?? {} });
export function markConflicts(facts) {
  const groups = new Map();
  for (const f of facts) {
    const k = canonical([f.relation, f.args, f.context, f.qualifiers ?? {}]);
    if (!groups.has(k)) groups.set(k, []); groups.get(k).push(f);
  }
  const conflicts = []; let checks=0;
  for (const group of groups.values()) {
    const pos = group.filter(f => f.polarity === 1), neg = group.filter(f => f.polarity === -1);
    for (const a of pos) for (const b of neg) { assert(++checks<=200000,'INFERENCE_BUDGET','Conflict-comparison budget exhausted.'); if (intersect(a, b)) {
      a.tainted = true; b.tainted = true; conflicts.push({ positive:a.id, negative:b.id, context:a.context });
      assert(conflicts.length<=2000,'INFERENCE_BUDGET','Conflict output budget exceeded.');
    }}
  }
  return conflicts;
}
export function closure(assertions, rules, { maxFacts = 10000, maxRounds = 32, comparisons = 200000 } = {}) {
  const facts = assertions.filter(f => f.status === 'accepted').map(f => ({...f}));
  assert(facts.length <= maxFacts, 'INFERENCE_BUDGET', 'Fact budget exceeded.');
  let conflicts = markConflicts(facts);
  const keys = new Map(facts.map(f => [factKey(f), f]));
  const budget = { remaining:comparisons }; let rounds = 0, complete = false;
  const active = rules.filter(r => r.status === 'active').sort((a,b) => a.id.localeCompare(b.id));
  // Safe finite-domain positive/explicit-negative Horn closure. No fresh entity creation.
  for (; rounds < maxRounds; rounds++) {
    const additions = [];
    for (const rule of active) {
      for (const row of join(rule.body, facts, { budget, maxRows:maxFacts })) {
        const f = { relation:rule.head.relation, args:rule.head.args.map(a => variable(a) ? row.bindings[a] : a),
          polarity:rule.head.polarity ?? 1, context:row.context, validFrom:row.validFrom, validTo:row.validTo, qualifiers:{},
          status:'accepted', kind:'assertion', derived:true, rule:rule.id, ruleVersion:rule.version ?? 1,
          premises:row.factIds, tainted:row.tainted, name:rule.name };
        const key = factKey(f);
        if (keys.has(key)) continue; // A representative proof is retained, not every exponentially many proof path.
        f.id = `derived:${hash([key, rule.id, f.premises]).slice(0, 32)}`;
        keys.set(key, f); additions.push(f);
        assert(keys.size <= maxFacts, 'INFERENCE_BUDGET', 'Inferred fact budget exceeded.');
      }
    }
    if (!additions.length) { complete = true; break; }
    facts.push(...additions); conflicts = markConflicts(facts);
  }
  assert(complete, 'INFERENCE_BUDGET', 'Fixed point not reached within the round budget.');
  // Propagate warnings if conflicts were discovered after a descendant was produced.
  const byId = new Map(facts.map(f => [f.id, f]));
  for (let i=0; i<facts.length; i++) {
    let changed = false;
    for (const f of facts) if (!f.tainted && f.premises?.some(id => byId.get(id)?.tainted)) { f.tainted = true; changed = true; }
    if (!changed) break;
  }
  return { facts, conflicts, complete:true, rounds:rounds + 1, comparisonsUsed:comparisons - budget.remaining };
}
export function checkConstraints(facts, relations, constraints) {
  const violations = [], rels = new Map(relations.map(r => [r.id, r]));
  let comparisons = 200000;
  const active = facts.filter(f => f.polarity === 1);
  for (const f of active) {
    const r = rels.get(f.relation);
    if ((r?.status === 'active' || r?.metadataStatus === 'active') && r?.irreflexive && eq(f.args[0], f.args[1])) violations.push({ kind:'irreflexive', relation:r.id, factIds:[f.id] });
  }
  for (const c of constraints.filter(c => c.status === 'active')) {
    const subset = active.filter(f => f.relation === c.relation);
    if (c.constraintKind === 'irreflexive') {
      for (const f of subset) if (eq(f.args[0], f.args[1])) violations.push({ kind:c.constraintKind, constraint:c.id, factIds:[f.id] });
    } else if (c.constraintKind === 'functional') {
      const groups = new Map();
      for (const f of subset) {
        const k = canonical([f.context, (c.keyPositions ?? [0]).map(i => f.args[i])]);
        if (!groups.has(k)) groups.set(k, []); groups.get(k).push(f);
      }
      for (const group of groups.values()) for (let i=0; i<group.length; i++) for (let j=i+1; j<group.length; j++) {
        assert(--comparisons >= 0, 'CONSTRAINT_BUDGET', 'Constraint comparison budget exceeded.');
        assert(violations.length < 2000, 'CONSTRAINT_BUDGET', 'Too many constraint violations.');
        if (!eq(group[i].args[c.valuePosition ?? 1], group[j].args[c.valuePosition ?? 1]) && intersect(group[i], group[j]))
          violations.push({ kind:'functional', constraint:c.id, factIds:[group[i].id, group[j].id] });
      }
    }
  }
  return violations;
}
