import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import readline from 'node:readline/promises';
import { Store, promote } from './storage.mjs';
import { Engine } from './engine.mjs';
import { ChatAgent, LocalLLM } from './llm.mjs';
import { AutoFormaliser } from './formaliser.mjs';
import { createBase } from './seed.mjs';
import { parseArgs, assert, errorJSON } from './util.mjs';
import { VERSION_SET, INTERNAL_LANGUAGE } from './versions.mjs';

const args=parseArgs(process.argv.slice(2)),command=args._[0] ?? 'help';
if(command==='help'){
  console.log(`BaseKB Lab CLI (Node >=22.16, zero npm dependencies)
  node src/cli.mjs chat [--demo] [--session data/chat.sqlite]
  node src/cli.mjs run examples/family.mjs --source examples/family.txt [--dry-run]
  node src/cli.mjs inspect [--session ...]
  node src/cli.mjs fork output.sqlite [--session ...]
  node src/cli.mjs ingest input.json|input.nt|input.txt|base.sqlite [--session ...] [--output staging.sqlite]
  node src/cli.mjs approve record-id --reason 'review rationale' [--session ...]
  node src/cli.mjs identity-profile entity-id [--session ...]
  node src/cli.mjs rebind-resolution resolution-id target-entity-id --reason 'correction rationale' [--session ...]
  node src/cli.mjs audit [--session ...]
  node src/cli.mjs promote new-base.sqlite --ids id1,id2 --reason 'review rationale' [--include-private]
  node src/cli.mjs export archive.json [--session ...]
Local model settings: LLM_BASE_URL, LLM_MODEL, LLM_API_KEY. No hosted fallback.
Ingestion always uses a NEW staged session file, leaving the original session unchanged.`);
}else{
  const base=resolve(args.base ?? 'data/base.sqlite');if(!existsSync(base))createBase(base);
  let store=new Store({basePath:base,sessionPath:resolve(args.session ?? 'data/cli-session.sqlite')}),engine=new Engine(store);
  try{
    const agent=new ChatAgent(engine,{demo:!!args.demo,llm:new LocalLLM()});
    if(command==='run'){
      const code=readFileSync(args._[1],'utf8'),text=args.source?readFileSync(args.source,'utf8'):'Operator-supplied program.';
      const result=engine.execute(code,{text,dryRun:!!args['dry-run']});console.log(JSON.stringify(result,null,2));
    }else if(command==='inspect')console.log(JSON.stringify({id:store.id,internalLanguage:INTERNAL_LANGUAGE,versions:VERSION_SET,records:store.list(),events:store.events(20)},null,2));
    else if(command==='fork'){const child=store.fork(resolve(args._[1]));console.log(`Fork created: ${args._[1]}`);child.close();}
    else if(command==='approve')console.log(engine.approve(args._[1],args.reason));
    else if(command==='identity-profile')console.log(JSON.stringify(engine.identityProfile(args._[1]),null,2));
    else if(command==='rebind-resolution')console.log(JSON.stringify(engine.rebindResolution(args._[1],args._[2],args.reason),null,2));
    else if(command==='audit'){const report=store.verifyAuditChain();console.log(JSON.stringify(report,null,2));if(!report.ok)process.exitCode=2;}
    else if(command==='promote'){
      assert(typeof args.ids==='string','PROMOTION','Provide --ids id1,id2.');
      console.log(promote(store,resolve(args._[1]),args.ids.split(','),{reason:args.reason,includePrivate:!!args['include-private']}));
    }else if(command==='export'){
      writeFileSync(args._[1],JSON.stringify({format:'basekb-record-archive-v2',records:store.exportRecords(),events:store.events(1000),audit:store.verifyAuditChain()},null,2),{mode:0o600});
      console.log('Wrote a private audit archive. This format is for inspection, not exchange ingestion.');
    }else if(command==='ingest'){
      const output=resolve(args.output ?? `data/ingest-${Date.now()}.sqlite`);const staged=store.fork(output);
      try{
        const e=new Engine(staged),a=new ChatAgent(e,{llm:new LocalLLM()});
        const result=await new AutoFormaliser(e,{agent:a}).ingestFile(resolve(args._[1]));
        const reportPath=`${output}.report.json`;writeFileSync(reportPath,JSON.stringify(result,null,2),{mode:0o600});
        console.log(JSON.stringify({stagedSession:output,report:reportPath,complete:result.complete ?? true,originalSessionUnchanged:true},null,2));
        if(result.complete===false)process.exitCode=2;
      }finally{staged.close();}
    }else if(command==='chat'){
      console.log(`Session ${store.id}\nMode: ${args.demo?'controlled demo, no LLM':'local LLM'}\n/exit, /stats, /choose N (after an ambiguity; 0 = distinct entity).`);
      const rl=readline.createInterface({input:process.stdin,output:process.stdout});let pending=null;
      try{while(true){let text;try{text=(await rl.question('You> ')).trim();}catch{break;}if(!text)continue;if(text==='/exit')break;
        if(text==='/stats'){console.log({entities:store.list('entity').length,assertions:store.list('assertion').length});continue;}
        try{
          let result;
          if(text.startsWith('/choose ')){
            assert(pending,'PENDING','No pending ambiguity.');const n=Number(text.slice(8));const target=n===0?'__new__':pending.error.details.candidates[n-1]?.id;
            assert(target,'PENDING','Invalid candidate number.');
            result=await agent.run(pending.sourceText,{code:pending.program,bindings:{...pending.bindings,[pending.error.details.mentionKey]:target},normalization:pending.inputNormalization});
          }else result=await agent.run(text);
          if(result.needsClarification){console.log(result.error.message);if(result.error.code==='AMBIGUOUS'){
            pending=result;for(const [i,c]of result.error.details.candidates.entries())console.log(`${i+1}. ${c.name}: ${c.description} ${c.blockers?.length?'[blocked]':''}`);console.log('0. A distinct new entity');
          }}else{pending=null;console.log(`KB> ${result.answer.displayText ?? result.answer.text}`);for(const w of result.answer.warnings ?? [])console.log(`  ${w}`);}
          if(args.verbose)console.log(JSON.stringify(result,null,2));
        }catch(e){console.error(JSON.stringify(errorJSON(e),null,2));}
      }}finally{rl.close();}
    }else throw new Error(`Unknown command ${command}. Use help.`);
  }catch(e){console.error(JSON.stringify(errorJSON(e),null,2));process.exitCode=1;}finally{store.close();}
}
