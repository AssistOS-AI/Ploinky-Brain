import { DatabaseSync } from 'node:sqlite';
import { existsSync, readFileSync, mkdirSync, chmodSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { assert, hash, now, safeData, uuid, canonical } from './util.mjs';
import { VERSION_SET, SCHEMA_VERSION, INTERNAL_LANGUAGE } from './versions.mjs';
const DDL = `
PRAGMA foreign_keys=ON;
PRAGMA trusted_schema=OFF;
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT;
CREATE TABLE IF NOT EXISTS records(
 id TEXT PRIMARY KEY, kind TEXT NOT NULL, name TEXT NOT NULL, data TEXT NOT NULL CHECK(json_valid(data)), created_at TEXT NOT NULL
) STRICT;
CREATE INDEX IF NOT EXISTS records_kind ON records(kind);
CREATE INDEX IF NOT EXISTS records_name ON records(kind,name);
CREATE TABLE IF NOT EXISTS masks(id TEXT PRIMARY KEY, reason TEXT NOT NULL, created_at TEXT NOT NULL) STRICT;
CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY, at TEXT NOT NULL, kind TEXT NOT NULL, data TEXT NOT NULL CHECK(json_valid(data))) STRICT;
`;
function unpack(row) { return row ? { ...JSON.parse(row.data), id: row.id, kind: row.kind, name: row.name, createdAt: row.created_at } : null; }
function eventPayload(row) { return row ? JSON.parse(row.data) : null; }
function eventDigest(row) {
  if (!row) return null;
  const data=eventPayload(row),audit=data?._audit;
  if (audit?.eventHash) return audit.eventHash;
  return hash({legacy:true,seq:row.seq,at:row.at,kind:row.kind,data});
}
function init(db, role) {
  db.exec(DDL);
  db.prepare('INSERT OR IGNORE INTO meta VALUES(?,?)').run('schemaVersion', SCHEMA_VERSION);
  db.prepare('INSERT OR IGNORE INTO meta VALUES(?,?)').run('role', role);
  for (const [key,value] of Object.entries(VERSION_SET)) db.prepare('INSERT OR IGNORE INTO meta VALUES(?,?)').run(key, String(value));
  assert(db.prepare('SELECT value FROM meta WHERE key=?').get('schemaVersion')?.value === SCHEMA_VERSION, 'VERSION', 'Unsupported SQLite schema.');
  assert(db.prepare('SELECT value FROM meta WHERE key=?').get('internalLanguage')?.value === INTERNAL_LANGUAGE, 'INTERNAL_LANGUAGE', 'Knowledge stores must use English semantic representation.');
}
export class Store {
  constructor({ basePath = null, sessionPath = ':memory:', writableBase = false } = {}) {
    this.basePath = basePath && resolve(basePath); this.sessionPath = sessionPath; this.writableBase = writableBase; this.inTransaction = false;
    if (sessionPath !== ':memory:') mkdirSync(dirname(resolve(sessionPath)), { recursive: true, mode: 0o700 });
    this.db = new DatabaseSync(sessionPath, { timeout: 3000, allowExtension: false });
    init(this.db, writableBase ? 'base' : 'session');
    if (sessionPath !== ':memory:') chmodSync(sessionPath, 0o600);
    this.base = null;
    if (basePath) {
      assert(existsSync(basePath), 'BASE_MISSING', 'BaseKB does not exist. Run npm run init.');
      assert(resolve(basePath) !== resolve(sessionPath), 'CONFIG', 'Base and session must be different files.');
      this.base = new DatabaseSync(basePath, { readOnly: true, allowExtension: false });
      this.base.exec('PRAGMA trusted_schema=OFF; PRAGMA query_only=ON');
      assert(this.base.prepare('SELECT value FROM meta WHERE key=?').get('schemaVersion')?.value === SCHEMA_VERSION, 'VERSION', 'Unsupported BaseKB version.');
      assert(this.base.prepare('SELECT value FROM meta WHERE key=?').get('internalLanguage')?.value === INTERNAL_LANGUAGE, 'INTERNAL_LANGUAGE', 'BaseKB semantic representation must be English.');
      const digest = hash(readFileSync(basePath));
      const pinned = this.getMeta('baseDigest');
      assert(!pinned || pinned === digest, 'BASE_CHANGED', 'Session is pinned to another BaseKB file digest. Keep the original base or explicitly migrate.');
      this.setMeta('baseDigest', digest);
    }
    if (!this.getMeta('id')) this.setMeta('id', uuid(writableBase ? 'base' : 'session'));
    if (!this.getMeta('turn')) this.setMeta('turn', '0');
  }
  get id() { return this.getMeta('id'); }
  getMeta(k) { return this.db.prepare('SELECT value FROM meta WHERE key=?').get(k)?.value; }
  setMeta(k, v) { this.db.prepare('INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, String(v)); }
  get(id, { includeMasked = false } = {}) {
    if (!includeMasked && this.db.prepare('SELECT 1 FROM masks WHERE id=?').get(id)) return null;
    const local = unpack(this.db.prepare('SELECT * FROM records WHERE id=?').get(id));
    if (local) return { ...local, layer: this.writableBase ? 'base' : 'session' };
    const base = this.base && unpack(this.base.prepare('SELECT * FROM records WHERE id=?').get(id));
    return base ? { ...base, layer: 'base' } : null;
  }
  list(kind) {
    const rows = db => (kind ? db.prepare('SELECT * FROM records WHERE kind=? ORDER BY id').all(kind) : db.prepare('SELECT * FROM records ORDER BY id').all()).map(unpack);
    const result = new Map();
    if (this.base) for (const r of rows(this.base)) result.set(r.id, { ...r, layer: 'base' });
    for (const r of rows(this.db)) result.set(r.id, { ...r, layer: this.writableBase ? 'base' : 'session' });
    for (const m of this.db.prepare('SELECT id FROM masks').all()) result.delete(m.id);
    return [...result.values()];
  }
  local(kind) { return this.list(kind).filter(x => x.layer === 'session' || this.writableBase); }
  put(record, { replace = false } = {}) {
    const r = safeData(JSON.parse(JSON.stringify(record)));
    assert(r.id && r.kind && typeof r.name === 'string', 'RECORD', 'Record requires id/kind/name.');
    if (r.kind !== 'source') {
      if (r.internalLanguage === undefined) r.internalLanguage = INTERNAL_LANGUAGE;
      assert(r.internalLanguage === INTERNAL_LANGUAGE, 'INTERNAL_LANGUAGE', `Semantic record ${r.kind} must use English internally.`);
    }
    const old = this.get(r.id, { includeMasked: true });
    if (old && !replace) return old;
    assert(!old || old.layer !== 'base' || this.writableBase, 'IMMUTABLE', 'Base records cannot be overwritten.');
    const { id, kind, name, layer, createdAt, ...data } = r;
    this.db.prepare('INSERT INTO records VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET kind=excluded.kind,name=excluded.name,data=excluded.data')
      .run(id, kind, name, JSON.stringify(data), createdAt ?? now());
    return this.get(id);
  }
  mask(id, reason) {
    const r = this.get(id);
    assert(r?.kind === 'assertion', 'POLICY', 'Only assertions can be retracted in this prototype.');
    this.db.prepare('INSERT OR REPLACE INTO masks VALUES(?,?,?)').run(id, reason, now());
    this.event('retract', { id, reason });
  }
  event(kind, data) {
    const clean=safeData(data); assert(!Object.hasOwn(clean,'_audit'),'AUDIT','_audit is reserved for the append-only event chain.');
    const previous=this.db.prepare('SELECT * FROM events ORDER BY seq DESC LIMIT 1').get();
    const seq=(previous?.seq ?? 0)+1,at=now(),prevHash=eventDigest(previous);
    const eventHash=hash({auditVersion:'1.0',seq,at,kind,data:clean,prevHash});
    const payload={...clean,_audit:{version:'1.0',prevHash,eventHash}};
    this.db.prepare('INSERT INTO events(seq,at,kind,data) VALUES(?,?,?,?)').run(seq,at,kind,JSON.stringify(payload));
    return {seq,at,kind,eventHash};
  }
  events(limit = 100) { return this.db.prepare('SELECT * FROM events ORDER BY seq DESC LIMIT ?').all(Math.max(1, Math.min(1000, limit))).map(x => ({ ...x, data: JSON.parse(x.data) })); }
  verifyAuditChain() {
    const rows=this.db.prepare('SELECT * FROM events ORDER BY seq').all();let previous=null,audited=0,legacyUnsealed=0;const errors=[];
    for(const row of rows){
      const data=eventPayload(row),audit=data?._audit,expectedPrev=eventDigest(previous);
      if(audit?.eventHash){
        const clean={...data};delete clean._audit;
        const expected=hash({auditVersion:'1.0',seq:row.seq,at:row.at,kind:row.kind,data:clean,prevHash:expectedPrev});
        if(audit.version!=='1.0')errors.push({seq:row.seq,kind:'unsupported_audit_version',version:audit.version});
        if(audit.prevHash!==expectedPrev)errors.push({seq:row.seq,kind:'previous_hash_mismatch',expected:expectedPrev,actual:audit.prevHash});
        if(audit.eventHash!==expected)errors.push({seq:row.seq,kind:'event_hash_mismatch',expected,actual:audit.eventHash});
        audited++;
      }else legacyUnsealed++;
      previous=row;
    }
    return {ok:errors.length===0,events:rows.length,audited,legacyUnsealed,headHash:eventDigest(previous),errors};
  }
  transaction(fn, { dryRun = false } = {}) {
    assert(!this.inTransaction, 'TRANSACTION', 'Nested transactions are not allowed.');
    this.db.exec('BEGIN IMMEDIATE'); this.inTransaction = true;
    try {
      const value = fn();
      assert(!value?.then, 'TRANSACTION', 'Do not await network or LLM calls inside SQLite transactions.');
      this.db.exec(dryRun ? 'ROLLBACK' : 'COMMIT'); return value;
    } catch (e) { this.db.exec('ROLLBACK'); throw e; }
    finally { this.inTransaction = false; }
  }
  fork(path) {
    assert(!this.inTransaction && !existsSync(path), 'FORK', 'Fork target must not exist and no transaction may be active.');
    mkdirSync(dirname(resolve(path)), { recursive: true, mode: 0o700 });
    this.db.prepare('VACUUM INTO ?').run(resolve(path));
    const child = new Store({ basePath: this.basePath, sessionPath: path });
    child.setMeta('parentSession', this.id); child.setMeta('id', uuid('session')); child.event('fork', { parent: this.id });
    return child;
  }
  snapshot() { return hash({ records: this.list(), masks: this.db.prepare('SELECT * FROM masks ORDER BY id').all(), turn: this.getMeta('turn') }); }
  exportRecords() { return this.list().map(({ layer, ...record }) => record); }
  close() { this.base?.close(); this.db.close(); }
}
/** Trusted operator action: creates a NEW BaseKB, never mutates the old one. */
export function promote(store, outputPath, ids, { reason, includePrivate = false } = {}) {
  assert(reason?.trim() && !existsSync(outputPath) && ids.length, 'PROMOTION', 'Provide a reason, selected IDs, and a new output path.');
  const wanted = new Set(ids), records = new Map(store.list().map(r => [r.id, r]));
  function visit(id) {
    const r = records.get(id); assert(r, 'PROMOTION', `Missing dependency ${id}.`);
    assert(!r.private || includePrivate, 'PRIVACY', 'Private source promotion requires --include-private.');
    assert(!['function','rule','constraint','alias','hook','relation'].includes(r.kind) || r.status === 'active' || (r.kind === 'relation' && r.metadataStatus === 'active'), 'POLICY', 'Candidate executable/schema definitions require separate review before promotion.');
    const walk = v => {
      if (typeof v === 'string' && records.has(v) && !wanted.has(v)) { wanted.add(v); visit(v); }
      else if (Array.isArray(v)) v.forEach(walk);
      else if (v && typeof v === 'object') Object.values(v).forEach(walk);
    };
    walk(r);
  }
  for (const id of [...wanted]) visit(id);
  const out = new Store({ sessionPath: outputPath, writableBase: true });
  try {
    out.transaction(() => {
      // Existing base knowledge, except explicitly retracted assertions, plus reviewed selection.
      for (const r of store.list().filter(x => x.layer === 'base' || wanted.has(x.id))) out.put(({ ...r, layer: undefined, promotedFrom: store.id, promotionReason: reason }));
      out.event('promotion', { session: store.id, ids, reason });
    });
  } finally { out.close(); }
  return { path: outputPath, records: wanted.size };
}
