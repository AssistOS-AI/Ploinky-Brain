export const INTERNAL_LANGUAGE = 'en';
export const SCHEMA_VERSION = '2';
export const KNOWLEDGE_IR_VERSION = '1.0';
export const PROGRAM_API_VERSION = '1.0';
export const RESOLVER_POLICY_VERSION = '3.0';
export const INFERENCE_VERSION = '1.0';
export const IDENTITY_PROFILE_VERSION = '1.0';
export const AUDIT_CHAIN_VERSION = '1.0';
export const PROMPT_VERSION = '2.1';

export const VERSION_SET = Object.freeze({
  schemaVersion: SCHEMA_VERSION,
  internalLanguage: INTERNAL_LANGUAGE,
  knowledgeIRVersion: KNOWLEDGE_IR_VERSION,
  programApiVersion: PROGRAM_API_VERSION,
  resolverPolicyVersion: RESOLVER_POLICY_VERSION,
  inferenceVersion: INFERENCE_VERSION,
  identityProfileVersion: IDENTITY_PROFILE_VERSION,
  auditChainVersion: AUDIT_CHAIN_VERSION,
  promptVersion: PROMPT_VERSION
});
