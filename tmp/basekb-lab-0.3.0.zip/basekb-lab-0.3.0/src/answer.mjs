import { canonical } from './util.mjs';
import { INTERNAL_LANGUAGE } from './versions.mjs';

export function label(term, store) {
  if (term && typeof term === 'object' && term.kind === 'literal') return `${term.value}${term.unit ? ` ${term.unit}` : ''}`;
  if (typeof term === 'string') return store.get(term)?.name ?? term;
  return canonical(term);
}
export function explainFact(id, facts, store, seen = new Set(), depth = 0, budget = {remaining:200}) {
  const fact = facts.find(f => f.id === id) ?? store.get(id, {includeMasked:true});
  if (!fact) return { id, missing:true };
  if (--budget.remaining < 0 || seen.has(id) || depth >= 12) return {id, shortened:true};
  seen.add(id);
  return { id, relation:store.get(fact.relation)?.name ?? fact.relation, arguments:fact.args?.map(t => ({value:t, label:label(t, store)})),
    polarity:fact.polarity, context:fact.context, validFrom:fact.validFrom, validTo:fact.validTo,
    source:fact.evidence ?? null, rule:fact.rule ?? null, tainted:!!fact.tainted,
    premises:fact.premises?.map(p => explainFact(p, facts, store, seen, depth + 1, budget)) ?? [] };
}
/** Internal answers are always English. Localization is a separate, non-authoritative edge step. */
export function renderAnswer(value, store, { language = INTERNAL_LANGUAGE, facts = [] } = {}) {
  if (language !== INTERNAL_LANGUAGE) throw new Error('renderAnswer is an internal semantic renderer and only supports English.');
  const proofSeen=new Set(),proofBudget={remaining:200};
  const explain=id=>explainFact(id,facts,store,proofSeen,0,proofBudget);
  if (value?.kind === 'queryResult') {
    const text = value.rows.length ? value.rows.map(row => {
      const selected = Object.entries(row.bindings).map(([key, val]) => `${key.slice(1)} = ${label(val, store)}`);
      const main=selected.length ? selected.join('; ') : 'The statement has support in this context.';
      const time=(row.validFrom || row.validTo) ? ` [${row.validFrom ?? '-∞'}, ${row.validTo ?? '+∞'})` : '';
      return main+time+(row.context!=='actual'?` [context: ${row.context}]`:'');
    }).join('\n') : 'No support was found in the queried knowledge and context. This does not establish falsity.';
    const warnings = [...(value.warnings ?? [])];
    if (value.truncated) warnings.push(`Showing ${value.rows.length} of ${value.total} results.`);
    return { kind:'answer', internalLanguage:INTERNAL_LANGUAGE, text, value, warnings, evidence:[...new Set(value.rows.flatMap(r => r.factIds))].map(explain) };
  }
  if (value?.kind === 'truthResult') {
    const labels = { supported:'Supported', refuted:'Explicitly refuted', both:'Conflict: positive and negative support', unknown:'Unknown' };
    return { kind:'answer', internalLanguage:INTERNAL_LANGUAGE, text:labels[value.state], value, warnings:[], evidence:value.factIds.map(explain) };
  }
  if (value?.kind === 'clarification') return {kind:'answer', internalLanguage:INTERNAL_LANGUAGE, text:value.message, value, warnings:['No changes were applied.'], evidence:[]};
  if (value?.kind === 'toolResult') return {kind:'answer', internalLanguage:INTERNAL_LANGUAGE, text:JSON.stringify(value.value), value, warnings:['Procedural result; it is not automatically a fact about the world.'], evidence:[], computation:value.trace};
  return {kind:'answer', internalLanguage:INTERNAL_LANGUAGE, text:typeof value === 'string' ? value : JSON.stringify(value), value, warnings:['Program-produced text/value; it is not automatically a semantically verified conclusion.'], evidence:[]};
}
