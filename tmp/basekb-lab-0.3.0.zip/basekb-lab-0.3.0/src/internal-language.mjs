import { assert, requireString, safeData } from './util.mjs';
import { INTERNAL_LANGUAGE } from './versions.mjs';

/**
 * We intentionally do not pretend that a regex can prove that prose is English.
 * Language normalization is an LLM boundary responsibility. The deterministic
 * kernel instead carries and checks explicit language metadata so non-English
 * semantic payloads cannot enter through trusted exchange formats unnoticed.
 */
export function internalText(text, field = 'Internal semantic text') {
  requireString(text, field, 10000);
  return text;
}

export function assertInternalLanguageTag(tag, context = 'record') {
  assert(tag === INTERNAL_LANGUAGE, 'INTERNAL_LANGUAGE', `${context} must declare internalLanguage=${INTERNAL_LANGUAGE}.`);
  return tag;
}

export function semanticEnvelope(value) {
  return safeData({ internalLanguage: INTERNAL_LANGUAGE, value });
}
