#!/usr/bin/env bash
set -euo pipefail
# Explicit optional build. This script neither uses sudo nor changes the system CUDA driver.
# Usage: LLAMA_CPP_REV=<reviewed tag or commit> bash scripts/build-llama.sh
: "${LLAMA_CPP_REV:?Set LLAMA_CPP_REV to a reviewed llama.cpp tag or commit. Record it with your evaluation.}"
for command in git cmake nvcc; do command -v "$command" >/dev/null || { echo "Missing $command. See docs/guides/DGX_SPARK.md" >&2; exit 1; }; done
root="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$root/vendor" "$root/reports"
repo="$root/vendor/llama.cpp"
if [ ! -d "$repo/.git" ]; then git clone https://github.com/ggml-org/llama.cpp.git "$repo"; fi
if [ -n "$(git -C "$repo" status --porcelain)" ]; then echo "Refusing to overwrite local llama.cpp changes." >&2; exit 1; fi
git -C "$repo" fetch --tags origin
git -C "$repo" checkout --detach "$LLAMA_CPP_REV"
git -C "$repo" rev-parse HEAD > "$root/reports/llama-cpp-commit.txt"
# Let CUDA/CMake detect the installed GPU. CUDA_ARCH may be supplied explicitly by the operator.
extra=(); if [ -n "${CUDA_ARCH:-}" ]; then extra+=("-DCMAKE_CUDA_ARCHITECTURES=$CUDA_ARCH"); fi
cmake -S "$repo" -B "$repo/build" -DGGML_CUDA=ON -DCMAKE_BUILD_TYPE=Release "${extra[@]}"
cmake --build "$repo/build" --config Release -j "${JOBS:-8}" --target llama-server
printf '\nBuilt %s\n' "$repo/build/bin/llama-server"
