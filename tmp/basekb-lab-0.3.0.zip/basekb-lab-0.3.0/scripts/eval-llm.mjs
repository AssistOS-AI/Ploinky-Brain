/** Real local endpoint evaluation. No demo fallback and no fabricated model results. */
import { mkdtempSync, rmSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Store } from '../src/storage.mjs';
import { Engine } from '../src/engine.mjs';
import { createBase } from '../src/seed.mjs';
import { LocalLLM, ChatAgent } from '../src/llm.mjs';
import { parseArgs, hash, errorJSON, assert } from '../src/util.mjs';
const args=parseArgs(process.argv.slice(2));
const all=JSON.parse(readFileSync(new URL('../eval/llm-cases.json',import.meta.url),'utf8'));
const cases=args.case?all.filter(c=>c.id===args.case):all;assert(cases.length,'CASE','Unknown --case.');
const repeats=Number(args.repeats ?? 1);assert(Number.isSafeInteger(repeats)&&repeats>=1&&repeats<=10,'LIMIT','--repeats must be 1..10.');
const llm=new LocalLLM(),health=await llm.health();mkdirSync('reports',{recursive:true});
const path=args.output ?? 'reports/llm-eval.json';
const report={createdAt:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,
  datasetHash:hash(all),model:llm.model,endpoint:llm.baseURL,repeats,health,status:health.ok?'running':'not_run',
  caveats:['Small authored diagnostic suite, not an independent held-out benchmark.','These tests check selected facts and final structured answers, not all semantic entailments.',
    'Review programs, unsupported extra claims, aliases and source spans manually.','No estimated or mocked model scores are substituted.'],results:[]};
const save=()=>writeFileSync(path,JSON.stringify(report,null,2),{mode:0o600});
function evaluate(c,result,store){
  const issues=[];if(result?.needsClarification)return ['Unexpected clarification for this specified diagnostic case.'];
  const value=result?.answer?.value;
  if(c.expect.kind==='number' && value!==c.expect.value)issues.push('Wrong numeric answer or nonnumeric final output.');
  if(c.expect.kind==='truth' && (value?.kind!=='truthResult'||value.state!==c.expect.state))issues.push('Wrong structured truth status.');
  if(c.expect.kind==='names'){
    const names=value?.kind==='queryResult'?[...new Set(value.rows.flatMap(r=>Object.values(r.bindings).map(id=>store.get(id)?.name ?? id)))].sort():[];
    if(JSON.stringify(names)!==JSON.stringify([...c.expect.names].sort()))issues.push('Wrong structured query answers.');
  }
  const facts=store.list('assertion');
  for(const [relation,a,b,polarity,context] of c.facts ?? []) if(!facts.some(f=>store.get(f.relation)?.name===relation&&store.get(f.args[0])?.name===a&&store.get(f.args[1])?.name===b&&f.polarity===polarity&&f.context===context))issues.push(`Missing explicit claim ${relation}(${a},${b})/${polarity}/${context}.`);
  for(const relation of c.forbidRelations ?? []) if(facts.some(f=>store.get(f.relation)?.name===relation))issues.push(`Invented ${relation} assertion.`);
  for(const relation of c.forbidActual ?? []) if(facts.some(f=>store.get(f.relation)?.name===relation&&f.context==='actual'))issues.push(`Hypothesis leaked into actual ${relation}.`);
  if(c.interval && !facts.some(f=>store.get(f.relation)?.name===c.interval.relation&&f.validFrom?.startsWith(c.interval.from)&&f.validTo?.startsWith(c.interval.to)))issues.push('Incorrect source interval.');
  for(const name of c.requiredCalls ?? []) if(!result.trace?.some(t=>t.operation==='call'&&t.args?.[0]===name))issues.push(`Missing requested tool ${name}.`);
  return issues;
}
if(!health.ok){save();console.error(`No model evaluation performed. Local endpoint unavailable. Status saved to ${path}. Start the model, then rerun npm run eval:llm.`);process.exitCode=2;}
else{
  const dir=mkdtempSync(join(tmpdir(),'basekb-llm-eval-'));const base=join(dir,'base.sqlite');createBase(base);
  try{for(let repeat=0;repeat<repeats;repeat++)for(const c of cases){
    const store=new Store({basePath:base,sessionPath:join(dir,`${c.id}-${repeat}.sqlite`)});const engine=new Engine(store),agent=new ChatAgent(engine,{llm,demo:false});
    const started=performance.now(),turns=[];let result,error;
    try{for(const prompt of c.prompts ?? [c.prompt]){result=await agent.run(prompt);turns.push(result);if(result.needsClarification)break;}}
    catch(e){error=errorJSON(e);}
    const issues=error?[`${error.code}: ${error.message}`]:evaluate(c,result,store);
    const row={id:c.id,repeat,passed:!issues.length,issues,error:error ?? null,elapsedMs:Math.round(performance.now()-started),turns};
    report.results.push(row);store.close();save();console.log(`${row.passed?'PASS':'FAIL'} ${c.id} repeat=${repeat} ${issues.join('; ')}`);
  }}finally{rmSync(dir,{recursive:true,force:true});}
  report.status='completed';report.metrics={cases:report.results.length,passed:report.results.filter(r=>r.passed).length,passRate:report.results.filter(r=>r.passed).length/report.results.length,
    modelCalls:report.results.reduce((n,r)=>n+r.turns.reduce((n,t)=>n+(t.attempts?.length ?? 0),0)+(r.error?.details?.attempts?.length ?? 0),0)};save();console.log(JSON.stringify(report.metrics,null,2));
  if(report.metrics.passed<report.metrics.cases)process.exitCode=1;
}
