import { mkdirSync, writeFileSync, readFileSync, readdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';
import { VERSION_SET } from '../src/versions.mjs';

mkdirSync('reports',{recursive:true});
const run=(name,args,{allowStatus=[]}={})=>{
  const r=spawnSync(process.execPath,args,{encoding:'utf8',env:process.env,maxBuffer:32*1024*1024});
  const status=r.status ?? 1;
  if(status!==0 && !allowStatus.includes(status)){
    const e=new Error(`${name} failed with status ${status}`);e.result=r;throw e;
  }
  return {status,stdout:r.stdout??'',stderr:r.stderr??''};
};
const write=(path,text)=>writeFileSync(path,text.endsWith('\n')?text:text+'\n');
const timestamp=new Date().toISOString();
let syntax,tests,evaluation,doctor;
try{
  syntax=run('syntax check',['scripts/check.mjs']);
  write('reports/syntax-check.txt',syntax.stdout+syntax.stderr);

  const testFiles=readdirSync('tests').filter(n=>n.endsWith('.test.mjs')).sort().map(n=>join('tests',n));
  tests=run('deterministic tests',['--test',...testFiles]);
  write('reports/tests.tap',tests.stdout+tests.stderr);

  evaluation=run('deterministic identity evaluation',['scripts/eval.mjs']);
  write('reports/identity-eval-console.txt',evaluation.stdout+evaluation.stderr);

  doctor=run('environment diagnostic',['scripts/doctor.mjs']);
  write('reports/environment.json',doctor.stdout);
}catch(e){
  if(e.result) process.stderr.write((e.result.stdout??'')+(e.result.stderr??''));
  throw e;
}

const tap=tests.stdout;
const number=(label)=>Number(tap.match(new RegExp(`^# ${label} (\\d+)$`,'m'))?.[1]??NaN);
const testSummary={createdAt:timestamp,release:'BaseKB Lab 0.3.0',versions:VERSION_SET,tests:number('tests'),pass:number('pass'),fail:number('fail'),cancelled:number('cancelled'),skipped:number('skipped'),todo:number('todo')};
writeFileSync('reports/test-results.json',JSON.stringify(testSummary,null,2));

const identity=JSON.parse(readFileSync('reports/identity-eval.json','utf8'));
const full=identity.results.find(r=>r.variant==='full');
let environment={};try{environment=JSON.parse(doctor.stdout);}catch{environment={parseError:true,raw:doctor.stdout};}
const llmStatus={createdAt:timestamp,status:'not_run',reason:environment.llm?.ok?'A local endpoint is available, but release verification deliberately does not run generative evaluation automatically. Run npm run eval:llm explicitly.':'Local model endpoint was not available during release verification.',health:environment.llm??null};
writeFileSync('reports/llm-eval.json',JSON.stringify(llmStatus,null,2));
write('reports/llm-eval-console.txt',`Release verification did not run generative-model evaluation. ${llmStatus.reason}\n`);
writeFileSync('reports/smoke-local.json',JSON.stringify({createdAt:timestamp,status:'not_run',reason:llmStatus.reason,health:llmStatus.health},null,2));
write('reports/LOCAL_MODEL_STATUS.md',`# Local Model Status\n\nRelease verification: **${llmStatus.status}**. ${llmStatus.reason}\n\nConfigured model: \`${environment.llm?.model??'unknown'}\`  \nEndpoint: \`${environment.llm?.baseURL??'unknown'}\`\n\nNo mocked or estimated generative-model score is substituted. Start the intended local model and run \`npm run smoke:local\` followed by \`npm run eval:llm\`.\n`);

write('reports/TEST_RESULTS.md',`# Test Results — BaseKB Lab 0.3.0\n\nGenerated: ${timestamp}\n\n- deterministic tests: **${testSummary.pass}/${testSummary.tests} passed**\n- failures: **${testSummary.fail}**\n- syntax check: **passed**\n- deterministic identity fixture: **${full.cases.filter(c=>c.correct).length}/${full.metrics.count} correct decisions**\n- false auto-links on authored identity fixture: **${full.metrics.falseAutoLinks}**\n- local generative-model evaluation: **not run by release verification**\n\nThe deterministic identity fixture is an authored regression suite, not an independent benchmark. See \`IDENTITY_EVAL.md\` and \`identity-eval.json\`.\n`);

write('reports/RELEASE_STATUS.md',`# Release Status — BaseKB Lab 0.3.0\n\nGenerated: ${timestamp}\n\n**Deterministic release gate: PASS**\n\nThe syntax check, ${testSummary.tests} deterministic tests, and deterministic identity regression/ablation completed successfully. The release keeps model evaluation separate: \`npm run verify\` never fabricates or silently substitutes LLM results.\n\nRuntime semantic versions used by this build:\n\n\`\`\`json\n${JSON.stringify(VERSION_SET,null,2)}\n\`\`\`\n\nLocal-model status: ${llmStatus.reason}\n`);

console.log(`Release verification passed: ${testSummary.pass}/${testSummary.tests} deterministic tests; identity ${full.cases.filter(c=>c.correct).length}/${full.metrics.count}.`);
