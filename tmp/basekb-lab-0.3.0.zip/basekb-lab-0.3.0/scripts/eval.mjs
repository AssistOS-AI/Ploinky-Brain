import { mkdirSync, writeFileSync } from 'node:fs';
import { Resolver } from '../src/resolver.mjs';
import { IDENTITY_CASES, identityFixture } from '../eval/identity-fixture.mjs';
import { hash } from '../src/util.mjs';

const variants=[['full',{}],['without_aliases',{aliases:false}],['without_context',{context:false}],['without_properties',{properties:false}],['without_fuzzy',{fuzzy:false}]];
const results=[];
for(const [variant,heuristics] of variants){
  const {store}=identityFixture(),resolver=new Resolver(store,{heuristics});const start=performance.now();
  const cases=IDENTITY_CASES.map(c=>{
    let output;
    try{output=resolver.resolveEntity(c.mention,{turn:c.turn ?? 10});}
    catch(e){if(e.code!=='AMBIGUOUS')throw e;output={decision:'uncertain',reason:e.message,candidates:e.details.candidates};}
    return {id:c.id,gold:c.expect,goldTarget:c.target ?? null,predicted:output.decision,target:output.target ?? null,
      correct:output.decision===c.expect && (c.expect!=='same' || output.target===c.target),reason:output.reason,candidates:output.candidates};
  });
  const linked=cases.filter(c=>c.predicted==='same'),correctLinks=linked.filter(c=>c.gold==='same' && c.target===c.goldTarget).length;
  const abstentions=cases.filter(c=>c.predicted==='uncertain').length;
  results.push({variant,cases,metrics:{count:cases.length,decisionAccuracy:cases.filter(c=>c.correct).length/cases.length,
    autoLinks:linked.length,correctAutoLinks:correctLinks,falseAutoLinks:linked.length-correctLinks,autoLinkPrecision:linked.length?correctLinks/linked.length:null,
    abstentions,abstentionRate:abstentions/cases.length,decisionCoverage:(cases.length-abstentions)/cases.length,elapsedMs:Number((performance.now()-start).toFixed(3))}});
}
const report={createdAt:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,
  evaluation:'synthetic regression and ablation, authored alongside this implementation',datasetHash:hash(IDENTITY_CASES),llmCalls:0,
  caveats:['Not an independent held-out benchmark.','Scores are not probabilities; synthetic auto-link precision is not a real-world guarantee.',
    'Ablations measure this policy fixture, not general language understanding.','Latency is a small in-memory fixture measurement, not DGX/model or large-SQLite performance.'],results};
mkdirSync('reports',{recursive:true});writeFileSync('reports/identity-eval.json',JSON.stringify(report,null,2));
let md=`# Deterministic Identity Evaluation\n\nRun: ${report.createdAt}; Node ${report.node}, ${report.platform}/${report.arch}.\n\n**Synthetic regression set authored alongside the implementation, not an independent benchmark.** No LLM calls.\n\n| Variant | Correct | Auto-links | False auto-links | Abstentions |\n|---|---:|---:|---:|---:|\n`;
for(const r of results){const m=r.metrics;md+=`| ${r.variant} | ${r.cases.filter(c=>c.correct).length}/${m.count} | ${m.autoLinks} | ${m.falseAutoLinks} | ${m.abstentions} |\n`;}
md+='\n`decisionCoverage` includes both links and decisions to create a new referent. Link precision is computed only for `same` predictions. Abstentions are deliberate and are not replaced with guesses. The gold set includes cases that must remain ambiguous.\n\nComplete results and decision reasons are in `identity-eval.json`. These results do not validate natural-language formalization, a real model inference, or safety on an unknown distribution.\n';
writeFileSync('reports/IDENTITY_EVAL.md',md);
console.table(results.map(r=>({variant:r.variant,...r.metrics})));console.log('Wrote reports/identity-eval.json and reports/IDENTITY_EVAL.md');
if(results[0].cases.some(c=>!c.correct))process.exitCode=1;
