import { DatabaseSync } from 'node:sqlite';
import { spawnSync } from 'node:child_process';
import { statfsSync } from 'node:fs';
import { LocalLLM } from '../src/llm.mjs';
const db=new DatabaseSync(':memory:');
const sqlite=db.prepare('select sqlite_version() version').get().version;db.close();
const gpu=spawnSync('nvidia-smi',['--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],{encoding:'utf8',timeout:5000});
const disk=statfsSync('.');
console.log(JSON.stringify({node:process.version,platform:process.platform,arch:process.arch,sqlite,
  diskAvailableGB:Math.round(disk.bavail*disk.bsize/1e9),gpu:gpu.error?'nvidia-smi unavailable':(gpu.stdout || gpu.stderr).trim(),
  llm:await new LocalLLM().health(),notes:['GB10 unified memory reporting can differ from discrete GPU memory reporting.','No model weights are bundled.','No Node packages need to be installed.']},null,2));
