#!/usr/bin/env node
import { DatabaseSync } from 'node:sqlite';
import { copyFileSync, existsSync, unlinkSync } from 'node:fs';
import { resolve } from 'node:path';
import { VERSION_SET } from '../src/versions.mjs';
import { migrateV1ToV2 } from '../migrations/001-v1-to-v2.mjs';
import { assert, parseArgs, errorJSON } from '../src/util.mjs';

const args=parseArgs(process.argv.slice(2));
const input=resolve(args._[0] ?? '');
const output=resolve(args.output ?? '');
assert(input && output && existsSync(input) && input!==output,'MIGRATE','Usage: node scripts/migrate.mjs OLD.sqlite --output NEW.sqlite --assume-english [--cleanup-legacy-bootstrap]');
assert(!existsSync(output),'MIGRATE','Output already exists. Migrations never overwrite knowledge stores.');
copyFileSync(input,output);
const db=new DatabaseSync(output,{timeout:3000,allowExtension:false});
try {
  db.exec('BEGIN IMMEDIATE');
  const before=db.prepare('SELECT value FROM meta WHERE key=?').get('schemaVersion')?.value;
  if(before==='1') migrateV1ToV2(db,VERSION_SET,{assumeEnglish:!!args['assume-english'],cleanupLegacyBootstrap:!!args['cleanup-legacy-bootstrap']});
  else assert(before===VERSION_SET.schemaVersion,'MIGRATE',`Unsupported source schema ${before}.`);
  db.exec('COMMIT');
  console.log(JSON.stringify({input,output,before,after:VERSION_SET.schemaVersion,versions:VERSION_SET},null,2));
} catch(e) {
  try{db.exec('ROLLBACK');}catch{}
  try{db.close();}catch{}
  try{unlinkSync(output);}catch{}
  console.error(JSON.stringify(errorJSON(e),null,2));process.exitCode=1;
  process.exit();
} finally { try{db.close();}catch{} }
