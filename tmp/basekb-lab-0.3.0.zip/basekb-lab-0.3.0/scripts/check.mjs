import { readdirSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
let count=0,failures=0;
function walk(dir){for(const e of readdirSync(dir,{withFileTypes:true})){if(['vendor','node_modules','data'].includes(e.name))continue;const p=join(dir,e.name);if(e.isDirectory())walk(p);else if(p.endsWith('.mjs') && !p.startsWith('examples')){count++;const r=spawnSync(process.execPath,['--check',p],{encoding:'utf8'});if(r.status){console.error(r.stderr);failures++;}}}}
walk('.');console.log(`${count} modules checked; ${failures} syntax failures.`);process.exitCode=failures?1:0;
