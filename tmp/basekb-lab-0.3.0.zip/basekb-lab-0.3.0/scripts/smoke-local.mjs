#!/usr/bin/env node
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createBase } from '../src/seed.mjs';
import { Store } from '../src/storage.mjs';
import { Engine } from '../src/engine.mjs';
import { ChatAgent, LocalLLM } from '../src/llm.mjs';
import { errorJSON } from '../src/util.mjs';

const dir=mkdtempSync(join(tmpdir(),'basekb-local-smoke-'));
try {
  const base=join(dir,'base.sqlite');createBase(base);
  const store=new Store({basePath:base,sessionPath:join(dir,'session.sqlite')});
  try {
    const llm=new LocalLLM(),health=await llm.health();
    if(!health.ok){console.error(JSON.stringify({status:'not_run',reason:'Local model endpoint is not available.',health},null,2));process.exitCode=2;}
    else {
      const agent=new ChatAgent(new Engine(store),{llm});
      const source='Ion este părintele Mariei. Maria este părintele Anei. Cine este bunicul Anei?';
      const r=await agent.run(source);
      const checks={
        sourceLanguage:r.inputNormalization?.sourceLanguage==='ro',
        internalEnglish:r.answer?.internalLanguage==='en',
        normalizedEnglish:/parent|grandparent/i.test(r.inputNormalization?.englishText??''),
        hasAnswer:!!r.answer?.text,
        provenance:store.list('source').some(s=>s.text===source&&s.sourceLanguage==='ro'&&s.normalizedText),
        canonicalRecords:store.list().filter(x=>x.kind!=='source').every(x=>x.internalLanguage==='en')
      };
      const ok=Object.values(checks).every(Boolean);
      console.log(JSON.stringify({status:ok?'pass':'fail',model:health.model,endpoint:health.baseURL,checks,answer:r.answer},null,2));
      if(!ok)process.exitCode=1;
    }
  } finally {store.close();}
} catch(e){console.error(JSON.stringify({status:'fail',error:errorJSON(e)},null,2));process.exitCode=1;}
finally {rmSync(dir,{recursive:true,force:true});}
