import { existsSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { createBase } from '../src/seed.mjs';
const path = resolve(process.argv[2] ?? 'data/base.sqlite');
if(existsSync(path)) console.log(`BaseKB already exists: ${path}; left unchanged.`);
else {createBase(path); console.log(`Created: ${path}`);}
