#!/usr/bin/env node
import { spawn, spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { parseArgs, assert, errorJSON } from '../src/util.mjs';

const args=parseArgs(process.argv.slice(2)),provider=args.provider ?? 'ollama';
let child=null;
function run(executable,argv,options={}){
  return new Promise((yes,no)=>{const p=spawn(executable,argv,{stdio:'inherit',shell:false,...options});p.once('error',no);p.once('exit',code=>code===0?yes():no(new Error(`${executable} exited ${code}`)));});
}
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function healthy(url){try{const r=await fetch(url,{signal:AbortSignal.timeout(1500),redirect:'error'});return r.ok;}catch{return false;}}
async function waitFor(url,attempts=120){for(let i=0;i<attempts;i++){if(await healthy(url))return;if(child && child.exitCode!==null)throw new Error('Model server exited before becoming ready.');await sleep(1000);}throw new Error('Model server did not become ready. Inspect its logs; increase available memory or reduce context.');}
const stop=()=>{if(child && child.exitCode===null)child.kill('SIGTERM');};
process.once('SIGINT',()=>{stop();process.exit(130);});process.once('SIGTERM',()=>{stop();process.exit(143);});
try{
  const manifest={provider,startedAt:new Date().toISOString(),node:process.version,arch:process.arch,ownedServer:false};
  if(provider==='ollama'){
    const bin=args.bin ?? 'ollama',model=args.model ?? 'qwen3-coder:30b';
    assert(!/cloud/i.test(model),'LOCAL_ONLY','Use a locally installed model, not a cloud-routed model.');
    const version=spawnSync(bin,['--version'],{encoding:'utf8',timeout:5000});
    assert(!version.error,'OLLAMA_MISSING','Ollama is not installed. See docs/guides/DGX_SPARK.md; installation is an explicit operator action.');
    manifest.version=(version.stdout || version.stderr).trim();manifest.model=model;
    const host='127.0.0.1:11434',url=`http://${host}`;
    if(!await healthy(`${url}/api/tags`)){
      child=spawn(bin,['serve'],{stdio:'inherit',shell:false,env:{...process.env,OLLAMA_HOST:host,OLLAMA_CONTEXT_LENGTH:String(args.context ?? 8192),OLLAMA_NUM_PARALLEL:'1',OLLAMA_MAX_LOADED_MODELS:'1'}});
      child.once('error',e=>{console.error(e.message);process.exitCode=1;});manifest.ownedServer=true;await waitFor(`${url}/api/tags`,30);
    }
    if(args.pull)await run(bin,['pull',model],{env:{...process.env,OLLAMA_HOST:host}});
    const tags=await (await fetch(`${url}/api/tags`)).json();manifest.installedModel=tags.models?.find(m=>m.name===model) ?? null;
    assert(manifest.installedModel,'MODEL_MISSING',`Model ${model} is not installed. Re-run with --pull to authorize its download.`);
    const load=await fetch(`${url}/api/generate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,prompt:'',stream:false,keep_alive:'30m',options:{num_ctx:Number(args.context ?? 8192)}}),signal:AbortSignal.timeout(300000),redirect:'error'});
    assert(load.ok,'MODEL_LOAD',`Model load failed: ${load.status} ${await load.text()}`);
    console.log(`\nLocal model ready. In another terminal:\nLLM_BASE_URL=${url}/v1 LLM_MODEL=${model} npm start\n`);
  }else if(provider==='llama'){
    const bin=resolve(args.bin ?? 'vendor/llama.cpp/build/bin/llama-server'),model=resolve(args.model ?? '');
    assert(args.model && existsSync(bin) && existsSync(model),'MODEL_MISSING','Provide --bin /path/llama-server --model /path/model.gguf.');
    const port=Number(args.port ?? 8080),context=Number(args.context ?? 8192);
    assert(Number.isSafeInteger(port) && port>1024 && port<65536 && Number.isSafeInteger(context) && context>=1024,'CONFIG','Invalid port or context.');
    const argv=['--model',model,'--host','127.0.0.1','--port',String(port),'--ctx-size',String(context),'--parallel','1','--n-gpu-layers',String(args['gpu-layers'] ?? 999),'--alias','basekb-local'];
    manifest.argv=argv;manifest.ownedServer=true;child=spawn(bin,argv,{stdio:'inherit',shell:false});
    child.once('error',e=>{console.error(e.message);process.exitCode=1;});await waitFor(`http://127.0.0.1:${port}/health`,300);
    console.log(`\nLocal model ready. In another terminal:\nLLM_BASE_URL=http://127.0.0.1:${port}/v1 LLM_MODEL=basekb-local npm start\n`);
  }else throw new Error('Supported providers: ollama, llama.');
  mkdirSync('reports',{recursive:true});writeFileSync('reports/local-model-manifest.json',JSON.stringify(manifest,null,2));
  if(child)await new Promise(resolve=>child.once('exit',resolve));
}catch(e){stop();console.error(JSON.stringify(errorJSON(e),null,2));process.exitCode=1;}
