# Operations Guide

## Initialize a clean BaseKB

```bash
rm -f data/base.sqlite
npm run init
```

Do not remove a meaningful BaseKB merely to change schema; use `npm run migrate -- ...` and preserve the original.

## Chat

```bash
npm run chat -- --demo
npm run chat
```

The CLI prints `displayText` when output localization is available while retaining English `answer.text` internally.

## Inspect

```bash
node src/cli.mjs inspect
```

Inspection includes the version set and `internalLanguage`.

## Import into a staging fork

```bash
node src/cli.mjs ingest examples/import.json --output data/import-stage.sqlite
node src/cli.mjs ingest examples/import.nt --output data/rdf-stage.sqlite
```

The original session is unchanged. Review staged records before promotion.

## Approve a candidate definition

```bash
node src/cli.mjs approve RECORD_ID --reason "Reviewed semantics and implementation"
```

## Promote selected knowledge into a new BaseKB

```bash
node src/cli.mjs promote data/base-reviewed.sqlite \
  --ids assertion:... \
  --reason "Reviewed source and semantics" \
  --include-private
```

The existing BaseKB remains unchanged.

## Migrate schema v1 -> v2

```bash
node scripts/migrate.mjs old-base.sqlite --output new-base-v2.sqlite --assume-english
# for the known 0.1 bootstrap aliases, optionally add: --cleanup-legacy-bootstrap
```

`--assume-english` is deliberately required because a deterministic migration cannot prove that arbitrary v1 semantic text is English. Normalize/review legacy semantic records first. `--cleanup-legacy-bootstrap` removes the known non-English bootstrap aliases from the 0.1 prototype. Never overwrite the source database in place.

## Identity inspection, correction and audit

Identity evidence is accumulated non-destructively. Inspect the active derived profile before correcting a prior resolution:

```bash
node src/cli.mjs identity-profile ENTITY_ID --session data/sessions/SESSION.sqlite
```

A reviewed operator correction supersedes one resolution and replays only assertions that explicitly record their dependency on that decision:

```bash
node src/cli.mjs rebind-resolution RESOLUTION_ID TARGET_ENTITY_ID \
  --reason "Reviewed evidence shows the mention refers to the target" \
  --session data/sessions/SESSION.sqlite
```

Legacy assertions without dependency metadata fail closed with `REPLAY_UNTRACKED`; do not work around that by graph-wide replacement. Verify the local event hash chain with:

```bash
node src/cli.mjs audit --session data/sessions/SESSION.sqlite
```

The hash chain detects accidental/post-hoc modification inside the database; it is not a digital signature against a fully privileged host.

## Reproducibility

For a release/handoff run:

```bash
npm run verify
```

This command regenerates syntax, deterministic test, identity-evaluation and environment reports under `reports/`. It deliberately does **not** run a generative-model benchmark automatically. When the intended local endpoint is active, run separately:

```bash
npm run smoke:local
npm run eval:llm
```

A missing local endpoint is therefore reported as `not_run`, never replaced by a mock score. Preserve the generated reports with the release.
