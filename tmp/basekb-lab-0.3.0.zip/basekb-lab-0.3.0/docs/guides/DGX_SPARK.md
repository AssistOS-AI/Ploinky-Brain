# DGX Spark Local Setup

This project is intentionally friendly to a DGX Spark running Ubuntu/aarch64: Node has zero package dependencies and all inference is accessed through a local HTTP endpoint.

## 1. Verify environment

```bash
node --version        # require >= 22.16
nvidia-smi
npm run doctor
```

Node's built-in `node:sqlite` currently emits an ExperimentalWarning on some Node releases; the deterministic tests account for the API used by this project.

## 2. Deterministic verification before downloading a model

```bash
npm run verify
npm run demo
```

This proves the parser/runtime/storage/test stack independently of model quality.

## 3. Ollama route

The default `qwen3-coder:30b` is a coding-oriented MoE (30.5B total / 3.3B activated in the Qwen model card; current Ollama package about 19 GB). Install Ollama using the vendor instructions for your platform, then:

```bash
node scripts/start-model.mjs \
  --provider ollama \
  --model qwen3-coder:30b \
  --context 8192 \
  --pull
```

The launcher keeps the server on loopback and prevents cloud-tag use. In a second terminal:

```bash
LLM_BASE_URL=http://127.0.0.1:11434/v1 \
LLM_MODEL=qwen3-coder:30b \
npm start
```

Then run:

```bash
npm run smoke:local
npm run eval:llm
```

## 4. llama.cpp route

`build-llama.sh` is provided as a convenience script, but cloning/building third-party code and downloading weights are explicit operator actions. Once `llama-server` and a compatible GGUF exist:

```bash
node scripts/start-model.mjs \
 --provider llama \
 --bin /path/to/llama-server \
 --model /path/to/qwen-coder.gguf \
 --context 8192
```

## 5. Memory tuning

Begin with one loaded model, one parallel request, and an 8k context. Increase context only after measuring. Long context increases KV-cache memory and is unnecessary for the intended retrieval/chunking architecture.

## 6. No hidden download

BaseKB Lab never downloads model weights from application code. `--pull` is the explicit opt-in path for Ollama. This keeps experiments reproducible and prevents unexpected network/storage side effects.
