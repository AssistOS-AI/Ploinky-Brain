# 09 — Implementation Status and Roadmap

## Implemented in 0.3.0

- BaseKB SQLite + SessionKB overlay/fork and immutable base behavior during chat;
- multilingual input normalization to an English semantic core;
- restricted JS-like Knowledge Program + custom parser + canonical versioned Knowledge IR;
- n-ary assertions, polarity, contexts, temporal intervals and exact-source provenance;
- finite rule inference and constraints with budgets;
- conservative entity resolver with candidate heuristics, anchors and blockers;
- field-level evidence-bearing identity values;
- first-class `Mention -> ResolutionDecision -> Entity` records;
- non-destructive derived `IdentityProfile` with accumulated active trusted evidence and conflict detection;
- resolution supersession and dependency-directed operator rebinding of directly asserted facts;
- fail-closed correction for legacy/untracked identity dependencies;
- first-class execution records with runtime versions/hashes;
- hash-linked session audit events and verifier;
- relation signature protection and semantic-comparison scaffolding;
- reviewed function/rule/schema activation model;
- AutoFormaliser adapters for BaseKB, exchange JSON, strict N-Triples and text;
- local OpenAI-compatible LLM adapter, repair loop and localized presentation;
- local chat web UI and CLI;
- explicit schema/IR/API/policy/profile/audit/prompt versions and migration skeleton;
- deterministic tests and identity eval.

## Deliberately incomplete

- no universal natural-language formalization guarantee;
- no full OWL/RDFS/Turtle/JSON-LD implementation;
- no PDF/DOCX parser in the dependency-minimal core;
- no production-scale query planner/index layout;
- no semi-naive incremental Datalog engine;
- no full historical snapshot/checkpoint replay of arbitrary past runtime states;
- no calibrated confidence probabilities;
- no independent external identity/formalization benchmark;
- no signed reviewer identity or external audit notarization;
- no audited OS-level sandbox for host extensions.

## Recommended sequence for a coding agent

### P0 — semantic correctness

1. Add a first-class `CandidateClaim` staging representation so long-document extraction is separated from entity/schema resolution and commit.
2. Extract identity signals into modular type-specific policies (`Person`, `Organization`, `Place`, `Concept`, `Artifact`) with explicit temporal semantics for changeable fields.
3. Expand relation semantic resolution into `SAME / INVERSE / BROADER / NARROWER / ARGUMENT_PERMUTATION / RELATED / DIFFERENT / UNCERTAIN` without auto-activating unreviewed mappings.
4. Add property/fuzz tests for parser, provenance spans, Unicode/confusables, transaction rollback, resolution chains and rebinding.
5. Add operator inspection/approval UX for identity profiles and proposed corrections.

### P1 — evaluation

6. Add independent multilingual formalization and identity datasets, including correction/rebinding cases.
7. Run several local models and quantify normalization fidelity, formalization fidelity, abstention and repair-loop behavior.
8. Add replayable golden traces and regression corpora separated from implementation-designed fixtures.

### P2 — scale and replay

9. Benchmark 100k–1M entities / 1–10M assertions, then introduce persistent label/alias/identifier/argument/temporal indexes.
10. Add semi-naive inference and dependency-directed recomputation indexes.
11. Add explicit checkpoints/snapshots so a historical execution can be replayed against its original effective session state.
12. Add planner/cost accounting for function calls and query joins.

### P3 — trust and ecosystem

13. More deterministic ontology/import adapters.
14. Signed reviewer/approval records, capability packages and namespace governance.
15. Optional external transparency/notarization for audit heads.
16. SOP Lang / other compiler front ends targeting the same Knowledge IR.
