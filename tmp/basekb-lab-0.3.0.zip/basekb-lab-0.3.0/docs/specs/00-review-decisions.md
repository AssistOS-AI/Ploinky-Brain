# 00 — Reviewed Architecture and Decisions

This document records the decisions made before handing the repository to a coding agent.

## Goal

BaseKB Lab combines symbolic knowledge and executable capabilities. The LLM is primarily a semantic compiler/planner, not the authoritative store or the sole reasoning engine. The trusted runtime decides what objects exist, what follows from accepted rules, whether constraints hold, and what is committed.

## Decisions

**D01 — BaseKB + SessionKB overlay.** BaseKB is opened read-only. A SessionKB is a separate SQLite delta and is the working world for a conversation. Forking copies the session delta, not the whole base. Durable promotion creates a new reviewed BaseKB.

**D02 — English internal semantics.** Regardless of user language, canonical semantic representation is English. Proper names/identifiers are preserved. The exact original source is retained separately for provenance. Internal answers are English; presentation translation happens only after symbolic execution.

**D03 — JS-like syntax, not JavaScript execution.** A tiny familiar surface grammar is parsed by a custom parser and converted to versioned Knowledge IR. The IR is executed by KB-VM. Arbitrary Node/V8 evaluation is forbidden.

**D04 — LLM proposes; runtime validates and commits.** The model may propose entities, relation types, facts, constraints, rules, functions and a query plan. Identity resolution, type checking, rule safety, provenance checking, budgets, constraints and transaction commit are runtime responsibilities.

**D05 — Descriptions are mandatory semantic context, not proof.** Contextual descriptions aid candidate retrieval and explanation. Textual similarity alone cannot prove identity.

**D06 — Mention, resolution and entity are distinct.** A mention becomes a first-class `resolution` decision that points to a target entity. This creates an audit path and makes later rebinding/replay possible without destructive union.

**D07 — Conservative identity.** Exact label, normalized label, transliteration, initials, nickname, acronym and fuzzy similarity are primarily candidate generators. Trusted identifiers, evidence-bearing hard discriminators, reviewed strong aliases, and scoped session context can serve as anchors. Hard conflicts are blockers.

**D08 — Identity evidence is field-specific.** LLM-extracted discriminator properties must use `claim(value, sourceSpan(...))` to become trusted identity evidence. A property may be stored without that wrapper but will not automatically merge entities. Unique identifiers also require field-level evidence from `claim(...)`; merely occurring somewhere in the source is not sufficient.

**D09 — Relation identity preserves ordered semantics.** Same text does not imply same relation. Inverse, broader, narrower, argument-permuted and merely related meanings must not be collapsed as synonyms. The current implementation supports exact/approved relation identity and scaffolding for richer comparison.

**D10 — Claims preserve provenance and contradiction.** Facts retain source evidence, polarity, context and temporal validity. Explicit contradictions can coexist. Missing evidence is `unknown`, not negative evidence.

**D11 — Rules/functions/schema extensions are quarantined.** Model-generated executable or semantic definitions are candidates until separately approved. Declarative rules are preferred over imperative hooks.

**D12 — Transactional execution.** Parsing/validation occurs before execution; the normal LLM flow performs a dry-run before the real commit. Failed execution and clarification leave no semantic partial writes.

**D13 — Versioned contracts.** SQLite schema, Knowledge IR, Program API, resolver policy, inference semantics and LLM prompt all have explicit versions. DB changes require migrations.

**D14 — AutoFormaliser is an adapter pipeline.** Already formal sources should use deterministic adapters where possible. Natural language uses the local model, but output still passes the same trusted KB-VM. A future two-stage `CandidateClaim -> resolved assertion` representation is recommended for large documents.

**D15 — Formal validity is not semantic-equivalence proof.** Exact evidence can prove where a string came from, not that the LLM interpreted the string correctly. Translation and NL-to-symbolic fidelity require separate evaluation.


**D16 — Identity enrichment is a derived view.** Newly trusted identity fields from later mentions accumulate in a non-destructive `IdentityProfile`; they do not overwrite the canonical entity record. Superseded resolutions are excluded and conflicting trusted claims remain visible.

**D17 — Identity correction is dependency-directed.** A resolution can be superseded by an operator decision. Only directly asserted facts that recorded the old resolution as an identity dependency are rewritten; derived facts are recomputed. Legacy untracked dependencies fail closed instead of guessing.

**D18 — Runtime history and store history are distinct.** Opening a store with a newer compatible runtime does not relabel the store's historical version metadata. Each first-class execution records the runtime version set actually used.

**D19 — Session audit events are hash-linked.** The chain is useful for detecting accidental or post-hoc mutation of audited rows, but is not presented as a signature or protection from a fully privileged host.
