# 12 — Local Model Runtime

The core has no dependency on a specific inference server. `LocalLLM` speaks an OpenAI-compatible `/v1/chat/completions` interface and defaults to loopback.

## Default baseline

The release configuration uses:

```text
model: qwen3-coder:30b
endpoint: http://127.0.0.1:11434/v1
```

This is a pragmatic coding-oriented MoE baseline for producing constrained programs on a DGX Spark-class machine. The official Qwen model card describes 30.5B total parameters with 3.3B activated; the current Ollama library lists `qwen3-coder:30b` at about 19 GB and a 256K context window. BaseKB intentionally starts at 8K context to control memory and latency. This is configuration, not an assertion that this model is optimal. Compare smaller/larger candidates empirically using `eval:llm`.

## Ollama

```bash
node scripts/start-model.mjs \
  --provider ollama \
  --model qwen3-coder:30b \
  --context 8192 \
  --pull
```

`--pull` is intentionally explicit because model downloads are large operator-controlled side effects.

## llama.cpp

Build/install a compatible `llama-server`, obtain a GGUF separately, then:

```bash
node scripts/start-model.mjs \
  --provider llama \
  --bin /path/to/llama-server \
  --model /path/to/model.gguf \
  --context 8192
```

The launcher binds to `127.0.0.1` by default.

## Generic endpoint

```bash
export LLM_BASE_URL=http://127.0.0.1:8000/v1
export LLM_MODEL=my-local-model
npm start
```

Optional variables include `LLM_TIMEOUT_MS`, `LLM_MAX_TOKENS`, `LLM_TEMPERATURE`, and `LLM_API_KEY`. Remote endpoints are rejected unless the operator explicitly sets `ALLOW_REMOTE_LLM=1`.

## Context strategy

Do not solve long-document ingestion by indiscriminately increasing model context. The intended architecture retrieves only relevant KB context and chunks source ingestion. For books, add a document-level CandidateClaim/coreference stage rather than forcing the full book into every prompt.
