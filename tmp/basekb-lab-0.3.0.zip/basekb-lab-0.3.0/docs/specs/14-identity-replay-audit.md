# 14 — Identity Profiles, Rebinding, Execution Records and Audit

This specification is normative for release 0.3.

## 1. Active identity is derived, not destructively merged

The durable entity record is the referent container. Identity evidence is a set of claims with provenance, not a single mutable row. `buildIdentityProfile(store, entityId)` derives a current view from the entity's trusted fields plus active resolution mentions.

A profile contains:

```text
entityId
claims.ids / claims.properties       all active trusted claims + origins
resolved.ids / resolved.properties   only fields with one unambiguous canonical value
evidence                             supporting spans/origins
conflicts                            multiple trusted values for the same identity field
activeResolutionIds
ignoredSupersededResolutionIds
```

Hard conflicts are not averaged or resolved by score. They block automatic identity linking.

## 2. Supersession

A correction creates a new `resolution` record:

```text
R2.supersedes = R1.id
R2.target     = corrected entity
R2.reason     = operator_rebind
R2.operatorReason = human review rationale
```

R1 is retained. An already superseded resolution cannot be rebound again; the operator must target the current effective decision. This keeps the history a chain rather than a branching overwrite.

## 3. Assertion identity dependencies

When a Knowledge Program obtains an entity through `createEntity(...)`, KB-VM remembers the resolution that produced the returned entity ID for that execution. A subsequently created assertion records the relevant argument positions:

```json
{
  "identityDependencies": [
    {"resolutionId":"resolution:...", "positions":[0]}
  ]
}
```

This metadata is provenance about interpretation, not part of the asserted world relation. If a program introduces the same target through multiple indistinguishable mentions in one execution, the runtime abstains from assigning a unique dependency rather than pretending it knows which mention supplied a value.

## 4. Rebinding algorithm

`Engine.rebindResolution(oldResolutionId, newEntityId, reason)`:

1. requires an operator call, outside a generated Knowledge Program;
2. rejects a resolution already superseded;
3. rejects a new target with explicit trusted identity blockers;
4. locates the local mention;
5. finds local directly asserted facts with an explicit dependency on the old resolution;
6. fails with `REPLAY_UNTRACKED` if a same-source local fact references the old target but lacks dependency metadata;
7. creates R2 and updates the mention's effective binding/history;
8. rewrites only the recorded dependent argument positions, validating relation domains;
9. masks old facts and stores corrected facts with `reboundFrom` / `reboundByResolution`;
10. recomputes rules and constraints transactionally;
11. optionally marks an entity created solely by R1 as `orphaned` when nothing independently references it;
12. writes an audited `resolution_rebind` event.

Any failure rolls back the entire correction.

## 5. First-class execution records

Each committed Knowledge Program stores an `execution` record containing:

- source ID and turn;
- program hash and Knowledge IR hash;
- runtime version set;
- resolution IDs;
- write count;
- answer hash;
- inference summary.

The store's creation/migration metadata is not silently overwritten when a new runtime opens it. Historical decisions carry their own policy version and each execution records its actual runtime versions.

## 6. Event audit chain

Each new session event stores:

```text
_audit.version
_audit.prevHash
_audit.eventHash
```

The digest commits to sequence number, timestamp, kind, event payload and previous digest. `Store.verifyAuditChain()` verifies all audited rows and reports legacy unsealed rows separately.

Security boundary: this is a tamper-evident local chain, not a signature, TPM attestation, transparency log or external timestamp. A host administrator capable of rewriting all rows and recomputing the chain remains trusted.

## 7. Remaining work

- explicit source-level `CandidateClaim` staging and replay across long-document chunks;
- richer type-specific identity policies and temporal identity fields;
- a UI/operator workflow for inspecting and approving proposed rebinding;
- signed reviewer identities / approval records;
- snapshot/checkpoint infrastructure for deterministic whole-session replay, not only dependency-directed correction;
- independent benchmarks for false merge / false split / correction accuracy.
