# 06 — AutoFormaliser and BaseLLM

## BaseLLM responsibilities

The model is used for four boundary tasks:

1. **normalize** multilingual source meaning into faithful English;
2. **formalize/plan** an English Knowledge Program using the advertised KB API;
3. optionally **advise** on ambiguous identity evidence without authorizing a merge;
4. **verbalize/localize** the final English AnswerObject for the user.

It is not the authoritative rule engine or store.

## Multilingual normalization

Before planning, `normalizeUserInput` requests strict JSON:

```json
{"sourceLanguage":"ro","englishText":"..."}
```

The prompt requires preservation of names, IDs, numbers, units, negation, modality, uncertainty, quantifiers, time, quotations and hypothetical status. The normalizer must not answer the question or infer missing facts.

The original source remains available to `sourceSpan()` so that evidence is quoted exactly even when the program itself is English.

## Repair loop

The LLM output is parsed and dry-run. If the deterministic runtime rejects the program for a repairable reason, the model receives the structured error and may try again. No failed semantic attempt is committed. Ambiguous identity instead returns a clarification path rather than encouraging the model to guess.

## AutoFormaliser adapters

- another BaseKB: trusted operator-selected file, imported with ID namespacing/candidate quarantine;
- `basekb-exchange-v2`: explicit `internalLanguage:"en"`;
- strict N-Triples subset: deterministic parsing; no implicit RDFS/OWL entailment; resource IRIs are admitted as trusted identity fields only with an exact source-line span containing that IRI, so the same IRI can resolve safely across separate imports; blank-node identity stays document-local; explicitly non-English language-tagged semantic literals are rejected and must be normalized first;
- plain text/Markdown: chunked and sent through the local model;
- PDF/DOCX: deliberately not parsed in this minimal dependency-free prototype; convert explicitly to text first.

## Recommended future two-stage ingestion

For books/large corpora, prefer:

```text
raw source
  -> CandidateClaim / CandidateMention extraction
  -> document-level coreference, schema and identity resolution
  -> accepted Knowledge Program / assertions
```

This avoids committing chapter-local guesses before later context disambiguates them and provides clean error metrics for extraction vs resolution vs reasoning.
