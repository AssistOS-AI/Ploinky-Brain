# 05 — Logic, Constraints, Time and Provenance

## Assertions

A fact is an ordered n-ary assertion with explicit metadata. Important dimensions include:

- relation and ordered arguments;
- positive/negative polarity;
- actual vs hypothetical context;
- half-open temporal validity `[validFrom, validTo)`;
- qualifiers;
- source evidence;
- accepted/derived status;
- derivation premises and rule IDs where applicable.

## Open-world epistemic semantics

For a ground claim, the runtime distinguishes:

```text
supported
refuted
both
unknown
```

No fact found is `unknown`, not `refuted`. Positive and explicit negative support can coexist (`both`). The prototype does not use classical explosion.

## Rule engine

The implemented engine uses finite Horn-style rules without function terms or existentially generated entities. Head variables must be bound in the body. Inference is bounded by facts, rounds and comparison budgets. Budget exhaustion is an error/rollback, never a silent claim of completeness.

The implementation currently performs full-round closure with predicate grouping, not a production-grade semi-naive/Datalog planner. Semi-naive evaluation, persistent indexes and dependency-directed recomputation are high-value future work.

## Constraints and hooks

Declarative constraints/rules are preferred because they are inspectable and analyzable. Restricted hooks remain an escape hatch for validation that is awkward declaratively. Candidate metadata never activates itself.

## Provenance

Exact evidence is represented as a validated span of a `source` record. Model-generated assertions cannot cite arbitrary other sources. Trusted deterministic import adapters may attach imported provenance according to their own contract.

A key distinction:

```text
source-span validity != semantic extraction correctness
```

The runtime can prove that a quoted span occurs in the source; it cannot by itself prove that the LLM mapped that sentence to the right relation, polarity, time or entity.

## Identity provenance

Identity-sensitive scalar values may use `claim(value, sourceSpan(...))`. This attaches evidence to the field rather than only to the whole entity mention. This is required for automatic use of hard discriminator properties extracted by the model.


## Identity-resolution provenance

World assertions may depend on a particular interpretation of a source mention. Release 0.3 records this separately from ordinary source evidence using `identityDependencies`. The source span answers "where was the claim stated?"; a resolution dependency answers "which identity decision supplied this entity argument?". Both are required for safe correction.

A superseded resolution does not delete the old assertion. The old directly asserted fact is masked with a correction reason and the corrected fact records `reboundFrom` and `reboundByResolution`. Derived facts are not persisted as authoritative rows; they are recomputed from the effective accepted assertion set.

Committed executions are also first-class records with IR/program/answer hashes and the runtime version set, allowing an audit trail to distinguish changes in source knowledge from changes in resolver/prompt/runtime policy.
