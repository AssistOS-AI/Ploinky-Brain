# 11 — Coding-Agent Handoff Guide

Start with `AGENTS.md`; it is normative.

## First commands

```bash
node --version
npm run check
npm test
npm run eval
npm run doctor
```

Do not make the deterministic suite depend on a model download or network access.

## Architecture discovery order

1. `src/versions.mjs`
2. `src/storage.mjs`
3. `src/language.mjs` and `src/ir.mjs`
4. `src/engine.mjs`
5. `src/identity-profile.mjs`
6. `src/resolver.mjs`
7. `src/rules.mjs`
8. `src/llm.mjs`
9. `src/formaliser.mjs`
10. tests corresponding to each module

Read `docs/specs/14-identity-replay-audit.md` before changing identity or replay semantics.

## Change discipline

For semantic behavior, encode the desired invariant as a test before changing code. For DB/IR/API behavior, bump a version when backward interpretation changes. Never add a raw model capability because it is convenient; expose a bounded typed operation through the registry instead.

Do not rewrite store creation-version metadata merely because the runtime version changed. Historical resolutions/executions already carry their own policy/runtime versions.

## Recommended first issue

Implement first-class `CandidateClaim` staging for natural-language ingestion:

```text
raw source span
   -> CandidateClaim (what the source appears to assert)
   -> entity/relation/schema resolution
   -> accepted/proposed assertion
```

Requirements:

- preserve exact original source spans and the English semantic normalization separately;
- CandidateClaim creation must not mutate the accepted world model;
- represent polarity, modality/hypothesis, temporal scope and unresolved mentions;
- link each resolved assertion back to one or more CandidateClaims;
- allow a later entity-resolution correction to replay the affected claims without re-running unrelated document chunks;
- make extraction error, identity error, schema-mapping error and reasoning error separately measurable;
- keep the representation versioned and dependency-minimal;
- add tests before integrating it into LLM text ingestion.

This is now higher value than broadening tool capabilities because 0.3 already has reversible resolution dependencies at the assertion layer; CandidateClaim staging extends that correctness boundary to long-document extraction.
