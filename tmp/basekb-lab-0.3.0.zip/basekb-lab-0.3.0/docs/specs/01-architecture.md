# 01 — Architecture and Trust Boundaries

```text
USER / DOCUMENT (any language)
        |
        v
Language Boundary: local LLM
  - detect source language
  - faithful semantic normalization -> English
        |
        v
BaseLLM compiler / planner
  - English Knowledge Program
  - exact sourceSpan() quotations still reference original source
        |
        v
Custom parser -> canonical Knowledge IR -> static validation
        |
        v
KB-VM dry-run
  + Entity/Relation Resolver
  + Derived IdentityProfile
  + Rule Engine
  + Constraint Engine
  + Function Registry
  + Provenance Engine
        |
        +------> clarification / repair, zero semantic commit
        |
        v
transactional execution -> SessionKB overlay -> English AnswerObject
        |
        v
Presentation boundary: optional local LLM translation
        |
        v
USER LANGUAGE
```

## Persistent layers

```text
BaseKB (read-only during chat)
  + SessionKB delta
  = Session view
```

Session forks permit alternative worlds and experiments. A durable update never mutates the original BaseKB; `promote` creates a new file after operator review.

## Trusted computing base

Trusted: Node runtime, BaseKB host code, custom parser/interpreter, SQLite library, local model server configuration, and operator review decisions.

Untrusted: raw user text, documents, imported content, LLM outputs, candidate functions/rules, and arbitrary external identifiers until resolved.

## No hidden hosted fallback

`LocalLLM` defaults to loopback and rejects remote endpoints unless explicitly opted in. The repository has no cloud key requirement. The model server itself is external to KB-VM and is never called while a SQLite transaction is open.

## Main modules

- `storage.mjs`: Base/session overlay, transactions, fork, promotion, audit events.
- `engine.mjs`: KB-VM API, provenance, type checking, execution lifecycle.
- `language.mjs`: restricted program parser/evaluator.
- `ir.mjs`: canonical versioned Knowledge IR.
- `resolver.mjs`: entity/relation identity policy.
- `identity-profile.mjs`: non-destructive active identity evidence, supersession views and effective mention targets.
- `rules.mjs`: finite Horn-style closure, constraints and temporal joins.
- `answer.mjs`: internal English structured answers and explanations.
- `llm.mjs`: local endpoint, multilingual boundary, program prompt, repair loop, presentation localization.
- `formaliser.mjs`: import/formalization adapters.


## Correction path

```text
Mention M -> Resolution R1 -> Entity A -> directly asserted Fact F
                         |
operator-reviewed correction
                         v
                  Resolution R2 (supersedes R1) -> Entity B
                         |
                         +-> F2 replaces F only where F recorded R1 as an identity dependency

derived closure is recomputed; R1 and masked F remain auditable
```

The runtime refuses a partial replay when a legacy same-source assertion appears to depend on the old target but has no dependency metadata.
