# 08 — Evaluation Strategy

Evaluation is deliberately split into independent layers.

## A. Deterministic kernel

`npm test` requires no network and no model weights. It covers parser rejection, Program API behavior, transactions, provenance, types, rules, temporal semantics, contradiction, function/rule approval, identity policy, imports, BaseKB immutability, fork/promotion, local HTTP security and model-adapter mocks.

Release 0.3.0 contains **166 deterministic tests** at build time. The additional hardening tests cover accumulated identity evidence, resolution supersession/rebinding, fail-closed legacy replay, execution-version history and audit-chain tamper detection.

## B. Identity policy

`npm run eval` executes the synthetic identity fixture and heuristic ablations. It includes identifiers, homonyms, diacritics, reordered names, initials, nicknames, acronyms, organization jurisdictions, polysemy, recent references, confusables and deliberate abstentions.

This dataset is a regression suite co-designed with the resolver; it is not an independent accuracy benchmark.

## C. Real local model

`npm run smoke:local` checks the complete multilingual boundary on a real configured local endpoint.

`npm run eval:llm` runs diagnostic formalization cases and preserves model/program/error metadata. If no endpoint exists, it reports `not_run`; the repository must never fabricate a score.

## D. Replay/audit correctness

Deterministic tests verify that a superseded identity decision moves only dependency-tracked assertions, excludes old identity evidence, preserves the old records for audit, and refuses incomplete legacy replay. The event-chain test verifies detection of post-hoc mutation to audited rows.

## E. External semantic benchmark — required next

Build an independently labelled corpus with:

- multilingual inputs and parallel semantic annotations;
- same-name people/organizations and negative identity pairs;
- aliases, pseudonyms and temporal name changes;
- explicit negation/modality/uncertainty;
- relation inverses and near-synonyms;
- long-document coreference;
- adversarial prompt-like content inside sources.

Measure separately:

```text
language normalization fidelity
mention/entity extraction
entity resolution precision/recall/abstention
schema/relation mapping
claim extraction
provenance coverage
reasoning correctness
answer verbalization fidelity
```

The primary identity objective should favor precision and calibrated abstention over aggressive recall.
