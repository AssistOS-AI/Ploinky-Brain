# 13 — Remaining Risks and Failure Modes

## 1. Identity corruption

The highest-impact semantic failure. Conservative abstention, blockers and provenance reduce risk but cannot eliminate it. Type-specific policies and reversible rebinding are the next controls.

## 2. Ontology/relation explosion

A model may invent `worksAt`, `employedBy`, `employeeOf`, `hasEmployer`, etc. Relation resolution must classify equivalence/inversion/subsumption rather than matching labels alone. New schema remains candidate until reviewed.

## 3. Semantic drift

Definitions can change over sessions and time. Relation/type definitions eventually need explicit versioning/effective intervals and migration rules.

## 4. Translation loss

English-only internal semantics simplify the system but add a lossy boundary. Preserve original text and normalized text, evaluate both, and abstain when translation ambiguity is material.

## 5. LLM-generated rule amplification

One wrong rule can derive thousands of wrong facts. Candidate quarantine, separate approval, dependency graphs and bounded inference are mandatory.

## 6. Inference explosion

Recursive/high-cardinality joins can become combinatorial. Current budgets fail closed. Production work requires semi-naive evaluation, indexes, planner estimates and per-capability cost limits.

## 7. Prompt injection/source poisoning

A document can contain imperative text aimed at the model. Prompts mark source as data and KB-VM capabilities are bounded, but semantic misformalization remains possible. Treat high-risk sources as candidate claims until reviewed.

## 8. Hidden nondeterminism

LLM calls are probabilistic/external. The deterministic kernel should never call them implicitly. Record model/settings/request/response hashes and keep semantic decisions replayable under a version set.

## 9. Self-modification

Storing functions/rules/constraints makes the KB executable and powerful. Without namespaces, reviewers, signatures and capability manifests it is unsuitable for unattended self-modification.

## 10. Long-document premature commitment

Early chapters may not provide enough evidence to resolve a mention. Commit candidate mentions/claims first; resolve at document or cross-document scope before canonical promotion.

## 11. Scale assumptions

SQLite and JSON records are appropriate for this research prototype but should not be assumed performant at tens of millions of facts without measurement and index/schema redesign.


## Partial replay and false corrections

A graph-wide replacement of entity IDs would be dangerous because not every fact mentioning an entity necessarily originated from the same ambiguous mention. Release 0.3 therefore rewrites only facts carrying an explicit matching `identityDependency`. Old sessions may lack this metadata; correction fails closed with `REPLAY_UNTRACKED` rather than guessing.

The operator correction path also refuses a target that conflicts with explicit trusted identity blockers. If the original formalizer extracted a discriminator incorrectly, correct/re-ingest that evidence first instead of overriding it through rebinding.

## Audit-chain overclaim

The local hash chain detects mutation relative to the stored chain but is not a signature, external timestamp or protection against a privileged attacker who can rewrite the full database and recompute hashes. Future high-assurance deployments should sign/checkpoint audit heads externally.
