# 02 — Data Model, Persistence and Versioning

## SQLite physical schema

Each BaseKB/SessionKB uses a deliberately generic STRICT schema:

```sql
meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)
records(id TEXT PRIMARY KEY, kind TEXT NOT NULL, name TEXT NOT NULL,
        data TEXT NOT NULL CHECK(json_valid(data)), created_at TEXT NOT NULL)
masks(id TEXT PRIMARY KEY, reason TEXT NOT NULL, created_at TEXT NOT NULL)
events(seq INTEGER PRIMARY KEY, at TEXT NOT NULL,
       kind TEXT NOT NULL, data TEXT NOT NULL CHECK(json_valid(data)))
```

This is a prototype representation, not the target schema for tens of millions of records. Logical records remain explicit and inspectable while the design is still evolving.

## Logical record kinds

Important kinds include:

- `entity`, `type`, `relation`;
- `assertion` and derived assertion provenance;
- `source`;
- `mention`;
- `resolution` (including superseding decisions);
- `execution` (runtime version set, program/IR hashes, answer hash and inference summary);
- `rule`, `constraint`, `function`, `hook`, `alias`;
- literals/query results exist as runtime values where appropriate.

Every semantic record is tagged `internalLanguage:"en"`. `source` is the deliberate exception because its `text` field must preserve the original bytes/characters. A source additionally carries `sourceLanguage` and `normalizedText`.

## Hyper-relational facts

Assertions are ordered n-ary relations, not only RDF triples. They can carry polarity, context, temporal validity, qualifiers, status and evidence. Assertions created from resolved mentions may additionally carry `identityDependencies:[{resolutionId,positions}]`, which is replay metadata rather than world semantics. This permits representations such as employment with role/time qualifiers without forcing all semantics into binary triples.

## Type representation

The bootstrap provides `instanceOf` and a simple parent hierarchy. Types remain first-class records. The prototype keeps a direct `type` field for efficient validation while also materializing classification facts where appropriate; a future metamodel can reduce this duplication.

## Version set

The current release declares:

```text
schemaVersion           2
internalLanguage        en
knowledgeIRVersion      1.0
programApiVersion       1.0
resolverPolicyVersion   3.0
inferenceVersion        1.0
identityProfileVersion  1.0
auditChainVersion       1.0
promptVersion           2.1
```

See `src/versions.mjs`. Do not silently reinterpret versioned data. Store metadata describes the versions present when the file was initialized/migrated; opening it under a newer backward-compatible runtime must not rewrite that history. Every committed `execution` record stores the runtime `VERSION_SET` actually used. `migrations/001-v1-to-v2.mjs` demonstrates explicit migration. Because v2 adds an English-semantic contract that cannot be proven from arbitrary v1 text, the migration requires an explicit operator assertion (`--assume-english`) after review/normalization. Legacy v1 entity identifiers/properties are preserved but explicitly downgraded to untrusted identity evidence because v1 did not record field-level provenance. Migration writes a new file rather than mutating the old one.

## Scaling direction

The generic `records` table is intentionally simple. Before production-scale use, benchmark representative targets and introduce specialized indexes/tables for canonical labels, aliases, identifiers, relation arguments, temporal intervals and provenance edges. Do not prematurely encode a storage layout before query patterns are measured.
