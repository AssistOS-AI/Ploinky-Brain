# 04 — Knowledge Program and Canonical IR

## Surface grammar

The model emits a deliberately small JS-like language:

```text
program    := statement*
statement  := "const" identifier "=" expression ";"
            | "return" expression ";"
            | expression ";"
expression := scalar | identifier | array | object | directCall
```

There is no member access, assignment mutation, loops, user functions, classes, `new`, imports, async, templates, dynamic property access, `eval`, `Function`, filesystem, process, SQL or networking.

## Canonical IR

The textual DSL is only a convenient surface. The parser output is wrapped in a canonical versioned object:

```json
{
  "kind": "KnowledgeProgramIR",
  "irVersion": "1.0",
  "programApiVersion": "1.0",
  "statements": []
}
```

KB-VM executes validated IR, and every execution exposes an IR hash. Future front ends—SOP Lang, a GUI, a dedicated formalizer, or another model—should target this same IR rather than duplicating execution semantics.

## Core API groups

**Evidence and identity**

```text
sourceSpan(exactQuote, occurrence?)
claim(value, evidence)
createEntity(name, EnglishDescription, options)
createEntityType(name, EnglishDescription, options)
createRelationType(name, EnglishDescription, options)
```

**Assertions and logic**

```text
createFact(relation,args,options)
query(...)
truth(...)
explain(...)
retractFact(...)
```

**Capabilities and schema extension**

```text
call(reviewedFunction,...)
createFunction(...)
createRule(...)
createConstraint(...)
createAlias(...)
```

Definitions created by the latter group are candidates and require a separate approval action.

**Answers/control**

```text
respond(value)
clarify(EnglishQuestion)
ref(id)
literal(value, metadata)
get(object,key)
```

## Why not arbitrary JavaScript

Arbitrary JS would make model output capable of infinite loops, filesystem/network access, environment disclosure, process spawning and prototype tricks. More subtly, it would make deterministic replay and capability auditing difficult. A small language is therefore a semantic and security boundary, not merely a syntactic preference.
