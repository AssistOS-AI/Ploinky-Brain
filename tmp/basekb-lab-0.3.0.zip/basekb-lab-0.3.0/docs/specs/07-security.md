# 07 — Security and Capability Model

The prototype is designed for a local operator, not as an audited multi-tenant SaaS sandbox.

## Threats considered

| Threat | Current control |
|---|---|
| Model-generated shell/FS/network code | Custom parser + whitelisted KB-VM; no such capabilities in Program API |
| `eval`/constructor/prototype escape | Syntax rejection, own-key access, banned keys and safe JSON-shaped data |
| Infinite loops / computation bombs | No loops/functions; AST/fuel/write/inference budgets |
| Prompt injection in documents | Source treated as untrusted data; model has bounded Program API; executable/schema output quarantined |
| BaseKB contamination from chat | Base opened read-only; session overlay; explicit promotion to new file |
| False identity merge | conservative anchors/blockers, accumulated evidence profiles, first-class/supersedable decisions, explicit clarification |
| Rule/function poisoning | candidates require separate approval |
| Fabricated provenance | exact span validation against current raw source |
| Remote model exfiltration by default | loopback-only endpoint policy; remote endpoint requires explicit opt-in |
| Cross-site requests to local UI | local token/origin/Host checks and bounded JSON parsing |
| Silent history modification | hash-linked session event chain + explicit verifier (integrity aid, not a signature) |
| Partial identity correction | dependency-directed replay; legacy untracked cases fail closed |

## Important limitations

- The host Node process and local model server remain trusted components.
- The custom parser/interpreter should receive continued fuzzing/audit.
- A valid source span does not prevent semantic hallucination by the formalizer.
- Imports can contain hostile data even if code remains quarantined.
- A wrongly approved rule can derive many wrong conclusions.
- A local model may retain/log prompts according to its own server configuration; inspect that product before confidential use.
- The audit chain is not a cryptographic signature or external notarization. A fully privileged host that rewrites the entire DB and recomputes hashes remains trusted.

## Self-modification policy

The system can represent new functions/rules/constraints, which is research-interesting but dangerous. Candidate creation and activation are intentionally separate trust transitions. Future versions should add signer/reviewer identity, namespaces, capability manifests and versioned approval records.
