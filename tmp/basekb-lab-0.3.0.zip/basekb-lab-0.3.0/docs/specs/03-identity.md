# 03 — Entity and Relation Identity

Identity resolution is the highest-risk semantic subsystem: a wrong fact can be retracted locally, while a wrong entity merge connects entire subgraphs.

## Principle

```text
candidate generation != identity proof
```

`isTheSame(left,right)` returns inspectable features, anchors, blockers and a provisional decision. `resolveEntity` evaluates the candidate set and may reuse an entity, create a new entity, or abstain with a clarification request.

## Mention shape

Conceptually:

```javascript
{
  name: "Alex Stone",
  description: "Alex Stone, the person described in the current source.",
  type: "sys:Person",
  ids: { orcid: "..." },
  properties: { birthDate: "1970-01-01" },
  identityEvidence: {
    ids: { orcid: {trusted:true, evidence:{...}} },
    properties: { birthDate: {trusted:true, evidence:{...}} }
  }
}
```

## Candidate generators

The resolver can use many inexpensive deterministic heuristics to locate plausible candidates:

- exact normalized label;
- Unicode normalization and Romanian cedilla/comma normalization;
- diacritic folding;
- title removal and name-order variants;
- initials and surname variants;
- generated organization acronyms;
- approved aliases;
- nicknames as weak aliases;
- fuzzy bigram similarity;
- type compatibility;
- description-word overlap;
- recent session references.

These features improve recall. Most do **not** authorize a merge.

## Anchors

Current anchors include:

- field-evidenced trusted identifiers in known namespaces (ORCID, DOI, Wikidata, ISBN, registry, IRI, etc.);
- reviewed strong aliases, excluding nickname/acronym classes;
- evidence-bearing hard discriminators such as `birthDate`, `registryCountry`, `parentOrganization`, `version`;
- exact compatible entity recently established in the same session, within a bounded recent window;
- exact case-sensitive artifact labels under the artifact policy;
- concept label + substantial English definition overlap;
- declared type identity.

Soft properties such as affiliation/city/country may rank a candidate but are deliberately insufficient on their own because they change over time and are often ambiguous.

## Blockers

Examples:

- disjoint declared entity types;
- conflicting trusted unique identifier;
- conflicting evidence-bearing hard discriminator;
- mismatch for declared case-sensitive labels;
- mixed-script/confusable/control characters requiring manual review.

A blocker wins over positive score. Scores are ranking signals, **not calibrated probabilities**.

## Same-name people and organizations

A globally identical person or organization name is not enough. `Alex Stone` may denote several people; `Acme` may denote several legal entities. Organization resolution should eventually evolve into a type-specific policy using registry jurisdiction, legal identifiers, parent organization, address and temporal validity.

## Nicknames and aliases

Nicknames are intentionally weak. `Bob -> Robert` is not globally valid for every Robert and must not auto-merge by itself. Strong aliases require review/provenance. Aliases should ultimately carry scope and time.

## Recent context

Recent context may bind `she`, `it`, `this company`, or a repeated exact compatible label when only one scoped referent exists. Multiple compatible recent entities produce clarification. Context is a session-local anchor, not a global ontology assertion.

## First-class decisions

For every entity creation/reuse attempt, KB-VM stores:

```text
Mention M
   -> ResolutionDecision R
       - policyVersion
       - candidate evidence
       - blockers/anchors
       - decision/reason
       - target Entity E
```

A later operator-reviewed decision can supersede an earlier resolution. The old decision remains immutable/auditable; active identity profiles and recent-context resolution follow only the effective decision chain.

## Relation identity

Relation names are even more dangerous to normalize blindly:

```text
employedBy(Person, Organization)
employs(Organization, Person)          # inverse / argument permutation
worksAt(Person, Place)                 # different range
memberOf(Person, Organization)         # related but not identical
```

The resolver currently enforces exact/approved alias identity only when ordered signatures are compatible and surfaces semantic suggestions. Future comparison should explicitly classify `SAME`, `INVERSE`, `BROADER`, `NARROWER`, `ARGUMENT_PERMUTATION`, `RELATED`, `DIFFERENT`, `UNCERTAIN`.

## LLM role in identity

An LLM may be enabled as an **adviser** for ambiguous cases, but it cannot auto-merge. The deterministic evidence policy and explicit human confirmation remain authoritative.

## Non-destructive identity profiles

Release 0.3 derives an `IdentityProfile` for every entity from:

1. trusted field-level evidence on the entity record when its originating resolution is still active;
2. trusted identifiers/properties carried by active `ResolutionDecision` mentions that target the entity.

The entity row is not overwritten merely because a later mention contributes a birth date, registry ID or other discriminator. The derived profile deduplicates equal claims, retains origins/evidence, and records conflicts. A conflicting trusted unique identifier or hard discriminator makes the candidate unsafe for automatic matching until corrected. Superseded resolutions do not contribute to the active profile.

## Rebinding and replay

Facts created in 0.3 record `identityDependencies` mapping a resolution ID to the argument positions that came from that resolution. `Engine.rebindResolution(...)` is operator-only and:

- creates a new resolution with `supersedes:<old>`;
- updates the mention's effective target while retaining resolution history;
- rewrites only local directly asserted facts whose dependency metadata names the old resolution;
- masks the replaced assertions instead of deleting them;
- recomputes inference/constraints from the corrected assertion set;
- marks a newly created false duplicate entity `orphaned` only when no independent active resolution/fact still requires it;
- refuses the operation with `REPLAY_UNTRACKED` when a legacy same-source fact may depend on the old target but lacks dependency metadata.

This is deliberately not arbitrary graph-wide search/replace. Identity correction must be provenance-directed.

## Standard identifier validation

A value does not become a trusted identity anchor merely because it is wrapped in `claim(...)`. Known identifier namespaces are structurally validated before use: ORCID and ISBN include checksum validation; Wikidata IDs, DOI and IRI values must match canonical syntax. Authority-specific `registry`/`external` identifiers still require field-level provenance but cannot be universally checksum-validated by the kernel. Invalid claimed identifiers reject the transaction rather than degrading silently into a trusted anchor.
