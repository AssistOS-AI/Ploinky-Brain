# References and External Interfaces

These references are implementation/background pointers, not imported dependencies.

## Runtime / SQLite

- Node.js `node:sqlite`: https://nodejs.org/api/sqlite.html
- SQLite STRICT tables: https://www.sqlite.org/stricttables.html

## Local inference

- Ollama documentation: https://docs.ollama.com/
- Ollama OpenAI compatibility: https://docs.ollama.com/openai
- Qwen3-Coder model family: https://huggingface.co/Qwen
- llama.cpp: https://github.com/ggml-org/llama.cpp

## Knowledge representations and reasoning — useful future adapters/comparators

- RDF 1.2 concepts/specification family: https://www.w3.org/RDF/
- OWL 2: https://www.w3.org/OWL/
- JSON-LD: https://www.w3.org/TR/json-ld11/
- Datalog background: https://en.wikipedia.org/wiki/Datalog

## Design note

BaseKB Lab intentionally does not claim standards conformance beyond the strict subset/adapters documented in this repository. Add standards only with parser/semantic tests and explicit versioning.
